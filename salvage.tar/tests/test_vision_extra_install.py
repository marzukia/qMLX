# SPDX-License-Identifier: Apache-2.0
"""Regression tests for L-07 (``qmlx[vision]`` extra wiring) and
L-07-B (Gemma 4 fresh-install regression from 0.10.0).

Pre-fix probe (Kai r2, 0.8.0): a fresh-venv ``pip install qmlx==0.8.0``
did not pull ``mlx-vlm``, and hitting a VL route 500'd with
``ModuleNotFoundError: No module named 'mlx_vlm'``. Fix: declare
``mlx-vlm`` under ``[project.optional-dependencies].vision`` (NOT core,
to save ~322 MB for text-only users). README quickstart documents
``pip install 'qmlx[vision]'``.

0.10.0 regression (Layer A "+13 Gemma 4 aliases"): a fresh-venv
``pip install qmlx==0.10.0 && qmlx serve gemma-4-12b-4bit``
crashed the same way — Gemma 4 uses ``mlx_vlm.models.gemma4.language``
because Google publishes it as a VLM-family checkpoint. The obvious
fix — promoting ``mlx-vlm`` to core — would drag in ~+483 MB of
transitive weight (opencv-python 120 MB, pyarrow 123 MB from datasets,
pandas 70 MB, scipy 98 MB, mlx-audio 17 MB, ...) for text-only users
who never touch Gemma 4. Instead we **vendor** the ~1200 lines of
Gemma 4 text-only classes (config + language + rope_utils) into
``vllm_mlx/models/gemma4_vendored/`` (+200 KB of repo, zero MB user
install). ``vllm_mlx/models/gemma4_text.py`` prefers ``mlx-vlm`` when
installed (so ``[vision]`` users get the shared code path) and falls
back to the vendored copy otherwise.

These tests parse ``pyproject.toml`` via ``tomllib`` and lock in both
contracts:

  * ``[vision]`` still exists, still lists ``mlx-vlm`` (for Qwen-VL and
    true VLM routes — image-input models still need mlx-vlm proper).
  * ``mlx-vlm`` NEVER slips into core deps (the ~322 MB / ~483 MB anti-
    bloat guard).
  * Gemma 4 boots WITHOUT ``mlx-vlm`` — the vendored module tree exists
    and ``gemma4_text.py`` carries the try/except fallback.

A future refactor that silently drops any of these re-opens either the
original L-07 (bare 500 on VL routes) or L-07-B (bare boot failure on
Gemma 4 — same failure shape).
"""

from __future__ import annotations

import sys
from pathlib import Path

# Codex round-1 BLOCKING: ``import tomllib`` at module-import time would
# crash on Python 3.10 (the floor in ``pyproject.toml`` →
# ``requires-python = ">=3.10"``) before the version-floor test could
# emit a diagnostic. Fall back to the third-party ``tomli`` backport
# (same API surface) so the file imports cleanly on every supported
# interpreter. The runtime is identical on 3.11+ where ``tomllib`` is
# stdlib; on 3.10 the user must ``pip install tomli`` to run the
# vision-extra lock-in tests (skipped at the file level otherwise).
try:
    import tomllib  # type: ignore[import-not-found]
except ModuleNotFoundError:  # pragma: no cover — 3.10 fallback
    try:
        import tomli as tomllib  # type: ignore[import-not-found,no-redef]
    except ModuleNotFoundError:
        import pytest

        pytest.skip(
            "tomllib (stdlib ≥3.11) or tomli (3.10 backport) is required "
            "to parse pyproject.toml; install one with `pip install tomli` "
            "to run the L-07 lock-in tests.",
            allow_module_level=True,
        )


def _load_pyproject() -> dict:
    """Locate and parse the repo's ``pyproject.toml``. Walks up from
    this test file so the lookup survives both ``pytest tests/`` and
    a ``pytest path/to/tests/...`` invocation."""
    here = Path(__file__).resolve()
    for parent in [here.parent, *here.parents]:
        candidate = parent / "pyproject.toml"
        if candidate.is_file():
            with candidate.open("rb") as fp:
                return tomllib.load(fp)
    raise RuntimeError(  # pragma: no cover — sanity, repo always has one
        f"pyproject.toml not found above {here}"
    )


def _extra_specs(pyproject: dict, extra: str) -> list[str]:
    """Return the dep-spec list for a given ``[project.optional-dependencies]``
    extra. PEP 621 keeps these under ``project.optional-dependencies``."""
    return pyproject.get("project", {}).get("optional-dependencies", {}).get(extra, [])


def _split_spec(spec: str) -> tuple[str, str]:
    """Split ``"mlx-vlm>=0.6.3"`` into ``("mlx-vlm", ">=0.6.3")``. The
    PEP 508 surface is broader than this (markers, environment
    qualifiers) but every spec under our extras is the plain
    ``name<op><version>`` shape — keep the parse simple to avoid pulling
    ``packaging`` into the test runtime."""
    for op in (">=", "==", "~=", "!=", "<=", ">", "<"):
        if op in spec:
            name, _, ver = spec.partition(op)
            return name.strip(), op + ver.strip()
    return spec.strip(), ""


# ──────────────────────────────────────────────────────────────────────
# Core: vision extra exists, lists mlx-vlm, and the version floor is
# real (not a placeholder).
# ──────────────────────────────────────────────────────────────────────


def test_vision_extra_exists() -> None:
    """``[project.optional-dependencies].vision`` MUST be declared so
    ``pip install 'qmlx[vision]'`` resolves. The README quickstart
    documents this exact invocation — its disappearance would be a
    documentation-vs-code drift."""
    py = _load_pyproject()
    extras = py.get("project", {}).get("optional-dependencies", {})
    assert "vision" in extras, (
        f"`[vision]` extra missing from pyproject. Available extras: "
        f"{sorted(extras)!r}. README quickstart references "
        f"`pip install 'qmlx[vision]'` and would 404 without this."
    )


def test_vision_extra_lists_mlx_vlm() -> None:
    """The whole point of ``[vision]`` is to install ``mlx-vlm``. If
    this assertion fails, hitting a VL route still 500s with
    ``ModuleNotFoundError: No module named 'mlx_vlm'`` — i.e. L-07
    regressed."""
    py = _load_pyproject()
    specs = _extra_specs(py, "vision")
    names = {_split_spec(s)[0].lower() for s in specs}
    assert "mlx-vlm" in names, (
        f"mlx-vlm missing from `[vision]` extra. Got specs={specs!r}. "
        f"This is the dep that prevents the ``ModuleNotFoundError: No "
        f"module named 'mlx_vlm'`` on VL routes per L-07."
    )


def test_vision_mlx_vlm_floor_is_recognizable() -> None:
    """The minimum-version floor must be a concrete version, not an
    empty pin or a wildcard. ``0.8.0`` was tested against ``>=0.6.3``
    (Gemma 4 DLM PR #1347 + long-context prefill PR #1348). The L-07
    TODO references the older ``>=0.4.4`` floor as a workaround — we
    keep the stricter floor since downgrading would unwire
    DiffusionGemma support."""
    py = _load_pyproject()
    specs = _extra_specs(py, "vision")
    for spec in specs:
        name, ver = _split_spec(spec)
        if name.lower() == "mlx-vlm":
            assert ver.startswith(">="), (
                f"mlx-vlm spec should pin a minimum version with ``>=``; "
                f"got {spec!r}. A non-floor pin (``==`` / ``~=``) breaks "
                f"forward compatibility with mlx-vlm patch releases."
            )
            # The floor must be a real PEP-440 version string, not a
            # placeholder. Cheap-check: at least one dot.
            floor = ver[2:].strip()
            assert "." in floor, (
                f"mlx-vlm floor {floor!r} doesn't look like a real version. "
                f"Expected something like ``>=0.6.3``."
            )
            return
    raise AssertionError(  # pragma: no cover — guarded by the test above
        "mlx-vlm spec not found in `[vision]` extra"
    )


# ──────────────────────────────────────────────────────────────────────
# Defense in depth: mlx-vlm must NOT be in core deps (would defeat the
# whole point of the extra — the ~322 MB save for text-only users).
# ──────────────────────────────────────────────────────────────────────


def test_mlx_vlm_not_in_core_dependencies() -> None:
    """If ``mlx-vlm`` slips into ``[project].dependencies`` the
    text-only ``pip install qmlx`` jumps from ~460 MB to ~782 MB.
    The point of the ``[vision]`` extra is to keep that surface
    opt-in. This is the second half of L-07's contract."""
    py = _load_pyproject()
    core = py.get("project", {}).get("dependencies", [])
    core_names = {_split_spec(s)[0].lower() for s in core}
    assert "mlx-vlm" not in core_names, (
        f"mlx-vlm leaked into core deps={core!r}. Move it back under "
        f"`[project.optional-dependencies].vision` so the text-only "
        f"`pip install qmlx` stays slim (L-07)."
    )


# ──────────────────────────────────────────────────────────────────────
# README quickstart references `pip install 'qmlx[vision]'`. The
# docs-code drift would silently break the documented opt-in path.
# ──────────────────────────────────────────────────────────────────────


def test_readme_quickstart_mentions_vision_extra() -> None:
    """The README quickstart MUST surface the ``[vision]`` opt-in so a
    user reading top-down learns how to install for VL routes BEFORE
    hitting a 500. Detection is intentionally loose: any line carrying
    both ``qmlx`` and ``[vision]`` in the README counts."""
    here = Path(__file__).resolve()
    readme_path = None
    for parent in [here.parent, *here.parents]:
        candidate = parent / "README.md"
        if candidate.is_file():
            readme_path = candidate
            break
    assert readme_path is not None, (
        "README.md not found above the test file — repo layout regressed?"
    )
    text = readme_path.read_text(encoding="utf-8")
    has_vision_install = any(
        ("qmlx" in line and "[vision]" in line) for line in text.splitlines()
    )
    assert has_vision_install, (
        "README.md no longer documents `pip install 'qmlx[vision]'`. "
        "Users hitting a VL route now get a bare 500 with no install hint "
        "(L-07 — Kai r2 probe surfaced this on fresh-venv 0.8.0 installs)."
    )


# ──────────────────────────────────────────────────────────────────────
# Self-consistency: the ``all`` extra (advertised as union-of-everything)
# also pulls mlx-vlm. Otherwise ``pip install 'qmlx[all]'`` silently
# skips vision and we get the L-07 failure mode under a different name.
# ──────────────────────────────────────────────────────────────────────


def test_all_extra_includes_mlx_vlm() -> None:
    """``[all]`` is documented as the union of vision + chat + embeddings.
    A user who installs ``qmlx[all]`` expecting "everything"
    must NOT discover at request-time that mlx-vlm isn't there."""
    py = _load_pyproject()
    all_specs = _extra_specs(py, "all")
    names = {_split_spec(s)[0].lower() for s in all_specs}
    assert "mlx-vlm" in names, (
        f"`[all]` extra is documented as union-of-everything but does "
        f"not include mlx-vlm. Got specs={all_specs!r}."
    )


# ──────────────────────────────────────────────────────────────────────
# Tooling sanity — pyproject pins ``requires-python = ">=3.10"``. To
# keep the L-07 lock-in suite running on every supported interpreter
# (codex round-2 BLOCKING: a 3.10 CI worker without tomli would have
# module-skipped the entire suite), the [dev] extra declares
# ``tomli>=2.0.1; python_version < "3.11"``. This test pins both
# halves of that contract: the requires-python floor AND the matching
# tomli dev-dep declaration.
# ──────────────────────────────────────────────────────────────────────


def test_pyproject_requires_python_floor_matches_tomllib_fallback() -> None:
    """The TOML import block falls back to ``tomli`` on Python <3.11 so
    the L-07 lock-in tests work on every Python the project supports.
    Pin both halves of that contract here so a future floor bump
    (e.g. ``>=3.11``) lets a reviewer notice the now-dead fallback."""
    py = _load_pyproject()
    requires = py.get("project", {}).get("requires-python", "")
    assert requires, "pyproject.toml must declare requires-python"
    # The floor must be ``>=3.10`` or stricter — anything looser would
    # widen the surface this test file's tomli fallback covers.
    assert ">=3." in requires, (
        f"requires-python={requires!r} doesn't pin a 3.x floor — the "
        f"tomli fallback in this file assumes a Python 3 floor."
    )
    # Document the runtime we're using so a 3.10 contributor sees a
    # meaningful trail when reviewing the fallback.
    assert sys.version_info >= (3, 10), (
        f"Test runtime {sys.version_info[:2]} is below the project's "
        f"3.10 floor — the tomli fallback can't help here."
    )


def test_dev_extra_pins_tomli_for_python_310() -> None:
    """Codex round-2 BLOCKING: without ``tomli`` in the [dev] extra
    for Python <3.11, a 3.10 CI worker without the package would have
    module-skipped this whole L-07 suite — letting a future refactor
    silently drop the ``[vision]`` extra without any test ever firing.

    Pin that ``tomli`` is declared with the ``python_version < "3.11"``
    marker (PEP 508) so the dep only resolves on 3.10 where it's
    actually needed. On 3.11+ the stdlib ``tomllib`` is used; the
    marker keeps the install lean.
    """
    py = _load_pyproject()
    dev_specs = _extra_specs(py, "dev")
    # PEP 508 marker form: spec is something like
    # ``tomli>=2.0.1; python_version < "3.11"``. The dep name + marker
    # check is what we care about; the exact version is the dev's choice.
    matching = [
        spec
        for spec in dev_specs
        if "tomli" in spec.lower()
        and ";" in spec
        and "python_version" in spec
        and "3.11" in spec
    ]
    assert matching, (
        f"`[dev]` extra must declare tomli with a `python_version < "
        f'"3.11"` marker so 3.10 CI workers can actually run the '
        f"L-07 lock-in suite. Got dev specs: {dev_specs!r}"
    )
