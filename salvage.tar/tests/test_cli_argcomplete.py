# SPDX-License-Identifier: Apache-2.0
"""Unit tests for the qmlx CLI shell-completion helpers.

Locks in things that are easy to break:

1. ``alias_completer`` returns aliases filtered by prefix (the actual
   contract a completion layer invokes per keystroke).
2. ``alias_csv_completer`` correctly carries the comma-separated
   prefix forward so ``--models qwen3.5-4b-4bit,gem<TAB>`` expands the
   trailing token only.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from vllm_mlx._completion import (
    _ALIASES_PATH,
    alias_completer,
    alias_csv_completer,
)

def test_alias_completer_no_prefix_returns_sorted_list() -> None:
    """Empty prefix → full sorted alias list (shell collapses to the
    longest common prefix and re-prompts on second Tab, standard UX)."""
    result = alias_completer("")
    assert len(result) > 50, (
        f"expected the full alias list, got {len(result)}; if the file "
        "moved or load_alias_names returned [], this regressed"
    )
    assert result == sorted(result), "completer must return sorted output"


def test_alias_completer_filters_by_prefix() -> None:
    """``qwen3.5-<TAB>`` must surface all qwen3.5-* aliases and nothing
    else. This is the user-visible contract: a startswith filter on the
    alias name. (The completion pool is qwen3.*-only per the 2026-10-23
    operator directive — the same catalog ``qmlx models`` presents.)"""
    result = alias_completer("qwen3.5-")
    assert len(result) >= 5, "should match at least 5 qwen3.5 aliases"
    assert all(n.startswith("qwen3.5-") for n in result), (
        f"completer leaked non-matching aliases: "
        f"{[n for n in result if not n.startswith('qwen3.5-')]}"
    )
    # Lock in the canonical bring-up aliases — a ``len >= 5`` floor
    # alone would have passed even if the flagship entries were
    # dropped from aliases.json. Explicit membership catches that
    # regression.
    canonical = {
        "qwen3.5-9b-4bit",
        "qwen3.5-4b-4bit",
        "qwen3.5-35b-4bit",
        "qwen3.5-122b-8bit",
        "qwen3.5-122b-oq4-mtp",
    }
    missing = canonical - set(result)
    assert not missing, f"canonical aliases missing from completer output: {missing}"


def test_alias_completer_unknown_prefix_returns_empty() -> None:
    """Unknown prefix → []; the shell will then beep/fall back to
    filename completion. Must not raise or return stale results."""
    result = alias_completer("this-alias-does-not-exist-xyz")
    assert result == []


def test_alias_completer_handles_missing_aliases_file(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Tab completion must NEVER raise. A missing or corrupt
    aliases.json should degrade to ``[]`` — anything else propagates
    as a Python traceback into the user's shell, which is worse than a
    silent no-match."""
    missing = tmp_path / "no_such_aliases.json"
    monkeypatch.setattr("vllm_mlx._completion._ALIASES_PATH", missing)

    assert alias_completer("") == []
    assert alias_completer("gemma-4-") == []


def test_alias_completer_handles_corrupt_aliases_file(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Same robustness contract for a syntactically broken file."""
    corrupt = tmp_path / "broken.json"
    corrupt.write_text("not valid json {{")
    monkeypatch.setattr("vllm_mlx._completion._ALIASES_PATH", corrupt)

    assert alias_completer("") == []


def test_alias_csv_completer_first_token() -> None:
    """``qmlx doctor --models <TAB>`` (no comma yet) behaves
    exactly like ``alias_completer``."""
    no_comma = alias_csv_completer("gemma-4-")
    plain = alias_completer("gemma-4-")
    assert no_comma == plain


def test_alias_csv_completer_appends_to_existing_csv() -> None:
    """``--models qwen3.5-4b-4bit,qwen3.6-<TAB>`` should expand only the
    trailing token but emit the full re-assembled value so the shell
    inserts ``qwen3.5-4b-4bit,qwen3.6-27b-4bit`` rather than dropping the head."""
    result = alias_csv_completer("qwen3.5-4b-4bit,qwen3.6-")
    assert all(m.startswith("qwen3.5-4b-4bit,qwen3.6-") for m in result), (
        f"csv completer dropped the head before the comma: "
        f"{[m for m in result if not m.startswith('qwen3.5-4b-4bit,')]}"
    )
    assert len(result) >= 5, "should match at least 5 qwen3.6-* tokens"


def test_alias_csv_completer_multiple_commas() -> None:
    """``--models a,b,c<TAB>`` only completes ``c``; ``a,b,`` is
    carried through unchanged. Lock this in because rpartition vs
    partition is an easy-to-flip bug."""
    result = alias_csv_completer("qwen3.5-4b-4bit,gemma-4-12b-4bit,qwen3.6-")
    assert all(
        m.startswith("qwen3.5-4b-4bit,gemma-4-12b-4bit,qwen3.6-") for m in result
    ), "csv completer must preserve all prior csv tokens"


def test_aliases_path_resolves_to_real_file() -> None:
    """Sanity check the path we ship resolves to a real file in the
    installed package — catches a path bug at the module level."""
    assert _ALIASES_PATH.exists(), (
        f"aliases.json missing at {_ALIASES_PATH}; if the file moved, "
        "_completion.py needs the new location"
    )


def test_alias_csv_completer_handles_whitespace_after_comma() -> None:
    """``--models a, gem<TAB>`` — the runtime alias parser already
    accepts whitespace around commas (``split + strip``). The completer
    must match that contract so users who naturally type the
    human-friendly ``a, b, c`` shape get suggestions instead of an
    empty list."""
    spaced = alias_csv_completer("qwen3.5-4b-4bit, gemma-4-")
    tight = alias_csv_completer("qwen3.5-4b-4bit,gemma-4-")
    assert len(spaced) == len(tight), (
        "csv completer must produce the same number of matches whether "
        "the user typed `a,b` or `a, b`"
    )


def test_load_alias_names_rejects_oversized_file(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """A hostile multi-megabyte ``aliases.json`` (supply-chain swap, or
    a dev-machine fat-finger) must not stall every keystroke on a
    multi-second JSON decode. Cap is hard and fail-closed."""
    from vllm_mlx import _completion

    huge = tmp_path / "huge.json"
    payload = "{" + ",".join(f'"{i}":1' for i in range(200_000)) + "}"
    huge.write_text(payload)
    assert huge.stat().st_size > _completion._MAX_ALIASES_BYTES

    monkeypatch.setattr(_completion, "_ALIASES_PATH", huge)
    monkeypatch.setattr(_completion, "_CACHE", None)
    assert _completion._load_alias_names() == []


def test_load_alias_names_strips_unsafe_keys(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """A key containing newline / vertical-tab / NUL bytes would split
    argcomplete's line-oriented stdout IPC into multiple bogus
    completions or corrupt the user's terminal. The loader filters
    them out before returning. Legitimate aliases pass through."""
    from vllm_mlx import _completion

    spiked = tmp_path / "spiked.json"
    spiked.write_text(
        '{"qwen3-good-alias":{}, "evil\\nname":{}, "evil\\u000bname":{}, '
        '"with space":{}, "":{}}'
    )
    monkeypatch.setattr(_completion, "_ALIASES_PATH", spiked)
    monkeypatch.setattr(_completion, "_CACHE", None)

    assert _completion._load_alias_names() == ["qwen3-good-alias"]


def test_load_alias_names_caches_by_mtime(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """A hot Tab burst must hit the in-memory cache, not re-decode
    JSON each keystroke. The cache key is ``(mtime, size)`` so a
    fresh write invalidates automatically."""
    import os

    from vllm_mlx import _completion

    f = tmp_path / "cached.json"
    # Keys must be qwen3.* aliases: the completion surface presents the
    # same qwen3-only catalog as ``qmlx models`` (operator directive
    # 2026-10-23), so a non-qwen3 key would be filtered out here.
    f.write_text('{"qwen3-alpha":{}}')
    monkeypatch.setattr(_completion, "_ALIASES_PATH", f)
    monkeypatch.setattr(_completion, "_CACHE", None)

    first = _completion._load_alias_names()
    assert first == ["qwen3-alpha"]
    cached_id = id(_completion._CACHE)

    second = _completion._load_alias_names()
    assert second == ["qwen3-alpha"]
    assert id(_completion._CACHE) == cached_id, "second call should reuse cache"

    # Edit the file; the mtime+size change must invalidate.
    f.write_text('{"qwen3-alpha":{}, "qwen3-beta":{}}')
    # Force a measurable mtime delta in case the FS has 1-second
    # resolution and the writes landed in the same second.
    future = f.stat().st_mtime + 5
    os.utime(f, (future, future))

    refreshed = _completion._load_alias_names()
    assert refreshed == ["qwen3-alpha", "qwen3-beta"]

