# SPDX-License-Identifier: Apache-2.0
"""Route-level validation hardening (R10 sweep follow-up).

Each test pins behavior that the onboarding sweep showed was silently
broken — e.g. ``model: ""`` returning 200 with the default model,
``top_p=2.0`` accepted without error, ``logit_bias`` silently dropped,
``encoding_format=base64`` ignored on /v1/embeddings.
"""

import argparse
from unittest.mock import MagicMock

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient


@pytest.fixture
def patched_config():
    """Patch select fields on the global cfg singleton and restore on exit.

    Mirrors the pattern in test_routes.py — avoids the ``setattr``/``leak
    into next test`` hazard of touching the singleton directly.
    """
    from vllm_mlx.config import get_config

    cfg = get_config()
    saved: dict = {}

    def patch(**kwargs):
        for k, v in kwargs.items():
            saved.setdefault(k, getattr(cfg, k, None))
            setattr(cfg, k, v)

    yield patch

    for k, v in saved.items():
        setattr(cfg, k, v)


# ---------------------------------------------------------------------------
# _validate_model_name — empty string must 400, not silently use default
# ---------------------------------------------------------------------------


class TestValidateModelName:
    def test_empty_string_raises_400(self):
        """``model: ""`` used to short-circuit to the default model,
        masking client bugs (typos, unset env vars)."""
        from vllm_mlx.service.helpers import _validate_model_name

        with pytest.raises(HTTPException) as ei:
            _validate_model_name("")
        assert ei.value.status_code == 400
        assert "empty" in ei.value.detail.lower()

    def test_none_still_passes_through(self):
        """``None`` continues to be a no-op so callers that pass an
        unset request.model field don't break."""
        from vllm_mlx.service.helpers import _validate_model_name

        # Should not raise.
        _validate_model_name(None)

    def test_mismatch_still_raises_404_via_openai_route(
        self, patched_config, monkeypatch
    ):
        """The OpenAI chat route must still reject unknown model names with 404.
        This confirms that removing _validate_model_name from the Anthropic
        route did NOT affect the OpenAI route."""
        from vllm_mlx.routes import chat as chat_route

        engine = MagicMock()
        engine.is_mllm = False
        patched_config(
            engine=engine,
            model_name="loaded-model",
            model_alias=None,
            model_path=None,
            model_registry=None,
            tool_call_parser=None,
            reasoning_parser=None,
            ready=True,
            api_key=None,
        )
        monkeypatch.setattr(chat_route, "get_engine", lambda *_a, **_kw: engine)

        app = FastAPI()
        app.include_router(chat_route.router)
        client = TestClient(app, raise_server_exceptions=False)

        r = client.post(
            "/v1/chat/completions",
            json={
                "model": "wrong-model",
                "messages": [{"role": "user", "content": "hi"}],
            },
        )
        assert r.status_code == 404
        assert "wrong-model" in r.json()["detail"]


# ---------------------------------------------------------------------------
# Chat completion validation block — top_p, max_tokens cap, logit_bias
# ---------------------------------------------------------------------------


def _build_chat_app(patch_cfg, monkeypatch):
    """Mount the chat router with a stub engine so we can hit the
    validation block without touching mlx weights."""
    from vllm_mlx.routes import chat as chat_route

    app = FastAPI()
    app.include_router(chat_route.router)

    engine = MagicMock()
    engine.is_mllm = False
    patch_cfg(
        engine=engine,
        model_name="stub-model",
        model_alias=None,
        model_path=None,
        model_registry=None,
        tool_call_parser=None,
        reasoning_parser=None,
        ready=True,
        api_key=None,
    )

    # get_engine() inside the route resolves to this stub; if validation
    # passes, the test's other assertions take over (or the engine call
    # fails downstream, which is fine — we only care about the 400 path).
    monkeypatch.setattr(chat_route, "get_engine", lambda *_a, **_kw: engine)

    # raise_server_exceptions=False so downstream-pipeline failures
    # (the mocked engine returns non-coroutines) come back as 500s
    # rather than re-raising into pytest — we only care about the
    # validator response.
    return TestClient(app, raise_server_exceptions=False)


class TestChatValidation:
    def test_top_p_above_one_rejected(self, patched_config, monkeypatch):
        """F-011: Pydantic schema enforces ``top_p ∈ (0, 1]`` via Field
        bounds, so out-of-range values now 422 from the schema layer
        instead of the route's legacy 400. Either code is a clean
        rejection — pin both so a future cleanup that drops the dead
        route guard doesn't trip the test."""
        client = _build_chat_app(patched_config, monkeypatch)
        r = client.post(
            "/v1/chat/completions",
            json={
                "model": "stub-model",
                "messages": [{"role": "user", "content": "hi"}],
                "top_p": 2.0,
            },
        )
        assert r.status_code in (400, 422)
        assert "top_p" in r.text

    def test_top_p_zero_rejected(self, patched_config, monkeypatch):
        """0 is invalid per OpenAI spec — the valid range is (0, 1].

        F-011 promoted the route's 400 to a Pydantic 422; either code
        is a clean rejection."""
        client = _build_chat_app(patched_config, monkeypatch)
        r = client.post(
            "/v1/chat/completions",
            json={
                "model": "stub-model",
                "messages": [{"role": "user", "content": "hi"}],
                "top_p": 0,
            },
        )
        assert r.status_code in (400, 422)
        assert "top_p" in r.text

    def test_top_p_one_passes_validation(self, patched_config, monkeypatch):
        """1.0 is the OpenAI default and must not trigger the top_p
        validator. If downstream plumbing fails (likely, since we stub
        the engine), the failure must NOT be a top_p complaint."""
        client = _build_chat_app(patched_config, monkeypatch)
        r = client.post(
            "/v1/chat/completions",
            json={
                "model": "stub-model",
                "messages": [{"role": "user", "content": "hi"}],
                "top_p": 1.0,
            },
        )
        if r.status_code == 400:
            assert "top_p" not in r.json().get("detail", "")

    def test_max_tokens_over_ceiling_rejected(self, patched_config, monkeypatch):
        """Sanity ceiling at 1_000_000. Combined with admission control
        (separate PR) this prevents OOM from a buggy client passing
        max_tokens=999_999_999."""
        client = _build_chat_app(patched_config, monkeypatch)
        r = client.post(
            "/v1/chat/completions",
            json={
                "model": "stub-model",
                "messages": [{"role": "user", "content": "hi"}],
                "max_tokens": 999_999_999,
            },
        )
        assert r.status_code == 400
        assert "max_tokens" in r.json()["detail"]

    def test_logit_bias_rejected_with_clear_400(self, patched_config, monkeypatch):
        """Previously silently dropped (field not declared in schema).
        Declared + rejected with a clear message so clients can fall
        back without seeing wrong-output."""
        client = _build_chat_app(patched_config, monkeypatch)
        r = client.post(
            "/v1/chat/completions",
            json={
                "model": "stub-model",
                "messages": [{"role": "user", "content": "hi"}],
                "logit_bias": {"50000": -100},
            },
        )
        assert r.status_code == 400
        assert "logit_bias" in r.json()["detail"]

    def test_empty_logit_bias_does_not_trigger_400(self, patched_config, monkeypatch):
        """Defensive clients sometimes always send ``logit_bias: {}``;
        the empty dict must NOT trigger the validator."""
        client = _build_chat_app(patched_config, monkeypatch)
        r = client.post(
            "/v1/chat/completions",
            json={
                "model": "stub-model",
                "messages": [{"role": "user", "content": "hi"}],
                "logit_bias": {},
            },
        )
        if r.status_code == 400:
            assert "logit_bias" not in r.json().get("detail", "")


class TestEmbeddingsEncodingFormatLiteral:
    """Pydantic Literal narrowing replaces the silent-fallback bug:
    unknown encoding_format values now 422 at parse time."""

    def test_unknown_encoding_format_rejected(self):
        """Catches typos like 'base65', 'BASE64', 'json' — previously
        they all silently returned a float list."""
        from pydantic import ValidationError

        from vllm_mlx.api.models import EmbeddingRequest

        for bogus in ["base65", "BASE64", "json", "raw"]:
            with pytest.raises(ValidationError):
                EmbeddingRequest(input="hi", model="x", encoding_format=bogus)

    def test_valid_encoding_formats_accepted(self):
        from vllm_mlx.api.models import EmbeddingRequest

        for ok in ["float", "base64"]:
            req = EmbeddingRequest(input="hi", model="x", encoding_format=ok)
            assert req.encoding_format == ok


# ---------------------------------------------------------------------------
# --log-level accepts lowercase (industry convention)
# ---------------------------------------------------------------------------


class TestLogLevelLowercase:
    def _make_parser(self):
        """Mirror the same ``type`` contract used by serve_parser in
        vllm_mlx/cli.py and vllm_mlx/server.py."""
        parser = argparse.ArgumentParser()
        parser.add_argument(
            "--log-level",
            type=lambda s: s.upper(),
            choices=["DEBUG", "INFO", "WARNING", "ERROR"],
            default="INFO",
        )
        return parser

    @pytest.mark.parametrize("flag", ["debug", "info", "warning", "error"])
    def test_lowercase_accepted(self, flag):
        ns = self._make_parser().parse_args(["--log-level", flag])
        assert ns.log_level == flag.upper()

    @pytest.mark.parametrize("flag", ["DEBUG", "Info", "Warning"])
    def test_mixed_case_accepted(self, flag):
        ns = self._make_parser().parse_args(["--log-level", flag])
        assert ns.log_level == flag.upper()

    def test_unknown_level_still_rejected(self):
        with pytest.raises(SystemExit):
            self._make_parser().parse_args(["--log-level", "trace"])


# ---------------------------------------------------------------------------
# Surgical bundle (R10 follow-up #2):
# - C3: chat rejects image/video on text-only models (no silent hallucination)
# - C16: guided JSON preserves nested array-of-objects (no silent str degrade)
# - H17: `qmlx ps` parses --port positioned after the model argument
# - H18: /v1/completions rejects FIM `suffix` (declared, not silently dropped)
# ---------------------------------------------------------------------------


class TestChatRejectsImageOnTextOnlyModel:
    def test_image_url_on_text_only_engine_400(self, patched_config, monkeypatch):
        """Before this fix, extract_multimodal_content silently stripped
        the image part on a text-only engine and the model would
        confidently caption an image it never saw (R9P1 sweep)."""
        client = _build_chat_app(patched_config, monkeypatch)
        r = client.post(
            "/v1/chat/completions",
            json={
                "model": "stub-model",
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": "what is this?"},
                            {
                                "type": "image_url",
                                "image_url": {"url": "https://example.com/x.png"},
                            },
                        ],
                    }
                ],
            },
        )
        assert r.status_code == 400
        detail = r.json()["detail"]
        assert "image" in detail.lower() or "video" in detail.lower()

    def test_video_on_text_only_engine_400(self, patched_config, monkeypatch):
        client = _build_chat_app(patched_config, monkeypatch)
        r = client.post(
            "/v1/chat/completions",
            json={
                "model": "stub-model",
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": "describe"},
                            {"type": "video", "video": "/tmp/x.mp4"},
                        ],
                    }
                ],
            },
        )
        assert r.status_code == 400
        assert (
            "image" in r.json()["detail"].lower()
            or "video" in r.json()["detail"].lower()
        )

    def test_text_only_content_still_passes_validation(
        self, patched_config, monkeypatch
    ):
        """Plain text request on a text-only engine must NOT trigger the
        vision-rejection branch. (Downstream will 500 because the engine
        is mocked — we only care that the 400 reason is not the new
        guard.)"""
        client = _build_chat_app(patched_config, monkeypatch)
        r = client.post(
            "/v1/chat/completions",
            json={
                "model": "stub-model",
                "messages": [{"role": "user", "content": "hi"}],
            },
        )
        if r.status_code == 400:
            assert "image" not in r.json().get("detail", "").lower()
            assert "video" not in r.json().get("detail", "").lower()


class TestGuidedArrayOfObjectsSchema:
    """Before C16, ``array of objects`` (and ``array of arrays``) fell
    through to ``type_mapping.get(items_type, str)`` and silently became
    ``list[str]``. The model would then emit strings where the schema
    required objects, and the response failed validation against the
    user's own schema (R10 sweep finding)."""

    def test_array_of_objects_maps_to_list_dict(self):
        from vllm_mlx.api.guided import json_schema_to_pydantic

        schema = {
            "type": "object",
            "properties": {
                "items": {"type": "array", "items": {"type": "object"}},
            },
            "required": ["items"],
        }
        model = json_schema_to_pydantic(schema)
        assert model is not None
        # ``list[dict]`` accepts dict elements without coercion. Before
        # the fix this would be ``list[str]`` and dicts would coerce
        # to their repr or raise.
        instance = model(items=[{"a": 1}, {"b": 2}])
        assert instance.items == [{"a": 1}, {"b": 2}]

    def test_array_of_arrays_maps_to_list_list(self):
        from vllm_mlx.api.guided import json_schema_to_pydantic

        schema = {
            "type": "object",
            "properties": {
                "matrix": {"type": "array", "items": {"type": "array"}},
            },
            "required": ["matrix"],
        }
        model = json_schema_to_pydantic(schema)
        assert model is not None
        instance = model(matrix=[[1, 2], [3, 4]])
        assert instance.matrix == [[1, 2], [3, 4]]

    def test_array_of_strings_still_works(self):
        """Sanity: the historical happy path is unchanged."""
        from vllm_mlx.api.guided import json_schema_to_pydantic

        schema = {
            "type": "object",
            "properties": {
                "tags": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["tags"],
        }
        model = json_schema_to_pydantic(schema)
        assert model is not None
        assert model(tags=["a", "b"]).tags == ["a", "b"]


class TestPsCommandPortParsing:
    """``qmlx ps`` used to break on the first positional argument,
    so ``serve qwen3.5-4b-4bit --port 8005`` showed port=8000 (the default).
    Verify the parser keeps scanning for flags after capturing the
    positional model."""

    def _parse_serve(self, cmd_words):
        """Re-implement ps_command's parsing loop in isolation to avoid
        importing psutil + the full CLI. Mirrors cli.py:1249-1280."""
        model = "(unknown)"
        port = "8000"
        try:
            i = cmd_words.index("serve") + 1
            model_seen = False
            while i < len(cmd_words):
                tok = cmd_words[i]
                if tok.startswith("--"):
                    if tok == "--port" and i + 1 < len(cmd_words):
                        port = cmd_words[i + 1]
                        i += 2
                    elif "=" in tok and tok.startswith("--port="):
                        port = tok.split("=", 1)[1]
                        i += 1
                    else:
                        i += 1
                else:
                    if not model_seen:
                        model = tok
                        model_seen = True
                    i += 1
        except ValueError:
            pass
        return model, port

    def test_port_after_positional_model(self):
        model, port = self._parse_serve(
            ["qmlx", "serve", "qwen3.5-4b-4bit", "--port", "8005"]
        )
        assert model == "qwen3.5-4b-4bit"
        assert port == "8005"

    def test_port_before_positional_model(self):
        model, port = self._parse_serve(
            ["qmlx", "serve", "--port", "8005", "qwen3.5-4b-4bit"]
        )
        assert model == "qwen3.5-4b-4bit"
        assert port == "8005"

    def test_port_equals_form(self):
        model, port = self._parse_serve(
            ["qmlx", "serve", "qwen3.5-4b-4bit", "--port=9000"]
        )
        assert model == "qwen3.5-4b-4bit"
        assert port == "9000"

    def test_no_port_uses_default(self):
        model, port = self._parse_serve(["qmlx", "serve", "qwen3.5-4b-4bit"])
        assert model == "qwen3.5-4b-4bit"
        assert port == "8000"


class TestCompletionsSuffixRejection:
    def _build_completions_app(self, patch_cfg, monkeypatch):
        from vllm_mlx.routes import completions as comp_route

        app = FastAPI()
        app.include_router(comp_route.router)

        engine = MagicMock()
        patch_cfg(
            engine=engine,
            model_name="stub-model",
            model_alias=None,
            model_path=None,
            model_registry=None,
            tool_call_parser=None,
            reasoning_parser=None,
            ready=True,
            api_key=None,
        )
        monkeypatch.setattr(comp_route, "get_engine", lambda *_a, **_kw: engine)
        return TestClient(app, raise_server_exceptions=False)

    def test_suffix_rejected_with_400(self, patched_config, monkeypatch):
        """FIM `suffix` was silently dropped pre-PR (field not declared
        on CompletionRequest). Code-completion clients (Continue, Cody)
        would then get a non-FIM completion that ignored the suffix and
        often produced wrong code. Declare + reject so they fall back."""
        client = self._build_completions_app(patched_config, monkeypatch)
        r = client.post(
            "/v1/completions",
            json={
                "model": "stub-model",
                "prompt": "def hello():",
                "suffix": "    return greeting",
            },
        )
        assert r.status_code == 400
        assert "suffix" in r.json()["detail"].lower()

    def test_empty_suffix_does_not_trigger_400(self, patched_config, monkeypatch):
        """Defensive clients sometimes always send ``suffix: ""`` — the
        empty string must NOT trip the new guard."""
        client = self._build_completions_app(patched_config, monkeypatch)
        r = client.post(
            "/v1/completions",
            json={
                "model": "stub-model",
                "prompt": "hello",
                "suffix": "",
            },
        )
        if r.status_code == 400:
            assert "suffix" not in r.json().get("detail", "").lower()

    def test_omitted_suffix_does_not_trigger_400(self, patched_config, monkeypatch):
        client = self._build_completions_app(patched_config, monkeypatch)
        r = client.post(
            "/v1/completions",
            json={"model": "stub-model", "prompt": "hello"},
        )
        if r.status_code == 400:
            assert "suffix" not in r.json().get("detail", "").lower()
