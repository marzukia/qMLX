# SPDX-License-Identifier: Apache-2.0
"""Comprehensive tests for tool call parsers."""

import json

import pytest

from vllm_mlx.api.tool_calling import parse_tool_calls
from vllm_mlx.tool_parsers import (
    HermesToolParser,
    QwenToolParser,
    ToolParserManager,
)


class TestToolParserManager:
    """Test the ToolParserManager registry."""

    def test_list_registered(self):
        """Test that all expected parsers are registered."""
        parsers = ToolParserManager.list_registered()
        expected = [
            "qwen",
            "hermes",
        ]
        for p in expected:
            assert p in parsers, f"Parser '{p}' not found"

    def test_get_tool_parser_by_name(self):
        """Test getting parsers by name."""
        test_cases = [
            ("qwen", QwenToolParser),
            ("qwen3", QwenToolParser),
            ("hermes", HermesToolParser),
            ("nous", HermesToolParser),
        ]
        for name, expected_cls in test_cases:
            parser_cls = ToolParserManager.get_tool_parser(name)
            assert parser_cls == expected_cls, f"Parser '{name}' returned wrong class"

    def test_get_unknown_parser_raises(self):
        """Test that unknown parser raises KeyError."""
        with pytest.raises(KeyError):
            ToolParserManager.get_tool_parser("unknown_parser")

    def test_parser_instantiation(self):
        """Test that all parsers can be instantiated without tokenizer."""
        for name in [
            "qwen",
            "hermes",
        ]:
            parser_cls = ToolParserManager.get_tool_parser(name)
            parser = parser_cls()  # Should not raise
            assert parser is not None


class TestQwenToolParser:
    """Test the Qwen tool parser."""

    @pytest.fixture
    def parser(self):
        return QwenToolParser()

    def test_xml_format(self, parser):
        """Test parsing Qwen XML format."""
        text = '<tool_call>{"name": "calculate", "arguments": {"x": 1, "y": 2}}</tool_call>'
        result = parser.extract_tool_calls(text)

        assert result.tools_called
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0]["name"] == "calculate"

    def test_bracket_format(self, parser):
        """Test parsing Qwen bracket format (Qwen3 style)."""
        text = '[Calling tool: add({"a": 5, "b": 3})]'
        result = parser.extract_tool_calls(text)

        assert result.tools_called
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0]["name"] == "add"

    def test_multiple_xml_calls(self, parser):
        """Test multiple XML tool calls."""
        text = '<tool_call>{"name": "func1", "arguments": {}}</tool_call><tool_call>{"name": "func2", "arguments": {}}</tool_call>'
        result = parser.extract_tool_calls(text)

        assert result.tools_called
        assert len(result.tool_calls) == 2

    def test_no_tool_call(self, parser):
        """Test text without tool calls."""
        text = "I can help you with that question."
        result = parser.extract_tool_calls(text)

        assert not result.tools_called

    def test_streaming_dedups_multi_tool_xml(self, parser):
        """Regression for #181: streaming multi-tool XML emits each call once.

        Pre-fix: every closing </tool_call> re-emitted ALL tool calls found
        so far, with index recounted from 0. OpenAI client merge-by-index
        then concatenated names ('readread') and args ('{}{}').
        """
        chunks = [
            "<tool_call>",
            '{"name":"read","arguments":{}}',
            "</tool_call>",
            "<tool_call>",
            '{"name":"write","arguments":{}}',
            "</tool_call>",
        ]
        emitted = []
        prev = ""
        for c in chunks:
            cur = prev + c
            r = parser.extract_tool_calls_streaming(
                previous_text=prev,
                current_text=cur,
                delta_text=c,
                request={"tools": []},
            )
            if r and "tool_calls" in r:
                emitted.extend(r["tool_calls"])
            prev = cur

        assert len(emitted) == 2, f"expected 2 deltas, got {len(emitted)}"
        assert [tc["function"]["name"] for tc in emitted] == ["read", "write"]
        assert [tc["index"] for tc in emitted] == [0, 1]

    def test_streaming_dedups_multi_tool_bracket(self, parser):
        """Regression for #181: bracket format also dedups."""
        chunks = [
            '[Calling tool: read({"x":1})]',
            '[Calling tool: write({"y":2})]',
        ]
        emitted = []
        prev = ""
        for c in chunks:
            cur = prev + c
            r = parser.extract_tool_calls_streaming(
                previous_text=prev,
                current_text=cur,
                delta_text=c,
                request={"tools": []},
            )
            if r and "tool_calls" in r:
                emitted.extend(r["tool_calls"])
            prev = cur

        assert [tc["function"]["name"] for tc in emitted] == ["read", "write"]
        assert [tc["index"] for tc in emitted] == [0, 1]

    def test_streaming_single_tool_unchanged(self, parser):
        """Regression guard: single tool case (the common path) still works."""
        chunks = [
            "<tool_call>",
            '{"name":"only","arguments":{"k":"v"}}',
            "</tool_call>",
        ]
        emitted = []
        prev = ""
        for c in chunks:
            cur = prev + c
            r = parser.extract_tool_calls_streaming(
                previous_text=prev,
                current_text=cur,
                delta_text=c,
                request={"tools": []},
            )
            if r and "tool_calls" in r:
                emitted.extend(r["tool_calls"])
            prev = cur

        assert len(emitted) == 1
        assert emitted[0]["function"]["name"] == "only"
        assert emitted[0]["index"] == 0

    def test_streaming_malformed_first_tool_does_not_desync_indices(self, parser):
        """Codex-flagged: a malformed JSON tool body must not shift indices.

        Pre-fix code used raw close-marker counts as the dedup offset. If a
        close marker appeared but the JSON inside failed to parse, the count
        incremented but the emitted-call list didn't, so the next valid tool
        would receive a wrong index (or be sliced away). We now base the
        offset on len(prev_parsed.tool_calls) so malformed entries don't
        desynchronise valid ones.
        """
        # NOT_JSON is an unquoted bareword: regex still isolates the {...}
        # block but json.loads rejects it. Avoids the unrelated regex-fusion
        # case where a stray '{' in body 1 swallows body 2.
        chunks = [
            "<tool_call>",
            '{"name":"broken","arguments":NOT_JSON}',
            "</tool_call>",
            "<tool_call>",
            '{"name":"valid","arguments":{}}',
            "</tool_call>",
        ]
        emitted = []
        prev = ""
        for c in chunks:
            cur = prev + c
            r = parser.extract_tool_calls_streaming(
                previous_text=prev,
                current_text=cur,
                delta_text=c,
                request={"tools": []},
            )
            if r and "tool_calls" in r:
                emitted.extend(r["tool_calls"])
            prev = cur

        # Malformed first tool is silently dropped; the valid second tool
        # must still emit at index 0 (not 1, which would break OpenAI clients
        # that expect contiguous indexing from 0).
        assert len(emitted) == 1
        assert emitted[0]["function"]["name"] == "valid"
        assert emitted[0]["index"] == 0


class TestHermesToolParser:
    """Test the Hermes tool parser."""

    @pytest.fixture
    def parser(self):
        return HermesToolParser()

    def test_tool_call_format(self, parser):
        """Test parsing Hermes format."""
        text = (
            '<tool_call>{"name": "search", "arguments": {"query": "test"}}</tool_call>'
        )
        result = parser.extract_tool_calls(text)

        assert result.tools_called
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0]["name"] == "search"

    def test_with_reasoning(self, parser):
        """Test with reasoning block."""
        text = '<tool_call_reasoning>I need to search for this</tool_call_reasoning><tool_call>{"name": "search", "arguments": {}}</tool_call>'
        result = parser.extract_tool_calls(text)

        assert result.tools_called
        assert "Reasoning" in (result.content or "")


class TestEdgeCases:
    """Test edge cases and error handling."""

    def test_empty_input(self):
        """Test with empty input."""
        parsers = [
            QwenToolParser(),
            HermesToolParser(),
        ]
        for parser in parsers:
            result = parser.extract_tool_calls("")
            assert not result.tools_called


class TestThinkTagStripping:
    """Test <think> tag stripping in tool parsers (Issue #26)."""

    def test_strip_think_tags_utility(self):
        """Test the strip_think_tags static method."""
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        # Basic stripping
        text = "<think>Let me analyze this</think>The answer is 42"
        assert ToolParser.strip_think_tags(text) == "The answer is 42"

        # Multi-line thinking
        text = "<think>Step 1\nStep 2\nStep 3</think>Result"
        assert ToolParser.strip_think_tags(text) == "Result"

        # No think tags
        text = "Just regular text"
        assert ToolParser.strip_think_tags(text) == "Just regular text"

        # Empty think tags
        text = "<think></think>Content"
        assert ToolParser.strip_think_tags(text) == "Content"

    def test_hermes_with_think_tags(self):
        """Test Hermes parser strips think tags before parsing tool calls."""
        parser = HermesToolParser()

        # Model output with think tags AND tool call (Ring-Mini-Linear-2.0 style)
        output = """<think>Let me search for that information.</think>
<tool_call>{"name": "search", "arguments": {"query": "weather"}}</tool_call>"""

        result = parser.extract_tool_calls(output)
        assert result.tools_called is True
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0]["name"] == "search"

    def test_qwen_with_think_tags(self):
        """Test Qwen parser strips think tags before parsing tool calls."""
        parser = QwenToolParser()

        # Model output with think tags AND tool call
        output = """<think>I need to get the weather data.</think>
[Calling tool: get_weather({"city": "Tokyo"})]"""

        result = parser.extract_tool_calls(output)
        assert result.tools_called is True
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0]["name"] == "get_weather"

    def test_think_tags_with_no_tool_call(self):
        """Test that think tags are stripped even when no tool call is present."""
        parser = HermesToolParser()

        output = "<think>Let me think about this</think>The answer is 42."
        result = parser.extract_tool_calls(output)

        assert result.tools_called is False
        assert result.content == "The answer is 42."


class TestQwen3CoderParser:
    """Test Qwen3-Coder tool call parsing (Issue #47)."""

    def test_qwen3_coder_alias_registered(self):
        """Test that qwen3_coder is registered as an alias for HermesToolParser."""
        parser_cls = ToolParserManager.get_tool_parser("qwen3_coder")
        assert parser_cls == HermesToolParser

    def test_qwen3_coder_xml_format(self):
        """Test parsing Qwen3-Coder XML format (Nemotron-style)."""
        parser = HermesToolParser()
        text = (
            "<tool_call>\n"
            "<function=get_weather>\n"
            "<parameter=city>Paris</parameter>\n"
            "<parameter=units>celsius</parameter>\n"
            "</function>\n"
            "</tool_call>"
        )
        result = parser.extract_tool_calls(text)

        assert result.tools_called
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0]["name"] == "get_weather"
        args = json.loads(result.tool_calls[0]["arguments"])
        assert args["city"] == "Paris"
        assert args["units"] == "celsius"

    def test_qwen3_coder_with_think_tags(self):
        """Test Qwen3-Coder XML format with think tags."""
        parser = HermesToolParser()
        text = (
            "<think>I need to read this file.</think>\n"
            "<tool_call>\n"
            "<function=read_file>\n"
            "<parameter=path>/src/main.py</parameter>\n"
            "</function>\n"
            "</tool_call>"
        )
        result = parser.extract_tool_calls(text)

        assert result.tools_called
        assert result.tool_calls[0]["name"] == "read_file"
        args = json.loads(result.tool_calls[0]["arguments"])
        assert args["path"] == "/src/main.py"

    def test_qwen3_coder_multiline_parameter(self):
        """Test Qwen3-Coder with multi-line parameter values (code)."""
        parser = HermesToolParser()
        text = (
            "<tool_call>\n"
            "<function=write_file>\n"
            "<parameter=path>/src/hello.py</parameter>\n"
            "<parameter=content>def hello():\n"
            "    print('hello')\n</parameter>\n"
            "</function>\n"
            "</tool_call>"
        )
        result = parser.extract_tool_calls(text)

        assert result.tools_called
        assert result.tool_calls[0]["name"] == "write_file"
        args = json.loads(result.tool_calls[0]["arguments"])
        assert args["path"] == "/src/hello.py"
        assert "def hello():" in args["content"]

    def test_bare_function_without_tool_call_wrapper(self):
        """Test bare <function=...> blocks without <tool_call> wrapper."""
        parser = HermesToolParser()
        text = "<function=get_weather><parameter=city>Berlin</parameter></function>"
        result = parser.extract_tool_calls(text)

        assert result.tools_called
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0]["name"] == "get_weather"
        args = json.loads(result.tool_calls[0]["arguments"])
        assert args["city"] == "Berlin"

    def test_bare_multi_function_without_wrapper(self):
        """Test multiple bare <function=...> blocks without <tool_call> wrapper."""
        parser = HermesToolParser()
        text = (
            "<function=read_file>"
            "<parameter=path>/a.py</parameter>"
            "</function>\n"
            "<function=write_file>"
            "<parameter=path>/b.py</parameter>"
            "<parameter=content>hello</parameter>"
            "</function>"
        )
        result = parser.extract_tool_calls(text)

        assert result.tools_called
        assert len(result.tool_calls) == 2
        assert result.tool_calls[0]["name"] == "read_file"
        assert result.tool_calls[1]["name"] == "write_file"

    def test_qwen3_coder_multiple_tool_calls(self):
        """Test multiple Nemotron XML tool calls (multi-tool scenario)."""
        parser = HermesToolParser()
        text = (
            "<tool_call>\n"
            "<function=read_file>\n"
            "<parameter=path>/src/main.py</parameter>\n"
            "</function>\n"
            "</tool_call>\n"
            "<tool_call>\n"
            "<function=list_files>\n"
            "<parameter=directory>/src</parameter>\n"
            "</function>\n"
            "</tool_call>"
        )
        result = parser.extract_tool_calls(text)

        assert result.tools_called
        assert len(result.tool_calls) == 2
        assert result.tool_calls[0]["name"] == "read_file"
        assert result.tool_calls[1]["name"] == "list_files"


class TestQwen3XmlAlias:
    """Regression: qwen3_xml must resolve to QwenToolParser, not the Coder parser.

    Issue #175: qwen3_xml was aliased to Qwen3CoderToolParser, which expects
    <function=NAME> tags. Qwen3 reasoning models emit <tool_call>{json}</tool_call>
    instead, so the Coder parser silently returned tools_called=False, causing
    streaming chat completions to fail with finish_reason: error.
    """

    def test_qwen3_xml_resolves_to_qwen_parser(self):
        parser_cls = ToolParserManager.get_tool_parser("qwen3_xml")
        assert parser_cls is QwenToolParser, (
            f"qwen3_xml must resolve to QwenToolParser (handles JSON-in-<tool_call>), "
            f"got {parser_cls.__name__}"
        )

    def test_qwen3_xml_parses_reasoning_model_format(self):
        parser = ToolParserManager.get_tool_parser("qwen3_xml")(tokenizer=None)
        text = (
            '<tool_call>{"name": "read", "arguments": {"filePath": "/etc/hostname"}}'
            "</tool_call>"
        )
        result = parser.extract_tool_calls(text, request=None)
        assert result.tools_called, (
            "qwen3_xml must parse <tool_call>{json}</tool_call> "
            "(Qwen3 reasoning model output)"
        )
        assert result.tool_calls[0]["name"] == "read"
        args = json.loads(result.tool_calls[0]["arguments"])
        assert args["filePath"] == "/etc/hostname"

    def test_qwen3_xml_streaming_emits_tool_call(self):
        """Streaming path: feed reasoning-model output token-by-token through qwen3_xml.

        This is the path that was crashing in the user's bug report (raw token IDs
        leaking into 'Internal error during streaming'). The bug surfaced because
        the Coder parser's streaming logic doesn't recognize JSON-in-<tool_call>
        and either raised or silently dropped emissions. With qwen3_xml routed to
        QwenToolParser, the streaming path must successfully emit a tool_call
        delta when the closing </tool_call> token arrives.
        """
        parser = ToolParserManager.get_tool_parser("qwen3_xml")(tokenizer=None)
        # Mimic real tokenizer chunks (Qwen tokenizes <tool_call> and </tool_call>
        # as single tokens, JSON content as several tokens).
        chunks = [
            "<tool_call>",
            '{"name": ',
            '"read", ',
            '"arguments": ',
            '{"filePath": ',
            '"/etc/hostname"}}',
            "</tool_call>",
        ]
        emitted_tool_calls = []
        prev = ""
        for chunk in chunks:
            current = prev + chunk
            result = parser.extract_tool_calls_streaming(
                previous_text=prev,
                current_text=current,
                delta_text=chunk,
                request={"tools": [{"type": "function", "function": {"name": "read"}}]},
            )
            if result and "tool_calls" in result:
                emitted_tool_calls.extend(result["tool_calls"])
            prev = current
        assert len(emitted_tool_calls) >= 1, (
            "streaming qwen3_xml must emit at least one tool_call delta"
        )
        assert emitted_tool_calls[-1]["function"]["name"] == "read"
        args = json.loads(emitted_tool_calls[-1]["function"]["arguments"])
        assert args["filePath"] == "/etc/hostname"


class TestHermesStreamingFixes:
    """Test streaming fixes for Hermes parser (Issue #47)."""

    def test_streaming_complete_tool_call(self):
        """Test streaming with complete tool call in accumulated text."""
        parser = HermesToolParser()

        # Simulate token-by-token streaming
        # Token 1: regular content
        r = parser.extract_tool_calls_streaming(
            previous_text="",
            current_text="Sure, let me check.",
            delta_text="Sure, let me check.",
        )
        assert r == {"content": "Sure, let me check."}

        # Token 2: opening tag
        r = parser.extract_tool_calls_streaming(
            previous_text="Sure, let me check.",
            current_text='Sure, let me check.<tool_call>{"name":',
            delta_text='<tool_call>{"name":',
        )
        assert r is None  # Inside tool call, suppress

        # Token 3: more JSON
        r = parser.extract_tool_calls_streaming(
            previous_text='Sure, let me check.<tool_call>{"name":',
            current_text='Sure, let me check.<tool_call>{"name": "search", "arguments": {"q": "test"}}',
            delta_text=' "search", "arguments": {"q": "test"}}',
        )
        assert r is None  # Still inside, no closing tag yet

        # Token 4: closing tag
        r = parser.extract_tool_calls_streaming(
            previous_text='Sure, let me check.<tool_call>{"name": "search", "arguments": {"q": "test"}}',
            current_text='Sure, let me check.<tool_call>{"name": "search", "arguments": {"q": "test"}}</tool_call>',
            delta_text="</tool_call>",
        )
        assert r is not None
        assert "tool_calls" in r
        assert r["tool_calls"][0]["function"]["name"] == "search"

    def test_streaming_split_closing_tag(self):
        """Test that </tool_call> split across deltas is detected via current_text."""
        parser = HermesToolParser()

        # Accumulated text has <tool_call> but </tool_call is split
        r = parser.extract_tool_calls_streaming(
            previous_text='<tool_call>{"name": "func", "arguments": {}}',
            current_text='<tool_call>{"name": "func", "arguments": {}}</tool_call',
            delta_text="</tool_call",
        )
        # Not yet complete (missing >)
        assert r is None

        # Now the > arrives, completing </tool_call>
        r = parser.extract_tool_calls_streaming(
            previous_text='<tool_call>{"name": "func", "arguments": {}}</tool_call',
            current_text='<tool_call>{"name": "func", "arguments": {}}</tool_call>',
            delta_text=">",
        )
        assert r is not None
        assert "tool_calls" in r
        assert r["tool_calls"][0]["function"]["name"] == "func"

    def test_streaming_content_after_tool_call(self):
        """Test that content after </tool_call> is not suppressed."""
        parser = HermesToolParser()

        # Complete tool call already in text
        full = '<tool_call>{"name": "func", "arguments": {}}</tool_call>'
        r = parser.extract_tool_calls_streaming(
            previous_text=full[:-1],  # everything except last >
            current_text=full,
            delta_text=">",
        )
        assert "tool_calls" in r

        # Now content comes after the tool call
        r = parser.extract_tool_calls_streaming(
            previous_text=full,
            current_text=full + "\nHere is the result.",
            delta_text="\nHere is the result.",
        )
        # Should NOT be suppressed
        assert r is not None
        assert r.get("content") == "\nHere is the result."

    def test_streaming_nemotron_xml_format(self):
        """Test streaming with Qwen3-Coder/Nemotron XML format."""
        parser = HermesToolParser()

        chunks = [
            "<tool_call>\n",
            "<function=get_weather>\n",
            "<parameter=city>London</parameter>\n",
            "</function>\n",
            "</tool_call>",
        ]

        accumulated = ""
        tool_calls_found = False
        for chunk in chunks:
            prev = accumulated
            accumulated += chunk
            r = parser.extract_tool_calls_streaming(
                previous_text=prev,
                current_text=accumulated,
                delta_text=chunk,
            )
            if r is not None and "tool_calls" in r:
                tool_calls_found = True
                assert r["tool_calls"][0]["function"]["name"] == "get_weather"
                break

        assert tool_calls_found, "Tool call should have been detected"

    def test_streaming_no_false_positives(self):
        """Test that regular text with < doesn't trigger false positives."""
        parser = HermesToolParser()

        r = parser.extract_tool_calls_streaming(
            previous_text="",
            current_text="Use x < 10 and y > 5",
            delta_text="Use x < 10 and y > 5",
        )
        assert r == {"content": "Use x < 10 and y > 5"}

    def test_streaming_multi_tool_calls(self):
        """Test streaming with two sequential tool calls (Issue #47)."""
        parser = HermesToolParser()

        # First tool call arrives token by token
        chunks = [
            '<tool_call>{"name": "read_file", "arguments": {"path": "/a.py"}}',
            "</tool_call>",
            "\n",
            '<tool_call>{"name": "list_dir", "arguments": {"dir": "/src"}}',
            "</tool_call>",
        ]

        accumulated = ""
        emitted_calls = []
        for chunk in chunks:
            prev = accumulated
            accumulated += chunk
            r = parser.extract_tool_calls_streaming(
                previous_text=prev,
                current_text=accumulated,
                delta_text=chunk,
            )
            if r is not None and "tool_calls" in r:
                emitted_calls.extend(r["tool_calls"])

        assert len(emitted_calls) == 2
        assert emitted_calls[0]["function"]["name"] == "read_file"
        assert emitted_calls[1]["function"]["name"] == "list_dir"
        # Verify indexes are correct
        assert emitted_calls[0]["index"] == 0
        assert emitted_calls[1]["index"] == 1

    def test_streaming_multi_tool_no_duplicates(self):
        """Test that completed tool calls are not re-emitted on second completion."""
        parser = HermesToolParser()

        first_complete = '<tool_call>{"name": "func1", "arguments": {}}</tool_call>'
        # After first tool call is emitted, content between calls passes through
        between = "\n"
        second_start = '<tool_call>{"name": "func2", "arguments": {}}'
        second_end = "</tool_call>"

        # First tool call completed
        r1 = parser.extract_tool_calls_streaming(
            previous_text=first_complete[:-1],
            current_text=first_complete,
            delta_text=">",
        )
        assert r1 is not None and "tool_calls" in r1
        assert len(r1["tool_calls"]) == 1
        assert r1["tool_calls"][0]["function"]["name"] == "func1"

        # Whitespace between
        r2 = parser.extract_tool_calls_streaming(
            previous_text=first_complete,
            current_text=first_complete + between,
            delta_text=between,
        )
        assert r2 == {"content": between}

        # Second tool call building (inside block, suppress)
        r3 = parser.extract_tool_calls_streaming(
            previous_text=first_complete + between,
            current_text=first_complete + between + second_start,
            delta_text=second_start,
        )
        assert r3 is None  # Inside incomplete second tool call

        # Second tool call completed
        r4 = parser.extract_tool_calls_streaming(
            previous_text=first_complete + between + second_start,
            current_text=first_complete + between + second_start + second_end,
            delta_text=second_end,
        )
        assert r4 is not None and "tool_calls" in r4
        assert len(r4["tool_calls"]) == 1  # Only the NEW tool call
        assert r4["tool_calls"][0]["function"]["name"] == "func2"
        assert r4["tool_calls"][0]["index"] == 1  # Second index

    def test_streaming_multi_nemotron_xml(self):
        """Test streaming with multiple Nemotron XML tool calls."""
        parser = HermesToolParser()

        chunks = [
            "<tool_call>\n<function=read_file>\n",
            "<parameter=path>/a.py</parameter>\n",
            "</function>\n</tool_call>\n",
            "<tool_call>\n<function=write_file>\n",
            "<parameter=path>/b.py</parameter>\n",
            "<parameter=content>hello</parameter>\n",
            "</function>\n</tool_call>",
        ]

        accumulated = ""
        emitted_calls = []
        for chunk in chunks:
            prev = accumulated
            accumulated += chunk
            r = parser.extract_tool_calls_streaming(
                previous_text=prev,
                current_text=accumulated,
                delta_text=chunk,
            )
            if r is not None and "tool_calls" in r:
                emitted_calls.extend(r["tool_calls"])

        assert len(emitted_calls) == 2
        assert emitted_calls[0]["function"]["name"] == "read_file"
        assert emitted_calls[1]["function"]["name"] == "write_file"

    def test_streaming_bare_function_blocks(self):
        """Test streaming with bare <function= blocks without <tool_call> wrapper."""
        parser = HermesToolParser()

        chunks = [
            "<function=read_file>",
            "<parameter=path>/src/main.py</parameter>",
            "</function>",
        ]

        accumulated = ""
        tool_calls_found = False
        for chunk in chunks:
            prev = accumulated
            accumulated += chunk
            r = parser.extract_tool_calls_streaming(
                previous_text=prev,
                current_text=accumulated,
                delta_text=chunk,
            )
            if r is not None and "tool_calls" in r:
                tool_calls_found = True
                assert r["tool_calls"][0]["function"]["name"] == "read_file"
                args = json.loads(r["tool_calls"][0]["function"]["arguments"])
                assert args["path"] == "/src/main.py"
                break

        assert tool_calls_found, "Bare function block should have been detected"

    def test_streaming_bare_multi_function_blocks(self):
        """Test streaming with multiple bare <function= blocks."""
        parser = HermesToolParser()

        chunks = [
            "<function=func1><parameter=a>1</parameter></function>",
            "\n",
            "<function=func2>",
            "<parameter=b>2</parameter>",
            "</function>",
        ]

        accumulated = ""
        emitted_calls = []
        for chunk in chunks:
            prev = accumulated
            accumulated += chunk
            r = parser.extract_tool_calls_streaming(
                previous_text=prev,
                current_text=accumulated,
                delta_text=chunk,
            )
            if r is not None and "tool_calls" in r:
                emitted_calls.extend(r["tool_calls"])

        assert len(emitted_calls) == 2
        assert emitted_calls[0]["function"]["name"] == "func1"
        assert emitted_calls[1]["function"]["name"] == "func2"


class TestTextFormatToolCallFallback:
    """Test text-format tool call fallback parser.

    Models at low quantization (e.g., 4-bit) sometimes degrade after multiple
    tool call rounds and output tool calls as plain text instead of structured
    format.  The base ToolParser class provides general detection and extraction
    for two common degradation patterns:

    Variant 1 (KV style):  [Calling tool="name" key="value" ...]
    Variant 2 (function call style):  [Calling tool: name({"key": "value"})]
    """

    # -- Fixtures --

    @pytest.fixture
    def hermes_parser(self):
        return HermesToolParser()

    # -- Helpers --

    def _assert_tool_call(self, tc, name, **expected_args):
        """Assert a tool call dict has the expected name and arguments."""
        assert tc["id"].startswith("call_"), (
            f"Tool call id should start with 'call_', got {tc['id']}"
        )
        assert tc["name"] == name
        args = json.loads(tc["arguments"])
        for k, v in expected_args.items():
            assert args[k] == v, f"Expected {k}={v!r}, got {args[k]!r}"

    # =================================================================
    # Variant 1 - KV style
    # =================================================================

    def test_variant1_simple_kv(self):
        """Test basic KV-style text-format tool call."""
        text = '[Calling tool="web_search" query="weather palo alto"]'
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 1
        self._assert_tool_call(calls[0], "web_search", query="weather palo alto")

    def test_variant1_multiple_params(self):
        """Test KV-style with multiple parameters."""
        text = '[Calling tool="exec" command="ls -la" timeout="5000"]'
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 1
        self._assert_tool_call(calls[0], "exec", command="ls -la")
        args = json.loads(calls[0]["arguments"])
        # timeout should be parsed as int by json.loads
        assert args["timeout"] == 5000

    def test_variant1_escaped_quotes(self):
        """Test KV-style with escaped quotes in value."""
        text = r'[Calling tool="exec" command="curl -s \"https://example.com\""]'
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 1
        assert calls[0]["name"] == "exec"
        args = json.loads(calls[0]["arguments"])
        assert "https://example.com" in args["command"]

    def test_variant1_single_param(self):
        """Test KV-style with a single parameter."""
        text = '[Calling tool="read" path="/tmp/file.txt"]'
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 1
        self._assert_tool_call(calls[0], "read", path="/tmp/file.txt")

    # =================================================================
    # Variant 2 - Function call style
    # =================================================================

    def test_variant2_json_args(self):
        """Test function-call style with JSON arguments."""
        text = '[Calling tool: process({"action":"poll", "sessionId":"clear-haven", "timeout":5000})]'
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 1
        self._assert_tool_call(
            calls[0],
            "process",
            action="poll",
            sessionId="clear-haven",
            timeout=5000,
        )

    def test_variant2_simple_json(self):
        """Test function-call style with simple JSON."""
        text = '[Calling tool: web_search({"query":"weather tonight"})]'
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 1
        self._assert_tool_call(calls[0], "web_search", query="weather tonight")

    def test_variant2_single_key(self):
        """Test function-call style with single key."""
        text = '[Calling tool: exec({"command":"python3 --version"})]'
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 1
        self._assert_tool_call(calls[0], "exec", command="python3 --version")

    # =================================================================
    # Edge cases
    # =================================================================

    def test_inside_think_tags(self):
        """Text-format tool call embedded inside <think>...</think> tags."""
        text = '<think>I should search for this.\n[Calling tool="web_search" query="test"]</think>'
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        # The raw extraction should still find it inside think tags
        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 1
        self._assert_tool_call(calls[0], "web_search", query="test")

    def test_content_before(self):
        """Text-format tool call with content BEFORE it."""
        text = 'Let me check the weather for you. [Calling tool="web_search" query="weather"]'
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 1
        self._assert_tool_call(calls[0], "web_search", query="weather")

    def test_content_after(self):
        """Text-format tool call with content AFTER it."""
        text = '[Calling tool="web_search" query="weather"] I will get the results.'
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 1
        self._assert_tool_call(calls[0], "web_search", query="weather")

    def test_multiple_text_format_calls(self):
        """Multiple text-format tool calls in same output."""
        text = (
            '[Calling tool="web_search" query="weather"]\n'
            '[Calling tool="exec" command="date"]'
        )
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 2
        assert calls[0]["name"] == "web_search"
        assert calls[1]["name"] == "exec"

    def test_mixed_xml_and_text_format(self):
        """Mixed: one XML tool call + one text-format tool call in same output."""
        # The text-format extractor only extracts text-format calls,
        # not XML ones.  Verify it does not pick up the XML call.
        text = (
            '<minimax:tool_call><invoke name="func1"><parameter name="a">1</parameter></invoke></minimax:tool_call>\n'
            '[Calling tool="func2" b="2"]'
        )
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 1
        assert calls[0]["name"] == "func2"

    def test_unicode_in_arguments(self):
        """Unicode in arguments (Chinese, emoji)."""
        text = '[Calling tool="translate" text="\u4f60\u597d\u4e16\u754c"]'
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 1
        args = json.loads(calls[0]["arguments"])
        assert args["text"] == "\u4f60\u597d\u4e16\u754c"

    def test_unicode_emoji_in_arguments(self):
        """Emoji characters in arguments."""
        text = '[Calling tool="react" emoji="\U0001f680\U0001f525"]'
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 1
        args = json.loads(calls[0]["arguments"])
        assert args["emoji"] == "\U0001f680\U0001f525"

    def test_variant2_nested_json(self):
        """Nested JSON in variant 2."""
        text = '[Calling tool: configure({"key": {"nested": true}})]'
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 1
        args = json.loads(calls[0]["arguments"])
        assert args["key"]["nested"] is True

    def test_has_text_format_tool_call_true(self):
        """has_text_format_tool_call() returns True for matching text."""
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        assert ToolParser.has_text_format_tool_call('[Calling tool="web_search" q="x"]')
        assert ToolParser.has_text_format_tool_call('[Calling tool: func({"a":1})]')

    def test_has_text_format_tool_call_false(self):
        """has_text_format_tool_call() returns False for non-matching text."""
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        assert not ToolParser.has_text_format_tool_call("Hello, world!")
        assert not ToolParser.has_text_format_tool_call("[Calling out to the void]")
        assert not ToolParser.has_text_format_tool_call(
            '<tool_call>{"name":"f"}</tool_call>'
        )

    def test_has_pending_tool_call_text_format(self):
        """has_pending_tool_call() on base ToolParser returns True for text-format."""
        # Use a concrete subclass (HermesToolParser inherits from ToolParser)
        parser = HermesToolParser()
        assert parser.has_pending_tool_call('[Calling tool="search" q="test"]')

    def test_variant1_no_params_should_not_match(self):
        """Variant 1 with no params (just tool name) should NOT produce a tool call."""
        # The pattern requires at least one key="value" param, and extract
        # also checks `if arguments:` before appending.
        text = '[Calling tool="web_search"]'
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 0

    def test_partial_incomplete_should_not_match(self):
        """Partial/incomplete text-format (missing closing ']') should NOT match."""
        text = '[Calling tool="web_search" query="test"'
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 0

    def test_both_variants_in_same_text(self):
        """Both variant 1 and variant 2 in the same text."""
        text = (
            '[Calling tool="read" path="/tmp/data.txt"]\n'
            '[Calling tool: exec({"command":"cat /tmp/data.txt"})]'
        )
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 2
        names = {c["name"] for c in calls}
        assert names == {"read", "exec"}
        # Verify unique IDs
        ids = [c["id"] for c in calls]
        assert len(ids) == len(set(ids))

    # =================================================================
    # General ToolParser integration
    # =================================================================

    def test_hermes_inherits_has_pending_text_format(self, hermes_parser):
        """HermesToolParser inherits has_pending_tool_call detecting text-format."""
        assert hermes_parser.has_pending_tool_call(
            '[Calling tool="search" query="test"]'
        )

    def test_hermes_has_pending_false_for_plain_text(self, hermes_parser):
        """HermesToolParser has_pending_tool_call returns False for plain text."""
        assert not hermes_parser.has_pending_tool_call("Just a regular message.")

    def test_variant2_empty_json_should_not_match(self):
        """Variant 2 with empty JSON object should NOT produce a tool call."""
        text = "[Calling tool: func({})]"
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        # Empty dict check: `if isinstance(arguments, dict) and arguments:`
        assert len(calls) == 0

    def test_tool_call_ids_are_unique(self):
        """Each extracted tool call gets a unique ID."""
        text = (
            '[Calling tool="func1" a="1"]\n'
            '[Calling tool="func2" b="2"]\n'
            '[Calling tool: func3({"c":"3"})]'
        )
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        calls = ToolParser.extract_text_format_tool_calls(text)
        assert len(calls) == 3
        ids = [c["id"] for c in calls]
        assert len(ids) == len(set(ids)), "All tool call IDs should be unique"

    def test_arguments_are_valid_json(self):
        """Extracted arguments field is always valid JSON."""
        texts = [
            '[Calling tool="read" path="/tmp/file.txt"]',
            '[Calling tool: search({"query":"hello world"})]',
            '[Calling tool="exec" command="echo hello" timeout="30"]',
        ]
        from vllm_mlx.tool_parsers.abstract_tool_parser import ToolParser

        for text in texts:
            calls = ToolParser.extract_text_format_tool_calls(text)
            for call in calls:
                parsed = json.loads(call["arguments"])
                assert isinstance(parsed, dict)


class TestGenericToolCallParsing:
    """OpenAI-translation helpers: schema-aware coercion + bare `Calling tool:` parsing."""

    def test_bare_calling_tool_is_parsed_and_removed(self):
        text = (
            "Thinking first.\n"
            'Calling tool: write({"filePath": "/tmp/app.tsx", "content": "ok"})'
        )

        cleaned_text, tool_calls = parse_tool_calls(text)

        assert cleaned_text == "Thinking first."
        assert tool_calls is not None
        assert len(tool_calls) == 1
        assert tool_calls[0].function.name == "write"
        args = json.loads(tool_calls[0].function.arguments)
        assert args == {"filePath": "/tmp/app.tsx", "content": "ok"}

    def test_tool_arguments_decode_stringified_arrays(self):
        text = (
            'Calling tool: todowrite({"todos": '
            '"[{\\"content\\": \\"Initialize\\", \\"status\\": \\"in_progress\\"}]"'
            "})"
        )

        _, tool_calls = parse_tool_calls(text)

        assert tool_calls is not None
        args = json.loads(tool_calls[0].function.arguments)
        assert isinstance(args["todos"], list)
        assert args["todos"][0]["content"] == "Initialize"

    def test_tool_arguments_coerce_schema_numbers(self):
        request = {
            "tools": [
                {
                    "type": "function",
                    "function": {
                        "name": "bash",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "command": {"type": "string"},
                                "timeout": {"type": "number"},
                            },
                        },
                    },
                }
            ]
        }
        text = 'Calling tool: bash({"command": "npm test", "timeout": "60000"})'

        _, tool_calls = parse_tool_calls(text, request)

        assert tool_calls is not None
        args = json.loads(tool_calls[0].function.arguments)
        assert args["command"] == "npm test"
        assert args["timeout"] == 60000.0
