# Benchmarks

Performance benchmarks for qmlx on Apple Silicon.

## Benchmark Types

- [LLM Benchmarks](llm.md) - Text generation performance

## Quick Commands

```bash
# Engine comparison benchmark (qmlx vs ollama)
python scripts/bench_vs_ollama.py

# Or benchmark every model listed for the README at once
python examples/benchmark_all_models.py
```

## Standalone Test Defaults

Standalone benchmark test scripts have built-in default models, so you can run:

```bash
python tests/test_continuous_batching.py
python tests/test_prefix_cache.py
```

Defaults:
- `tests/test_continuous_batching.py` → `mlx-community/Qwen3-8B-6bit`
- `tests/test_prefix_cache.py` → `mlx-community/Qwen3-0.6B-8bit`

To test different models, use the optional `--model` flag:

```bash
python tests/test_continuous_batching.py --model mlx-community/Qwen3-0.6B-8bit
python tests/test_prefix_cache.py --model mlx-community/Qwen3-8B-6bit
```

## Hardware

Benchmarks have been collected on the following Apple Silicon configurations:

| Chip | Memory | Python |
|------|--------|--------|
| Apple M4 Max | 128 GB unified | 3.13 |
| Apple M1 Max | 64 GB unified | 3.12 |

Results will vary on different Apple Silicon chips.

## Contributing Benchmarks

If you have a different Apple Silicon chip, please share your results:

```bash
python scripts/bench_vs_ollama.py | tee results.txt
```

Open an issue with your results at [GitHub Issues](https://github.com/marzukia/qMLX/issues).
