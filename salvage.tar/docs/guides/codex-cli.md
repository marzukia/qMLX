# Codex CLI

Use [OpenAI's Codex CLI](https://github.com/openai/codex) with qmlx
as the local backend. Codex is a Rust-based coding agent that talks to
the OpenAI Responses API (`POST /v1/responses`); qmlx implements
that endpoint as a stateless shim — every Codex turn re-sends the full
conversation history, so no response-store layer is needed on the
server side.

Requires **qmlx >= 0.7.10**.

## TL;DR

```bash
# 1. Install Codex CLI
brew install codex   # or: npm install -g @openai/codex

# 2. Start qmlx with a strong-enough model
qmlx serve qwen3.6-35b-4bit --port 8000

# 3. Point Codex at the local server
qmlx agents codex --setup     # writes ~/.codex/config.toml for you

# 4. Run Codex
codex                              # interactive
codex exec "explain this repo"     # one-shot
```

## Model recommendations

Codex's workflow leans on multi-tool calls + `apply_patch` for file
edits. Small models underperform. On Apple Silicon, in rough order:

| Model | Size | Notes |
|---|---|---|
| `qwen3.6-35b-4bit` | ~20 GB | Recommended workhorse for M3 Max / M4 Pro 24 GB+ |
| `qwen3-coder-30b-4bit` | ~17 GB | Code-specialized; great for narrower coding tasks |
| `qwen3.5-9b-4bit` | ~5 GB | Practical floor — works on 16 GB Macs but expect more retries |

Smaller models (≤8B) tend to hallucinate `apply_patch` shapes; not
recommended.

## Manual config

If `qmlx agents codex --setup` didn't fit your layout (e.g. you
already have a `~/.codex/config.toml`), the relevant block is:

```toml
model = "default"            # or any qmlx alias
model_provider = "qmlx"

[model_providers.qmlx]
name = "qMLX (local)"
base_url = "http://localhost:8000/v1"
```

Codex picks the provider from `model_provider` and resolves its
`base_url` from the matching `[model_providers.NAME]` block.

### With `--api-key` enabled on the server

Current Codex CLI (>= 0.135) reads the credential via **env-var
indirection**, not as an inline literal — Codex's `--strict-config`
rejects `api_key = "..."` as an unknown field. Use `env_key` instead:

```toml
[model_providers.qmlx]
name = "qMLX (local)"
base_url = "http://localhost:8000/v1"
env_key = "QMLX_API_KEY"
```

And in your shell:

```bash
export QMLX_API_KEY=your-secret
```

## Model name passthrough

Codex sends model names like `gpt-5` or `gpt-5-codex` in the request
body even when you've configured a different one. qMLX's route
recognises any `gpt-*` / `claude-*` model name as "the loaded engine,
not a strict alias lookup" — so the request reaches the model you
actually started the server with, instead of 404'ing on the name
mismatch. The response's `model` field carries the loaded model's name
(consistent with the Anthropic-compat route).

This means: **whatever model you start `qmlx serve` with is what
Codex will talk to**, regardless of what Codex thinks it's talking to.

## What's mapped, what's not

The shim is intentionally minimal — it covers Codex's hot path and
nothing more.

**Translated:**

- `instructions` → system message
- `input[]` polymorphic items: `message` / `function_call` /
  `function_call_output` → assistant / tool messages
- `tools` (Responses-flat shape) → Chat-nested tools
- `text.format` JSON-schema → `response_format`
- `max_output_tokens` → `max_tokens`
- SSE: 7 events Codex actually parses (`response.created`,
  `response.output_item.added`, `response.output_text.delta`,
  `response.function_call_arguments.delta`,
  `response.output_item.done`, `response.completed`,
  `response.failed`)

**Not translated (v1):**

- `previous_response_id` → returns 400. Codex doesn't use this field
  (openai/codex#3841 confirms it's not implemented client-side), so the
  400 is a safety net for any other client that tries.
- `reasoning.effort` → ignored. Set thinking on the server with
  `qmlx serve --enable-thinking` instead.
- `input_image` → dropped. Codex doesn't send images.
- Non-function tool types (`web_search`, `code_interpreter`,
  `image_generation`, `file_search`, `computer_use`) → dropped. Codex
  doesn't send these to third-party backends.

## Probing the endpoint

If you want to verify the shim is reachable without booting Codex:

```bash
curl -sS http://localhost:8000/v1/responses \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-5",
    "input": "Say hello in one word.",
    "stream": false
  }' | jq .
```

You should see a `response` object with an `output` array containing a
`message` item. With `--api-key`, add `-H "Authorization: Bearer <key>"`.

## Codex CLI versions

Verified against **Codex CLI 0.136.0** on **qmlx 0.7.12+** with
Qwen3.5-9B and Qwen3.6-27B. Codex 0.135 → 0.136 reshaped the request
in three ways that earlier qmlx releases mishandled:

- the per-turn instruction channel switched from `system` to the new
  Responses-API `developer` role,
- multiple system-equivalent messages are now interleaved with user
  turns, and
- the agent loop terminates silently if the `function_call` item is
  missing — no error, no partial output, just a closed stream.

If you're on qmlx **< 0.7.12** with a recent Codex, you may see
"stream disconnected before completion" or a turn that ends with no
visible output. Upgrade with `qmlx upgrade`.

## Troubleshooting

**Codex says "stream closed before response.completed"** — this should
not happen on qmlx >= 0.7.12 with Codex 0.136. If it does, the
engine likely crashed mid-generation; check the server logs.
Re-running the query usually works.

**Codex 404s on `/v1/responses`** — you're on qmlx < 0.7.10.
Upgrade with `qmlx upgrade` (or `pip install -U qmlx`).

**Codex turn ends with no output** — on qmlx 0.7.10–0.7.11 with
Codex 0.136, tool-call XML was filtered before the parser ran and the
agent loop saw zero items. Fixed in 0.7.12.

**Tool calls don't apply** — make sure `--enable-auto-tool-choice` is
passed when starting the server, and that the model's tool parser is
auto-detected correctly (`qmlx serve ... --log-level DEBUG` shows
it during boot).

**Codex hangs** — first run prompts for sandbox permissions
(Landlock on Linux, Seatbelt on macOS). Accept them in the Codex
prompt; the second run is non-interactive.

## See also

- [Server setup](server.md)
- [Tool calling](tool-calling.md)
- [Reasoning models](reasoning.md)
- Upstream issue [#549](https://github.com/raullenchai/Rapid-MLX/issues/549): the request that drove this integration
