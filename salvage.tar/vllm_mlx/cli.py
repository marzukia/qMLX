#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""
CLI for qmlx (package name: ``vllm_mlx``).

Commands:
    qmlx serve <model> --port 8000    Start OpenAI-compatible server
    qmlx chat <model>                 Interactive chat REPL

Usage:
    qmlx serve qwen3.5-4b-4bit --port 8000
    qmlx chat qwen3.5-4b-4bit
"""

import argparse
import os
import shutil
import sys

from vllm_mlx import _ui as ui
from vllm_mlx._completion import alias_completer

# Project-default mirror for ``QMLX_MODEL_MIRROR`` (consumed by
# ``_try_mirror_prefetch``). Public Cloudflare Worker → R2 bucket, with
# rate-limit + Range-request passthrough. Override with the env var
# (set to an empty string to disable the mirror and force HF Hub).
MIRROR_DEFAULT = "https://models.rapidmlx.com"

def _log_level_choice(value: str) -> str:
    """Argparse ``type`` callable: normalize to upper-case so
    ``--log-level info`` is accepted as ``INFO``. Named (not a lambda)
    so argparse's error messages read sensibly instead of
    ``invalid <lambda> value``.
    """
    return value.upper()


def _auth_feature_str(argv_api_key: str | None) -> str | None:
    """Banner-side renderer for the ``auth: on`` feature line.

    Returns ``"auth: on"`` when the effective API key (argv or env)
    is non-empty, else ``None`` so the banner omits the feature.

    Lives at module scope (not inline in ``serve_command``) so the
    banner gate is directly unit-testable without booting a model.
    Routes through ``server._resolve_api_key`` — the same SSOT the
    server-side enforcement reads — so a refactor of the env-var
    policy cannot drift the banner from the actual auth state.
    Pre-fix the gate was ``if args.api_key`` directly, which printed
    ``auth: off`` for env-only sidecars even though
    ``verify_api_key`` was enforcing (dogfood-v0.8.2 finding #3).
    """
    from vllm_mlx import server as _server

    if _server._resolve_api_key(argv_api_key):
        return "auth: on"
    return None


def _port_arg(value: str) -> int:
    """Argparse ``type`` callable: validate ``--port`` is in [1, 65535].

    Without this, ``qmlx chat --port 99999`` parsed successfully and
    dropped the user into a REPL whose first turn failed with a confusing
    ``Failed to parse: http://127.0.0.1:99999/...``. Validate early so the
    user sees a one-line argparse error instead.
    """
    try:
        port = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"port must be an integer, got {value!r}"
        ) from None
    if not (1 <= port <= 65535):
        raise argparse.ArgumentTypeError(
            f"port must be between 1 and 65535, got {port}"
        )
    return port


def _listen_fd_arg(value: str) -> int:
    """Argparse ``type`` callable: validate ``--listen-fd`` is a sane fd.

    ``--listen-fd`` enables socket activation — the supervisor (launchd,
    systemd, an external parent process) binds the listening socket
    itself and execve's into ``qmlx serve`` with the pre-bound fd.
    This closes the bind→auth TOCTOU window: by the time qmlx
    runs, the socket is already bound but no requests can be accepted
    until ``uvicorn.run`` calls ``accept()`` — at which point the
    FastAPI app (with all route auth dependencies wired) is already
    constructed. See ``vllm_mlx/server.py`` and the regression test
    pinning the bind→auth invariant.

    Accept integers in ``[3, 1023]``:

    * 0/1/2 are stdin/stdout/stderr — never a listening socket.
    * 3 is the conventional "first non-stdio fd" (systemd's
      ``LISTEN_FDS_START`` and launchd both follow this convention).
    * 1023 is the SysV soft-limit ceiling — anything higher is almost
      certainly a typo, not a real fd.
    """
    try:
        fd = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"--listen-fd must be an integer, got {value!r}"
        ) from None
    if not (3 <= fd <= 1023):
        raise argparse.ArgumentTypeError(
            f"--listen-fd must be between 3 and 1023, got {fd}"
        )
    return fd


def _apply_body_receive_timeout_env(server_mod, *, logger=None) -> None:
    """Resolve ``QMLX_BODY_RECEIVE_TIMEOUT_SECONDS`` onto
    ``server_mod._body_receive_timeout_seconds`` (H-14 / F-072
    slow-DoS gate).

    Extracted from ``serve_command`` so the
    ``tests/test_body_receive_timeout.py::test_h14_env_var_override_reduces_timeout``
    case exercises the same code path the production binary runs —
    codex round-2 BLOCKING on PR #786 spotted that an inline-only
    resolver couldn't be unit-tested without duplicating its logic,
    which would silently mask a regression that deleted the wire-up.

    Behaviour:
      * No env var (or empty after strip) → leave the existing
        ``server_mod._body_receive_timeout_seconds`` untouched (the
        module's documented 15 s default).
      * Numeric env value → clamp via ``max(0.0, float(...))`` so
        negative numbers disable the gate without crashing.
      * Non-numeric env value → log a warning and explicitly write
        the 15 s default back to ``server_mod`` (an inherited
        non-default from a prior call would otherwise leak).

    ``server_mod`` is passed in so the test can hand a fresh
    ``vllm_mlx.server`` reference each call without dragging the
    whole import-time CLI prologue along.
    """
    import os

    if logger is None:  # pragma: no cover — tests always pass a logger
        import logging as _logging

        logger = _logging.getLogger(__name__)

    _brt_env_name = "QMLX_BODY_RECEIVE_TIMEOUT_SECONDS"
    _brt_env = os.environ.get(_brt_env_name, "").strip()
    if not _brt_env:
        return
    try:
        server_mod._body_receive_timeout_seconds = max(0.0, float(_brt_env))
    except ValueError:
        # Interpolate the env-var name via ``%s`` instead of baking it
        # into the format string — same false-positive avoidance
        # pattern as the SSE-keepalive block above.
        logger.warning(
            "%s=%r is not a number; falling back to the 15 s default",
            _brt_env_name,
            _brt_env,
        )
        server_mod._body_receive_timeout_seconds = 15.0


def _wildcard_host_aliases() -> frozenset[str]:
    """Strings that name "bind on every interface" rather than a single
    address. Python's ``socket.bind(("", N))`` and ``socket.bind(("0.0.0.0",
    N))`` are equivalent for IPv4; uvicorn historically treats both the
    empty string and ``0.0.0.0`` the same way. We treat them as a single
    class for the loopback-collision pre-flight (codex round-1 MAJOR on
    PR #848: original gate only matched ``"0.0.0.0"`` so ``--host ""``
    could still re-open the dual-bind ambiguity).

    Kept as a function rather than a module constant so the test suite
    can monkey-patch it in case a future host alias (e.g. ``"::"`` once we
    grow IPv6 pre-flight) needs to land without touching every call site.
    """
    return frozenset({"0.0.0.0", ""})


def _is_ipv6_host(host: str) -> bool:
    """Detect IPv6 literal hosts (``::``, ``::1``, ``2001:db8::1`` ...).

    Codex round-1 MED #6 on PR #855: the IPv4-only preflight always
    created an ``AF_INET`` socket, so any valid uvicorn IPv6 bind
    (``--host ::1``, ``--host ::``, etc.) failed ``socket.bind`` and got
    misreported as "port already in use." Detection is colon-based:
    every IPv6 literal contains at least one ``:``, no IPv4 literal /
    DNS name does (``localhost`` is the canonical non-IPv6 with no
    colon). We deliberately keep this purely lexical — a stricter
    ``ipaddress.ip_address`` parse would reject scoped literals
    (``fe80::1%en0``) that uvicorn happily accepts.
    """
    return ":" in host


def _render_port_collision(port: int, display_host: str, *, model: str) -> None:
    """Port-in-use error (issue #51): red titled panel on a TTY, the
    legacy two-line message elsewhere (byte-identical plain output)."""
    body = [
        f"[bold red]Port {port} is already in use on {display_host}.[/bold red]",
        f"Try a different port: qmlx serve {model} --port {port + 1}",
    ]
    ui.panel(
        "Error",
        body,
        plain_lines=[
            f"\n  Error: Port {port} is already in use on {display_host}.",
            f"  Try a different port: qmlx serve {model} --port {port + 1}",
        ],
        style="red",
    )


def _port_preflight_or_die(host: str, port: int, *, model: str) -> None:
    """Probe ``(host, port)`` AND — when ``host`` is a wildcard alias —
    additionally probe ``("127.0.0.1", port)``. Print a friendly error
    and ``sys.exit(1)`` on the first collision.

    Why both: macOS / Linux let a wildcard listener (``0.0.0.0`` or
    ``""``) coexist with a more-specific loopback listener
    (``127.0.0.1``) on the same port. v0.8.2 dogfood finding #2
    reproduced the resulting PortSweep bypass: ``nc -l 127.0.0.1 11812``
    + ``qmlx serve --port 11812`` BOTH succeed, and
    ``curl 127.0.0.1:11812/healthz`` returns HTTP 000 (kernel routes
    loopback to nc, not qmlx). The fix is to explicitly probe the
    loopback address whenever the requested bind is wider than loopback.

    Extracted from ``serve_command`` so the legacy
    ``python -m vllm_mlx.server`` entrypoint can call it too without
    duplicating the wildcard-alias / probe-loop logic — codex round-1
    MAJOR on PR #848 (the dogfood-CLI fix had to land on both supported
    entrypoints to actually close the bypass).

    ``::1`` is intentionally NOT probed when the user binds an IPv4
    wildcard: macOS treats v4 and v6 loopback as distinct stacks, and
    uvicorn's IPv4 bind never collides with an IPv6 listener. When the
    user EXPLICITLY binds an IPv6 host, we switch the probe family to
    ``AF_INET6`` so the bind doesn't spuriously fail (codex round-1
    MED #6 on PR #855 — pre-fix ``--host ::1`` raised ``OSError`` from
    the ``AF_INET`` socket and was misreported as "port already in use").
    """
    import socket

    wildcards = _wildcard_host_aliases()
    if host in wildcards:
        # Probe the requested wildcard FIRST (so a LAN-side port
        # collision still surfaces the user-supplied host name in the
        # error), then probe 127.0.0.1 to catch the loopback shadow.
        hosts_to_probe: tuple[str, ...] = (host, "127.0.0.1")
    else:
        hosts_to_probe = (host,)

    for probe_host in hosts_to_probe:
        # Pick the address family that matches the host string. IPv6
        # literals (``::``, ``::1``, etc.) need ``AF_INET6`` or the bind
        # raises before we can detect a real collision (codex r1 MED #6
        # on PR #855). Everything else — IPv4 literals, wildcards
        # (``0.0.0.0``, ``""``), the loopback-shadow probe ``127.0.0.1``
        # — stays on ``AF_INET``.
        family = socket.AF_INET6 if _is_ipv6_host(probe_host) else socket.AF_INET
        # ``with`` guarantees the preflight socket is closed on every
        # exit path — including OSError during ``bind``. The previous
        # form called ``_sock.close()`` only on the success branch,
        # which leaked the fd whenever the bind raised (e.g. when
        # running under a test harness that catches ``SystemExit``).
        with socket.socket(family, socket.SOCK_STREAM) as _sock:
            _sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                _sock.bind((probe_host, port))
            except OSError:
                # Surface the host we actually collided on so the user
                # can distinguish "LAN port busy" from "loopback port
                # already claimed by another qmlx / nc / proxy".
                # Use the empty-string-friendly display name so
                # ``--host ""`` shows up as ``0.0.0.0`` rather than a
                # confusing bare quote.
                display_host = probe_host or "0.0.0.0"
                _render_port_collision(port, display_host, model=model)
                sys.exit(1)


def _print_port_collision_and_exit(
    host: str, port: int, *, in_listen_fd_mode: bool
) -> None:
    """Print a Sven-style supervisor-friendly EADDRINUSE message to
    stderr and ``sys.exit(1)``. Single SSOT so both the host/port and
    ``--listen-fd`` failure paths emit a consistent operator-facing
    message and the exit code stays non-zero in both.

    In ``--listen-fd`` mode the ``host``/``port`` args don't describe
    the real bind (the supervisor owns it), so we omit the
    port-specific ``lsof -i :N`` hint and reference the inherited fd
    instead — otherwise the operator would chase a port the qmlx
    process never tried to bind (codex round-1 NIT #3).
    """
    if in_listen_fd_mode:
        print(
            "\n  Error: bind() failed on the supervisor-provided "
            "--listen-fd. The inherited socket is unusable. Re-launch "
            "with a fresh socket activation or fall back to --host/--port.",
            file=sys.stderr,
        )
    else:
        display_host = host or "0.0.0.0"
        print(
            f"\n  Error: Port {port} already in use on {display_host}. "
            f"Choose a different --port or stop the existing server "
            f"(lsof -i :{port}).",
            file=sys.stderr,
        )
    sys.exit(1)


def _run_uvicorn(app, args, log_level: str) -> None:
    """Dispatch into ``uvicorn.run`` with the kwargs that match the
    current ``--listen-fd`` / ``--host``/``--port`` mode.

    Extracted so the call-site contract is unit-testable WITHOUT booting
    the heavy ``serve_command`` prologue (version check, model download,
    server import). The companion bytecode test in
    ``tests/test_serve_listen_fd.py`` pins that ``serve_command``
    actually references this helper so a future refactor that drops the
    dispatch silently is caught — that's the regression-detection codex
    round-1 PR #696 review was after.

    R13 Sven B1: also the single CLI-side chokepoint that converts a
    uvicorn-side bind failure into the friendly "Port N already in
    use…" message + ``sys.exit(1)`` the operator's supervisor (systemd,
    launchd, k8s) needs to detect failure. Three paths feed in:

      * ``OSError(EADDRINUSE)`` raised through uvicorn (older uvicorns,
        ``--listen-fd`` mode where ``socket.fromfd`` / ``create_server``
        fail before uvicorn's own except arms) — caught directly.
      * ``SystemExit(1)`` from uvicorn>=0.34: ``Server.startup`` catches
        the bind ``OSError``, ``logger.error(exc)``s it (raw
        ``ERROR: [Errno 48] …``), and ``sys.exit(1)``s before our
        ``except OSError`` can fire. The exit code is already non-zero,
        but the friendly hint is missing — so we re-detect by probing
        the same ``(host, port)`` ourselves and, if it's busy, re-emit
        the Sven-style message before propagating the same non-zero
        exit (codex round-1 BLOCKING #2).
      * Any other ``SystemExit`` from uvicorn (clean lifespan shutdown,
        TLS misconfig, etc.) is left untouched.

    ``_port_preflight_or_die`` (run earlier in ``serve_command``)
    handles the common pre-load case at zero cost — this layer is the
    TOCTOU-race / fd-mode safety net.
    """
    import errno

    import uvicorn

    listen_fd = getattr(args, "listen_fd", None)
    try:
        if listen_fd is not None:
            # ``fd=`` overrides ``host``/``port``: uvicorn skips its own
            # ``socket.bind()`` and adopts the inherited fd directly. This
            # is the close of the bind→auth TOCTOU window — the supervisor
            # bound + validated the auth secret BEFORE execve'ing, and the
            # FastAPI ``app`` (with route auth dependencies) is fully
            # constructed at module load before this call.
            uvicorn.run(
                app,
                fd=listen_fd,
                log_level=log_level,
                timeout_keep_alive=30,
            )
        else:
            uvicorn.run(
                app,
                host=args.host,
                port=args.port,
                log_level=log_level,
                timeout_keep_alive=30,
            )
    except OSError as exc:
        # Direct EADDRINUSE — older uvicorn, ``--listen-fd`` mode bind
        # path. Translate to the friendly message; unrelated OSErrors
        # (e.g. EACCES on a low port) keep their original trace and
        # propagate so the failure is debuggable.
        if exc.errno == errno.EADDRINUSE:
            _print_port_collision_and_exit(
                args.host, args.port, in_listen_fd_mode=listen_fd is not None
            )
        raise
    except SystemExit as exc:
        # uvicorn>=0.34 catches the bind ``OSError`` in ``Server.startup``,
        # ``logger.error(exc)``s it (raw ``[Errno 48]`` line — not the
        # friendly hint a supervisor operator needs), and ``sys.exit(1)``s
        # before our ``except OSError`` can fire. The exit code is
        # already non-zero so the supervisor-failure-detection contract
        # holds, but we re-emit the Sven-style message on top so the
        # operator's grep for "already in use" still hits. Only override
        # the message when a probe confirms the port really IS in use —
        # other ``SystemExit(1)`` paths (TLS, lifespan, etc.) must keep
        # uvicorn's own diagnostic so we don't paper over them.
        #
        # Outer guard: codex round-2 BLOCKING — if the probe itself
        # raises (TypeError from a non-string host, gaierror, etc.) the
        # caller's ``SystemExit`` MUST still propagate. Wrap the
        # discriminator call so any probe-side exception is silently
        # absorbed and the original ``raise`` below re-delivers
        # uvicorn's exit. ``_port_is_busy`` ALSO defends internally,
        # but a future refactor that drops that guard (or a monkeypatch
        # in a test harness) must not corrupt the failure signal.
        if exc.code in (1, "1") and listen_fd is None:
            try:
                busy = _port_is_busy(args.host, args.port)
            except BaseException:
                busy = False
            if busy:
                _print_port_collision_and_exit(
                    args.host, args.port, in_listen_fd_mode=False
                )
        raise


def _run_uvicorn_live(app, args, log_level: str) -> None:
    """Run the server with a live status strip on the terminal (#51).

    Rich/TTY only — the caller gates on ``ui.rich``. uvicorn runs on a
    daemon thread while the main thread drives a bottom-anchored live
    strip (``ui.live`` → ``_ui._draw_live_strip``) fed by the
    in-process stats payload (``get_config().engine.get_stats()`` —
    zero HTTP round-trips, the same data ``/v1/status`` serves). The
    strip owns its own line (clear+redraw per poll, newline-terminated)
    so uvicorn's log lines — which still land on stderr via their
    logger handlers — always start on a fresh line and never fuse with
    the strip (issue #61). Access logging is off for this path so the
    strip is the only high-frequency writer on the terminal (issue
    #51 C8).
    """
    import threading

    import uvicorn

    config = uvicorn.Config(
        app,
        host=args.host,
        port=args.port,
        log_level=log_level,
        access_log=False,  # C8: the strip is the only stdout writer
        timeout_keep_alive=30,
    )
    server = uvicorn.Server(config)
    server_thread = threading.Thread(
        target=server.run, name="qmlx-uvicorn", daemon=True
    )
    server_thread.start()

    from vllm_mlx.config import get_config

    def _live_stats() -> dict | None:
        cfg = get_config()
        if cfg.engine is None or not cfg.ready:
            return None
        try:
            stats = cfg.engine.get_stats()
        except Exception:
            return None
        if not isinstance(stats, dict):
            return None
        bg = stats.get("batch_generator")
        if not isinstance(bg, dict):
            bg = {}
        endpoint = (
            f"http://{cfg.bind_host}:{cfg.bind_port}/v1"
            if cfg.bind_host and cfg.bind_port
            else None
        )
        return {
            "status": "generating" if stats.get("running") else "idle",
            "model": cfg.model_name,
            "endpoint": endpoint,
            "generation_tps": bg.get("generation_tps") or 0.0,
            "num_running": stats.get("num_running", 0),
            "num_waiting": stats.get("num_waiting", 0),
            "device_active_gb": stats.get("device_active_memory_gb"),
            "uptime_s": stats.get("uptime_seconds"),
        }

    def render() -> str:
        return ui.render_live_line(_live_stats())

    try:
        with ui.live(
            render, interval=0.5, stop_fn=lambda: not server_thread.is_alive()
        ):
            pass
    except KeyboardInterrupt:
        server.should_exit = True
    server_thread.join(timeout=10)


def _port_is_busy(host: str, port: int) -> bool:
    """Best-effort probe: is ``(host, port)`` already bound by another
    process? Used by ``_run_uvicorn`` to disambiguate an uvicorn
    ``SystemExit(1)`` triggered by a bind collision from one triggered
    by an unrelated startup failure (TLS, lifespan, etc.).

    Returns True iff a fresh ``socket.bind`` fails with EADDRINUSE.
    Returns False on ANY other outcome (clean bind, ENETDOWN, EACCES,
    ``gaierror``, ``TypeError`` from a ``None`` host, etc.) so the
    caller's original ``SystemExit`` propagates untouched — codex
    round-2 BLOCKING was that a probe-side ``TypeError`` could replace
    uvicorn's ``SystemExit(1)`` with a misleading traceback. The probe
    is a HEURISTIC: a false-negative is acceptable (operator still
    gets uvicorn's diagnostic + non-zero exit, just no friendly hint),
    a probe-side raise that masks uvicorn's failure is not.
    """
    import errno
    import socket

    if not isinstance(host, str) or not host:
        # uvicorn accepts ``host=""`` as the wildcard alias, but
        # ``socket.bind(("", port))`` works on AF_INET — pre-normalize
        # to avoid a probe-side ``TypeError`` for non-string hosts
        # (sentinel values, configured-via-env edge cases).
        host = "0.0.0.0"

    try:
        family = socket.AF_INET6 if _is_ipv6_host(host) else socket.AF_INET
        with socket.socket(family, socket.SOCK_STREAM) as probe:
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                probe.bind((host, port))
            except OSError as exc:
                return exc.errno == errno.EADDRINUSE
    except BaseException:
        # Outer guard: ANY probe-side failure (socket constructor,
        # gaierror, host normalization, etc.) MUST NOT mask the caller's
        # ``SystemExit``. Swallow and report "not busy" so the original
        # exception re-raises cleanly. ``BaseException`` is intentional
        # — even a stray ``KeyboardInterrupt`` during the probe should
        # not corrupt the supervisor-facing failure signal; the caller's
        # ``raise`` will re-deliver any interrupt on the next event loop.
        return False
    return False


def _chat_config_dir() -> str:
    """Directory for first-launch tip markers (and future per-user chat
    state). Honors ``QMLX_CONFIG_HOME`` override; otherwise falls back
    to ``~/.config/qmlx``. The directory is created lazily by the
    writer; callers don't need to ensure it exists for reads.
    """
    override = os.environ.get("QMLX_CONFIG_HOME")
    if override:
        return override
    return os.path.join(os.path.expanduser("~"), ".config", "qmlx")


def _seen_tips_path() -> str:
    return os.path.join(_chat_config_dir(), "seen-tips.json")


def _has_seen_tip(key: str) -> bool:
    """Return True iff the marker file records ``key: true``.

    Any IO/parse error is treated as "not seen" — better to show the tip
    one extra time than to hide it forever on a corrupt marker.
    """
    import json

    try:
        with open(_seen_tips_path(), encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return False
    return isinstance(data, dict) and bool(data.get(key))


def _mark_tip_seen(key: str) -> None:
    """Persist ``key: true`` to the seen-tips marker. Best-effort —
    failures are swallowed so a read-only config dir never aborts chat.
    """
    import json

    path = _seen_tips_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
    except OSError:
        return
    try:
        existing: dict = {}
        try:
            with open(path, encoding="utf-8") as fh:
                loaded = json.load(fh)
            if isinstance(loaded, dict):
                existing = loaded
        except (OSError, ValueError):
            existing = {}
        existing[key] = True
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(existing, fh)
    except OSError:
        return


def _print_unknown_model_help(name: str, *, full_path_example: str) -> None:
    """Print fuzzy suggestions + a curated popular-models hint.

    Replaces the older "Did you mean: X?" + "Run `qmlx models`" pattern
    that left users empty-handed when no close fuzzy match existed
    (e.g. ``qmlx chat gemma4-27b`` returned zero suggestions, told the
    user to run another command, and gave no hint of what was actually
    supported). Now: always show *something* — fuzzy matches when we have
    them, curated popular aliases when we don't.
    """
    from vllm_mlx.model_aliases import (
        POPULAR_ALIASES,
        list_visible_aliases,
        suggest_similar,
    )

    suggestions = suggest_similar(name)
    if suggestions:
        hint = f"Did you mean: {', '.join(suggestions)}?"
    else:
        hint = f"Try one of: {', '.join(POPULAR_ALIASES)}"
    body = [
        hint,
        f"Run `qmlx models` to see all {len(list_visible_aliases())} aliases,",
        f"or pass a full path like: {full_path_example}",
    ]
    ui.panel(
        f"Unknown model: {name}",
        body,
        plain_lines=[f"  {ln}" for ln in body],
        style="red",
    )


def _check_disk_space(model_name: str, force: bool = False) -> None:
    """Verify there's enough disk space to download the model.

    Queries HuggingFace for the repo size and compares with available space
    on the resolved HF cache filesystem (respects ``HF_HOME`` /
    ``HF_HUB_CACHE`` rather than the hard-coded ``~/.cache/huggingface``).

    Behaviour:

    - Model is already a local path → return.
    - ``config.json`` is in the cache → assume already downloaded → return.
    - HF API call fails (offline, gated repo, etc.) → return silently. The
      loader's 404/auth handlers will surface the real error if there is one.
    - Determined size and disk is insufficient → print actionable error
      and ``sys.exit(1)``. ``force=True`` warns instead of aborting.

    The previous behaviour was to print a soft warning then continue. Users
    burned 30+ minutes downloading a 141 GB model on an 8.8 GB disk before
    HF Hub crashed with ``OSError: No space left on device``.
    """
    # Skip if model is a local path that already exists.
    if os.path.exists(model_name):
        return

    # Skip if model is already in the HF cache.
    try:
        from huggingface_hub import try_to_load_from_cache

        cached = try_to_load_from_cache(model_name, "config.json")
        if isinstance(cached, str) and os.path.exists(cached):
            return
    except Exception:
        pass

    # Query HF for repo size + free space on the actual HF cache filesystem.
    try:
        from huggingface_hub import model_info
        from huggingface_hub.constants import HF_HUB_CACHE

        info = model_info(model_name, files_metadata=True)
        model_size_bytes = sum(
            (s.size or 0)
            for s in (getattr(info, "siblings", None) or [])
            if hasattr(s, "size")
        )
        if model_size_bytes == 0:
            return  # Can't determine size — skip rather than guess.

        # statvfs needs an existing path; HF_HUB_CACHE may not exist yet on
        # a fresh install. Walk up to the first ancestor that does.
        # Resolve to absolute up front so a relative HF_HUB_CACHE doesn't
        # short-circuit to CWD when an ancestor walk hits ".".
        probe = os.path.abspath(HF_HUB_CACHE) if HF_HUB_CACHE else ""
        while probe and not os.path.exists(probe):
            parent = os.path.dirname(probe)
            if parent == probe:
                break
            probe = parent
        if not probe or not os.path.exists(probe):
            probe = os.path.expanduser("~")

        stat = os.statvfs(probe)
        available_bytes = stat.f_bavail * stat.f_frsize

        # ~10% headroom for temp files during xet_get / move-into-place.
        required_bytes = int(model_size_bytes * 1.1)
        if available_bytes >= required_bytes:
            return

        model_size_gb = model_size_bytes / (1024**3)
        available_gb = available_bytes / (1024**3)
        need_to_free_gb = (required_bytes - available_bytes) / (1024**3)

        ui.panel(
            "Error: Insufficient disk space",
            [
                "[bold]Model size:[/] " f"{model_size_gb:>7.1f} GB",
                "[bold]Free space:[/] " f"{available_gb:>7.1f} GB  ({probe})",
                "[bold]Need to free:[/] " f"{need_to_free_gb:>7.1f} GB",
                "",
                "Suggestions:",
                "  - Free disk space, or set HF_HOME to a drive with more room",
                "  - Pick a smaller variant: qmlx models",
            ],
            plain_lines=[
                "",
                "  Error: Insufficient disk space for download.",
                f"    Model size:    {model_size_gb:>7.1f} GB",
                f"    Free space:    {available_gb:>7.1f} GB  ({probe})",
                f"    Need to free:  {need_to_free_gb:>7.1f} GB",
                "",
                "  Suggestions:",
                "    - Free disk space, or set HF_HOME to a drive with more room",
                "    - Pick a smaller variant: qmlx models",
            ],
            style="red",
        )
        if not force:
            print(
                "    - Bypass this check (download will likely fail mid-way): "
                "--force-disk-check"
            )
            print()
            sys.exit(1)
        # ``force=True``: warn loudly, let the user proceed at their own risk.
        print("  --force-disk-check set — proceeding anyway.")
        print()
    except SystemExit:
        raise
    except Exception:
        # Network / auth / etc. failures are non-critical — fall through to
        # the loader's own error handling rather than blocking startup on a
        # flaky HF metadata query.
        pass


def _gather_kv_cache_dtype_inputs(model_name: str) -> tuple[dict | None, dict | None]:
    """Best-effort collect the inputs ``resolve_kv_cache_dtype`` consumes.

    R15 task #300: the safelist that downgrades int4 → bf16 for sliding-
    window and MLA models needs the HF ``config.json`` (``sliding_window``,
    ``q_lora_rank`` / ``kv_lora_rank``) plus any alias-level
    ``sliding_window`` / ``is_mla`` hints. We intentionally avoid
    network fetches here — both signals come from data that's already
    on disk (aliases.json) or that will be downloaded for the model
    load anyway (HF config). If neither is available (offline, gated
    repo, brand-new release), the substring fallback in
    :func:`vllm_mlx.kv_cache_dtype.resolve_kv_cache_dtype` still catches
    the documented families by name.

    Returns:
        A ``(hf_config, alias_metadata)`` pair. Either or both may be
        ``None`` when the inputs aren't reachable.
    """
    hf_cfg: dict | None = None
    alias_meta: dict | None = None

    # Alias metadata — pull straight from the loaded profile so a
    # contributor-curated override (``"sliding_window": true``) wins
    # over the substring heuristic.
    try:
        from .model_aliases import resolve_profile

        profile = resolve_profile(model_name)
        if profile is not None:
            alias_meta = {
                "hf_path": getattr(profile, "hf_path", None),
                # AliasProfile doesn't have ``sliding_window`` / ``is_mla``
                # fields today (R15 #300 intentionally avoids a frozen-
                # dataclass schema bump). The substring fallback covers
                # the in-tree aliases; we leave the hook here so a
                # future closed-key extension picks them up automatically.
                "sliding_window": getattr(profile, "sliding_window", False),
                "is_mla": getattr(profile, "is_mla", False),
            }
    except Exception:
        # Alias resolution must never block server start. The substring
        # fallback covers the documented families even with no profile.
        alias_meta = None

    # HF config — read from the local HF cache only. We're inside the
    # serve preflight path so a network round-trip would be cheap (the
    # model load follows immediately anyway), but staying file-local
    # keeps this helper safe to call in tests and air-gapped installs.
    try:
        import json as _json
        import os as _os

        from huggingface_hub import try_to_load_from_cache as _cache_lookup

        hf_path = (alias_meta or {}).get("hf_path") or model_name
        if hf_path:
            if _os.path.isdir(hf_path):
                # Local checkpoint directory — read config.json in
                # place. ``try_to_load_from_cache`` is an HF-cache
                # lookup; a directory path is not a repo id and would
                # return None, which leaves the MTP eligibility gate
                # (and the int4 safelist) blind to local checkpoints.
                local_cfg = _os.path.join(hf_path, "config.json")
                if _os.path.isfile(local_cfg):
                    with open(local_cfg) as fh:
                        hf_cfg = _json.load(fh)
            else:
                cached = _cache_lookup(repo_id=hf_path, filename="config.json")
                if cached and _os.path.exists(cached):
                    with open(cached) as fh:
                        hf_cfg = _json.load(fh)
    except Exception:
        hf_cfg = None

    return hf_cfg, alias_meta


def _apply_mtp_cli_model_type_reconciliation(
    *,
    scheduler_config,
    hf_cfg_eligibility,
    logger=None,
) -> None:
    """Thread the eligibility gate's ``model_type`` down into
    ``SchedulerConfig.mtp_model_type``.

    Codex round-I BLOCKING #3 / round-K BLOCKING #2:
    ``serve_command`` reads the HF config on two paths — an early
    best-effort read that populates
    ``scheduler_config.mtp_model_type``, and a second read inside
    the MTP eligibility gate that decides accept/reject. Under a
    transient first-read failure (warm HF cache invalidated,
    filesystem hiccup, etc.), the first read returned ``None`` and
    the second read succeeded. The engine then treated the
    operator's explicit MTP speculative-config request as
    "non-CLI-vetted" and soft-skipped dispatch failures — silently
    degrading MTP to a no-op.

    This helper resolves the skew: it treats the eligibility gate's
    read as the source of truth (the gate accepted the config, so
    it MUST be correct), promotes ``model_type`` into
    ``scheduler_config.mtp_model_type``, and hard-fails at
    ``sys.exit(2)`` if the eligibility read somehow lacks a string
    ``model_type`` (should be unreachable per
    ``detect_mtp_eligibility``'s own gates, but defensive).

    Extracted so tests can drive this helper end-to-end. A
    purely-inline reconciliation block in ``serve_command`` would
    let tests still pass after the block was deleted, because
    replaying the logic inline in a test never exercises the
    production import path (round-K BLOCKING #2).

    Args:
      scheduler_config: The already-constructed ``SchedulerConfig``.
        Its ``mtp_model_type`` field is mutated in place.
      hf_cfg_eligibility: The dict returned by the eligibility
        gate's ``_gather_kv_cache_dtype_inputs`` call.
      logger: Optional ``logging.Logger``. If provided, a warning is
        emitted when the CLI-thread read disagreed with the
        eligibility read. Kept optional so tests don't have to
        conjure a real logger; the ``print`` fallback below covers
        the ``None`` case with the same operator-visible message.
    """
    _eligibility_model_type: str | None = None
    if isinstance(hf_cfg_eligibility, dict):
        _mt_from_eligibility = hf_cfg_eligibility.get("model_type")
        if isinstance(_mt_from_eligibility, str):
            _eligibility_model_type = _mt_from_eligibility
    if _eligibility_model_type is None:
        # Should be unreachable: detect_mtp_eligibility gates on a
        # dict-shaped config with a string model_type. But if some
        # detector refactor ever relaxes that invariant, we MUST
        # hard-fail rather than boot in the silent-skip state.
        print(
            "error: MTP speculative-config eligibility passed but the CLI "
            "could not extract config.json::model_type — this is a "
            "plumbing skew between detect_mtp_eligibility (accepted "
            "the config) and this CLI reconciliation block. Refusing "
            "to boot: the engine's dispatch requires the CLI-vetted "
            "model_type to hard-fail on non-attached dispatch results "
            "(round-E BLOCKER #2 contract). File an issue with the "
            'output of `python -c "import json; '
            "print(json.load(open('config.json')).get('model_type'))\" "
            "run in the model directory.",
            file=sys.stderr,
        )
        sys.exit(2)
    # If the earlier best-effort read succeeded but disagreed with
    # the eligibility read, prefer the eligibility read — it drives
    # the accept/reject decision, so it MUST be the source of truth
    # for the dispatch-side CLI-vetted marker.
    _prior = getattr(scheduler_config, "mtp_model_type", None)
    if _prior is not None and _prior != _eligibility_model_type:
        _msg = (
            "[MTP] CLI-thread config read disagreed with the "
            "eligibility gate on model_type (%r vs %r); using the "
            "eligibility gate's value."
        )
        if logger is not None:
            logger.warning(_msg, _prior, _eligibility_model_type)
        else:
            print(_msg % (_prior, _eligibility_model_type), file=sys.stderr)
    scheduler_config.mtp_model_type = _eligibility_model_type


def _check_alias_min_memory(user_typed: str) -> None:
    """Alias-level unified-memory guard — warn if the user's Mac is
    smaller than the alias's declared ``min_memory_gb`` floor.

    codex #1069 round 3 [NIT #3]: fires alongside (and before) the
    generic model-size / pressure check in ``_check_memory_capacity``.
    That check reads live weights + free RAM, so it can only warn AFTER
    the download completes (or from the HF file-size API, which lags).
    This one fires up front from the alias profile so a user on a 128
    GB Max sees the actionable pointer BEFORE the 166 GB
    ``hy3-preview-4bit`` download starts.

    Best-effort: warns loudly (never aborts) so an operator with a
    borderline machine, headless setup, or unusual memory allocator
    can still opt in. Silent no-op when:
      - The alias has no ``min_memory_gb`` metadata (every model we
        ship under 100 GB weights).
      - The user typed an HF path directly instead of an alias.
      - psutil is unavailable / raises.
    """
    try:
        from .model_aliases import resolve_profile

        profile = resolve_profile(user_typed)
    except Exception:
        return
    if profile is None:
        return
    floor_gb = getattr(profile, "min_memory_gb", None)
    if floor_gb is None or floor_gb <= 0:
        return

    try:
        import psutil

        total_ram_gb = psutil.virtual_memory().total / (1024**3)
    except Exception:
        return
    if total_ram_gb <= 0:
        return
    if total_ram_gb >= floor_gb:
        return  # Machine is big enough — silent.

    _plain_body = [
        f"\n⚠  Ultra-only alias '{user_typed}' declares a "
        f"{floor_gb:.0f} GB unified-memory floor, but this Mac reports "
        f"{total_ram_gb:.1f} GB.",
        "   The model weights are large enough to OOM the Metal "
        "allocator (or kernel-panic on macOS < 15.2, issue #324) before "
        "the first token generates.",
        "   Recommended: pick a Tier-1 alias sized for this "
        "machine (`qmlx models` for the full list). "
        "Proceeding anyway…\n",
    ]
    ui.panel(
        "Ultra-only alias warning",
        [
            f"[bold yellow]⚠ Ultra-only alias '{user_typed}' declares a "
            f"{floor_gb:.0f} GB unified-memory floor, but this Mac reports "
            f"{total_ram_gb:.1f} GB.[/bold yellow]",
            "The model weights are large enough to OOM the Metal "
            "allocator (or kernel-panic on macOS < 15.2, issue #324) before "
            "the first token generates.",
            "Recommended: pick a Tier-1 alias sized for this "
            "machine (`qmlx models` for the full list). "
            "Proceeding anyway…",
        ],
        plain_lines=[ln for ln in _plain_body],
        style="yellow",
    )


def _check_memory_capacity(model_name: str) -> None:
    """Pre-flight memory check — warn loudly if loading this model is
    likely to push unified memory past the danger threshold.

    On low-memory Apple Silicon (especially Mac mini M4 24 GB), loading
    a model that forces unified memory past ~85% of total can trip the
    iBoot AMCC async-abort firmware path and **kernel-panic the entire
    machine** rather than raise a userspace OOM. See issue #324.

    This check is best-effort: it warns the user, never aborts. If we
    can't read the model size (offline / gated repo), or psutil isn't
    importable, fall through silently — the existing loader paths still
    surface real failures.

    Working-set estimate is ``model_size * 1.5`` for a typical short
    chat workload — covers KV cache, activations, and OS reserve.
    Long-context (32k+) or high-concurrency serving pushes the
    multiplier higher; the warning under-predicts in those modes
    rather than over-predicts, so a user who configures aggressively
    may still crash. We err on the side of warning earlier than later.

    **Pressure formula uses already-used memory** rather than just
    ``working / total``. The kernel panic fires on absolute unified-
    memory pressure, so a 10 GB model on a 24 GB Mac that already has
    8 GB used by macOS + Chrome lands at projected ``(8 + 15) / 24``
    = 95.8% — kernel-panic territory. The naive formula would have
    reported only 62.5% and stayed silent.
    """
    try:
        import psutil
    except Exception:
        return

    # Resolve model size in bytes — local path, then HF cache, then HF API.
    model_size_bytes = 0
    try:
        if os.path.isdir(model_name):
            for root, _dirs, files in os.walk(model_name):
                for f in files:
                    try:
                        model_size_bytes += os.path.getsize(os.path.join(root, f))
                    except OSError:
                        continue
        else:
            from huggingface_hub import model_info, try_to_load_from_cache

            cached = try_to_load_from_cache(model_name, "config.json")
            if isinstance(cached, str) and os.path.exists(cached):
                # Already-downloaded model: walk the snapshot directory.
                snapshot_dir = os.path.dirname(cached)
                for root, _dirs, files in os.walk(snapshot_dir):
                    for f in files:
                        try:
                            model_size_bytes += os.path.getsize(os.path.join(root, f))
                        except OSError:
                            continue
            else:
                info = model_info(model_name, files_metadata=True)
                model_size_bytes = sum(
                    (s.size or 0)
                    for s in (getattr(info, "siblings", None) or [])
                    if hasattr(s, "size")
                )
    except Exception:
        return  # Network / auth failure — fall through.

    if model_size_bytes <= 0:
        return

    try:
        vm = psutil.virtual_memory()
        total_ram_bytes = vm.total
        available_ram_bytes = vm.available
    except Exception:
        return

    if total_ram_bytes <= 0:
        return

    # Projected post-load pressure: already-used + estimated working set.
    # ``available`` is psutil's best estimate of "memory we can grab without
    # swapping," which on macOS includes inactive + cached pages that the
    # kernel will reclaim under pressure. ``total - available`` is therefore
    # a tighter "currently-pinned" floor than ``total - free``.
    estimated_working = int(model_size_bytes * 1.5)
    used_ram_bytes = max(0, total_ram_bytes - available_ram_bytes)
    projected_use = used_ram_bytes + estimated_working
    ratio = projected_use / total_ram_bytes
    if ratio < 0.65:
        return  # Comfortable headroom — no warning.

    model_gb = model_size_bytes / (1024**3)
    working_gb = estimated_working / (1024**3)
    used_gb = used_ram_bytes / (1024**3)
    total_gb = total_ram_bytes / (1024**3)

    plain_lines: list[str] = [""]
    if ratio >= 0.85:
        plain_lines += [
            "  !! Memory pressure warning: "
            "this model is likely too large for your hardware.",
            "  Continuing may trigger a macOS kernel panic " "(see issue #324).",
        ]
    else:
        plain_lines.append(
            "  Memory pressure note: " "this model uses a large fraction of system RAM."
        )
    plain_lines += [
        "",
        f"    Model on disk:           {model_gb:>6.1f} GB",
        "    Est. working set:        "
        f"{working_gb:>6.1f} GB  "
        "(model x 1.5 — short-chat workload; long-context serving will use more)",
        f"    Currently used by OS:    {used_gb:>6.1f} GB",
        "    Total system RAM:        "
        f"{total_gb:>6.1f} GB  "
        f"({ratio * 100:.0f}% projected utilization)",
        "",
    ]
    if ratio >= 0.85:
        plain_lines += [
            "  Apple Silicon firmware can panic the whole system rather than",
            "  raise an OOM error when unified-memory pressure exceeds the",
            "  iBoot AMCC threshold. Recommended actions:",
            "",
            "    - Close other apps to free RAM, or",
            "    - Pick a smaller model:    qmlx models",
            "    - Or lower memory headroom: "
            "qmlx serve <model> --gpu-memory-utilization 0.75",
        ]
    else:
        plain_lines.append(
            "  If you see crashes or kernel panics, try: "
            "--gpu-memory-utilization 0.85"
        )
    plain_lines.append("")

    body = []
    if ratio >= 0.85:
        body.append(
            "[bold red]!! Memory pressure warning:[/bold red] "
            "this model is likely too large for your hardware."
        )
        body.append(
            "[dim]Continuing may trigger a macOS kernel panic "
            "(see issue #324).[/dim]"
        )
    else:
        body.append(
            "[bold yellow]Memory pressure note:[/bold yellow] "
            "this model uses a large fraction of system RAM."
        )
    body += [
        "",
        f"[bold]Model on disk:[/]          {model_gb:>6.1f} GB",
        f"[bold]Est. working set:[/]       {working_gb:>6.1f} GB  "
        "[dim](model x 1.5 — short-chat workload; "
        "long-context serving will use more)[/dim]",
        f"[bold]Currently used by OS:[/]   {used_gb:>6.1f} GB",
        f"[bold]Total system RAM:[/]      {total_gb:>6.1f} GB  "
        f"({ratio * 100:.0f}% projected utilization)",
    ]
    if ratio >= 0.85:
        body += [
            "Apple Silicon firmware can panic the whole system "
            "rather than raise an OOM error when unified-memory "
            "pressure exceeds the iBoot AMCC threshold.",
            "",
            "[bold]Recommended actions:[/bold]",
            "  - Close other apps to free RAM, or",
            "  - Pick a smaller model: qmlx models",
            "  - Or lower memory headroom: "
            "qmlx serve <model> --gpu-memory-utilization 0.75",
        ]
    else:
        body.append(
            "If you see crashes or kernel panics, try: " "--gpu-memory-utilization 0.85"
        )
    ui.panel(
        "Memory pressure",
        body,
        plain_lines=plain_lines,
        style="red" if ratio >= 0.85 else "yellow",
    )


def _try_mirror_prefetch(model_name: str) -> bool:
    """Pre-fetch a HuggingFace repo via R2-first / HF-fallback (per file).

    Delegates to :func:`vllm_mlx._mirror.download_with_mirror_fallback`.
    Returns ``True`` if the snapshot is fully populated (any mix of R2
    and HF). Returns ``False`` if the caller should fall through to the
    plain ``snapshot_download(repo_id)`` path (catalog unavailable for
    catalog-only paths, or one or more files failed both R2 and HF).

    Set ``QMLX_MODEL_MIRROR=""`` to disable R2 entirely and force
    HuggingFace.

    Codex round-6 BLOCKING #2: the mirror module already returns
    ``False`` on every recoverable network/cache error, so the only
    catch worth doing here is ``ImportError`` (mirror module disabled
    or missing in a minimal install). Programmer errors propagate so
    bugs in the mirror module surface as real stack traces instead of
    silently routing to ``snapshot_download``.
    """
    try:
        from vllm_mlx._mirror import download_with_mirror_fallback
    except ImportError:
        # Mirror module not available (minimal-deps install or
        # deliberately removed). Use the legacy HF path.
        return False
    return download_with_mirror_fallback(model_name)


def _ensure_model_downloaded(model_name: str) -> None:
    """Pre-fetch a model in the foreground so HF's tqdm progress is visible.

    Used by ``qmlx chat``: the chat REPL spawns ``serve`` as a
    subprocess with stdout/stderr redirected to a log file. If the model
    isn't cached, the user sees a silent multi-minute hang while several
    GB downloads behind the log. Calling ``snapshot_download`` here first
    surfaces the standard HF progress bars on the user's terminal, then
    the spawned server starts as a cache hit.

    No-op when the model is already cached, when ``model_name`` is a local
    path, or when the HF lookup fails (let the loader's own error paths
    handle it).
    """
    if os.path.exists(model_name):
        return
    # Reuse the same weight-file-presence probe as ``is_repo_cached``:
    # the older ``try_to_load_from_cache('config.json')`` check
    # short-circuits on a partial cache (metadata downloaded, weight
    # shards still in flight), letting the spawned ``serve`` quietly
    # finish the download inside its logfile. Codex round-3 BLOCKING #2.
    try:
        from vllm_mlx._download_gate import is_repo_cached

        if is_repo_cached(model_name):
            return
    except Exception:
        # Probe failed (filesystem permission error, unexpected layout) —
        # fall through to the heavy snapshot_download path; HF will
        # short-circuit on its own cache check if the repo really is
        # fully present.
        pass

    # Disk-space gate: a 20 GB partial download that fails on the last
    # shard wastes the user's time. ``_check_disk_space`` queries HF for
    # the repo size and aborts with a clear message + exit(1) if there
    # isn't enough room on the resolved HF cache filesystem.
    _check_disk_space(model_name)

    # User-configured mirror path (R2/S3/any HTTP host). When the mirror
    # serves every file the repo declares, populate the HF cache layout
    # ourselves and skip snapshot_download. On any miss we fall through
    # to the normal HuggingFace download below.
    if _try_mirror_prefetch(model_name):
        return

    try:
        from huggingface_hub import model_info, snapshot_download

        size_gb = 0.0
        try:
            info = model_info(model_name, files_metadata=True)
            size_bytes = sum(
                (s.size or 0)
                for s in (getattr(info, "siblings", None) or [])
                if hasattr(s, "size")
            )
            size_gb = size_bytes / (1024**3)
        except Exception:
            pass

        is_tty = sys.stdout.isatty() and "NO_COLOR" not in os.environ
        BOLD = "\x1b[1m" if is_tty else ""
        DIM = "\x1b[2m" if is_tty else ""
        RESET = "\x1b[0m" if is_tty else ""
        if size_gb > 0:
            print(
                f"\n  {BOLD}First-time download{RESET} — "
                f"fetching {model_name} {DIM}(~{size_gb:.1f} GB){RESET} "
                "from HuggingFace ..."
            )
        else:
            print(
                f"\n  {BOLD}First-time download{RESET} — "
                f"fetching {model_name} from HuggingFace ..."
            )

        snapshot_download(model_name)
        print()
    except SystemExit:
        # _check_disk_space aborts via sys.exit(1) — let it through.
        raise
    except Exception as e:
        # Definitive 404s are surfaced so callers (e.g. ``/model bogus``)
        # can refuse fast instead of spawning a doomed serve subprocess
        # that fails after ``--ready-timeout``. Other transient errors
        # (network, auth) fall through silently — the spawned server's
        # own loader will retry and surface a real error if needed.
        from huggingface_hub.utils import RepositoryNotFoundError

        if isinstance(e, RepositoryNotFoundError) or "404" in str(e):
            raise RuntimeError(f"Model {model_name!r} not found on HuggingFace") from e
        print(f"\n  Pre-download skipped ({type(e).__name__}); server will retry.")


def _normalize_speculative_config_or_exit(args):
    """Parse ``--speculative-config`` and map methods to runtime fields."""
    import json
    import sys

    from .spec_decode.config import (
        SpeculativeConfigError,
        parse_speculative_config,
        require_migrated_speculative_config,
    )

    raw_config = getattr(args, "speculative_config", None)
    raw_config_was_explicit = raw_config is not None
    config = None

    def _fill_runtime_defaults(*, overwrite: bool) -> None:
        defaults = {
            "enable_ddtree": False,
            "enable_dflash": False,
            "spec_decode": "none",
            "dflash_drafter_path": "",
            "enable_mtp": False,
            "mtp_num_draft_tokens": 1,
            "mtp_optimistic": False,
            "mtp_sidecar": None,
            "mtp_max_k": 1,
            "mtp_disable_auto_k": False,
            "suffix_decoding": False,
        }
        for name, value in defaults.items():
            if overwrite or not hasattr(args, name) or getattr(args, name) is None:
                setattr(args, name, value)

    def _reject_no_spec_decode_runtime_conflicts() -> None:
        if not getattr(args, "no_spec_decode", False):
            return
        conflicts = []
        if getattr(args, "enable_ddtree", False):
            conflicts.append("enable_ddtree")
        if getattr(args, "enable_dflash", False):
            conflicts.append("enable_dflash")
        spec_decode = getattr(args, "spec_decode", "none")
        if spec_decode not in (None, "none"):
            conflicts.append(f"spec_decode={spec_decode}")
        if (getattr(args, "dflash_drafter_path", "") or "").strip():
            conflicts.append("dflash_drafter_path")
        if getattr(args, "enable_mtp", False):
            conflicts.append("enable_mtp")
        if (getattr(args, "mtp_sidecar", None) or "").strip():
            conflicts.append("mtp_sidecar")
        # Idempotency guard: after ``_fill_runtime_defaults(overwrite=True)``
        # a disabled config normalizes to ``mtp_max_k=1``. Only flag the
        # value as a ``--no-spec-decode`` conflict when it diverges from
        # that disabled default (i.e., an explicit non-default was passed).
        if getattr(args, "mtp_max_k", None) not in (None, 1):
            conflicts.append("mtp_max_k")
        if getattr(args, "mtp_num_draft_tokens", 1) != 1:
            conflicts.append("mtp_num_draft_tokens")
        if getattr(args, "mtp_disable_auto_k", False):
            conflicts.append("mtp_disable_auto_k")
        if getattr(args, "mtp_optimistic", False):
            conflicts.append("mtp_optimistic")
        if getattr(args, "suffix_decoding", False):
            conflicts.append("suffix_decoding")
        if getattr(args, "suffix_max_draft", None) is not None:
            conflicts.append("suffix_max_draft")
        if getattr(args, "suffix_max_suffix_len", None) is not None:
            conflicts.append("suffix_max_suffix_len")
        if getattr(args, "suffix_min_confidence", None) is not None:
            conflicts.append("suffix_min_confidence")
        if getattr(args, "suffix_min_draft_len", None) is not None:
            conflicts.append("suffix_min_draft_len")
        if not conflicts:
            return
        joined = ", ".join(conflicts)
        print(
            f"error: --no-spec-decode is mutually exclusive with {joined}.",
            file=sys.stderr,
        )
        sys.exit(2)

    def _legacy_speculative_fields() -> list[str]:
        fields = []
        if getattr(args, "enable_ddtree", False):
            fields.append("enable_ddtree")
        if getattr(args, "enable_dflash", False):
            fields.append("enable_dflash")
        spec_decode = getattr(args, "spec_decode", "none")
        if spec_decode not in (None, "none"):
            fields.append(f"spec_decode={spec_decode}")
        if (getattr(args, "dflash_drafter_path", "") or "").strip():
            fields.append("dflash_drafter_path")
        if getattr(args, "enable_mtp", False):
            fields.append("enable_mtp")
        if (getattr(args, "mtp_sidecar", None) or "").strip():
            fields.append("mtp_sidecar")
        if getattr(args, "mtp_max_k", None) is not None:
            fields.append("mtp_max_k")
        if getattr(args, "mtp_num_draft_tokens", 1) != 1:
            fields.append("mtp_num_draft_tokens")
        if getattr(args, "mtp_disable_auto_k", False):
            fields.append("mtp_disable_auto_k")
        if getattr(args, "mtp_optimistic", False):
            fields.append("mtp_optimistic")
        if getattr(args, "suffix_decoding", False):
            fields.append("suffix_decoding")
        if getattr(args, "suffix_max_draft", None) is not None:
            fields.append("suffix_max_draft")
        if getattr(args, "suffix_max_suffix_len", None) is not None:
            fields.append("suffix_max_suffix_len")
        if getattr(args, "suffix_min_confidence", None) is not None:
            fields.append("suffix_min_confidence")
        if getattr(args, "suffix_min_draft_len", None) is not None:
            fields.append("suffix_min_draft_len")
        return fields

    def _fill_suffix_defaults() -> None:
        if getattr(args, "suffix_max_draft", None) is None:
            args.suffix_max_draft = 8
        if getattr(args, "suffix_max_suffix_len", None) is None:
            args.suffix_max_suffix_len = 4
        if getattr(args, "suffix_min_confidence", None) is None:
            args.suffix_min_confidence = 0.3
        if getattr(args, "suffix_min_draft_len", None) is None:
            args.suffix_min_draft_len = 2

    def _legacy_speculative_config_payload() -> dict | None:
        methods: list[tuple[str, dict]] = []

        def add_method(method: str, payload: dict) -> None:
            methods.append((method, payload))

        def reject_orphan(knob: str, selector: str) -> None:
            print(
                f"error: legacy speculative decoding knob {knob} requires {selector}.",
                file=sys.stderr,
            )
            sys.exit(2)

        spec_decode = getattr(args, "spec_decode", "none")
        dflash_model = (getattr(args, "dflash_drafter_path", "") or "").strip()
        if getattr(args, "enable_ddtree", False):
            add_method("ddtree", {"method": "ddtree"})
        dflash_requested = (
            getattr(args, "enable_dflash", False) or spec_decode == "dflash"
        )
        if dflash_model and not dflash_requested:
            reject_orphan("dflash_drafter_path", "enable_dflash or spec_decode=dflash")
        if dflash_requested:
            payload = {"method": "dflash"}
            if dflash_model:
                payload["model"] = dflash_model
            add_method("dflash", payload)

        mtp_payload = {"method": "mtp"}
        mtp_requested = getattr(args, "enable_mtp", False) or spec_decode == "mtp"
        sidecar = (getattr(args, "mtp_sidecar", None) or "").strip()
        if sidecar:
            if not mtp_requested:
                reject_orphan("mtp_sidecar", "enable_mtp or spec_decode=mtp")
            mtp_payload["model"] = sidecar
        mtp_max_k = getattr(args, "mtp_max_k", None)
        if mtp_max_k is not None:
            if not mtp_requested:
                reject_orphan("mtp_max_k", "enable_mtp or spec_decode=mtp")
            mtp_payload["num_speculative_tokens"] = mtp_max_k
        mtp_num_draft_tokens = getattr(args, "mtp_num_draft_tokens", 1)
        if (
            mtp_max_k is not None
            and mtp_num_draft_tokens != 1
            and mtp_max_k != mtp_num_draft_tokens
        ):
            print(
                "error: legacy MTP aliases mtp_max_k and mtp_num_draft_tokens "
                "conflict; pass only one token-count value.",
                file=sys.stderr,
            )
            sys.exit(2)
        if mtp_num_draft_tokens != 1:
            if not mtp_requested:
                reject_orphan("mtp_num_draft_tokens", "enable_mtp or spec_decode=mtp")
            mtp_payload["num_speculative_tokens"] = mtp_num_draft_tokens
        if getattr(args, "mtp_disable_auto_k", False):
            if not mtp_requested:
                reject_orphan("mtp_disable_auto_k", "enable_mtp or spec_decode=mtp")
            mtp_payload["disable_auto_k"] = True
        if getattr(args, "mtp_optimistic", False):
            if not mtp_requested:
                reject_orphan("mtp_optimistic", "enable_mtp or spec_decode=mtp")
            # Unified spec-decode interface (PR #1050): even legacy
            # ``--enable-mtp`` normalizes to ``spec_decode="mtp"`` and
            # installs the vendored MTP runtime, which does not honour
            # ``mtp_optimistic``. Hard-reject the flag on every entry
            # point so behavior stays consistent (fail loud > silent
            # ignore).
            print(
                "error: legacy speculative decoding knob mtp_optimistic "
                "is not supported under the unified spec-decode "
                "interface; the vendored MTP installer does not "
                "implement optimistic mode. Remove --mtp-optimistic.",
                file=sys.stderr,
            )
            sys.exit(2)
        if mtp_requested:
            add_method("mtp", mtp_payload)

        suffix_payload = {"method": "suffix"}
        suffix_requested = getattr(args, "suffix_decoding", False)
        suffix_fields = (
            ("suffix_max_draft", "num_speculative_tokens"),
            ("suffix_max_suffix_len", "max_suffix_len"),
            ("suffix_min_confidence", "min_confidence"),
            ("suffix_min_draft_len", "min_draft_len"),
        )
        for attr, key in suffix_fields:
            value = getattr(args, attr, None)
            if value is not None:
                if not suffix_requested:
                    reject_orphan(attr, "suffix_decoding")
                suffix_payload[key] = value
        if suffix_requested:
            add_method("suffix", suffix_payload)

        if not methods:
            return None
        distinct = {method for method, _payload in methods}
        if len(distinct) > 1:
            joined = ", ".join(method for method, _payload in methods)
            print(
                "error: legacy speculative decoding aliases select multiple "
                f"methods ({joined}); use one --speculative-config payload.",
                file=sys.stderr,
            )
            sys.exit(2)
        return methods[0][1]

    legacy_payload = None
    legacy_enable_mtp_requested = raw_config is None and getattr(
        args, "enable_mtp", False
    )
    legacy_mtp_optimistic_requested = raw_config is None and getattr(
        args, "mtp_optimistic", False
    )
    if raw_config_was_explicit:
        legacy_fields = _legacy_speculative_fields()
        if legacy_fields:
            joined = ", ".join(legacy_fields)
            print(
                "error: --speculative-config is mutually exclusive with "
                f"legacy speculative decoding aliases: {joined}.",
                file=sys.stderr,
            )
            sys.exit(2)

    if raw_config is None:
        _reject_no_spec_decode_runtime_conflicts()
        legacy_payload = _legacy_speculative_config_payload()
        if legacy_payload is not None:
            raw_config = json.dumps(legacy_payload, separators=(",", ":"))
            args.speculative_config = raw_config

    if raw_config is None:
        _fill_runtime_defaults(overwrite=False)
        args._speculative_config = None
        _fill_suffix_defaults()
        return

    if raw_config is not None:
        try:
            config = parse_speculative_config(raw_config)
            if config is not None:
                require_migrated_speculative_config(config)
        except SpeculativeConfigError as exc:
            print(f"error: {exc}", file=sys.stderr)
            sys.exit(2)
        if getattr(args, "no_spec_decode", False):
            print(
                "error: --speculative-config is mutually exclusive with "
                "--no-spec-decode.",
                file=sys.stderr,
            )
            sys.exit(2)

    if config is None:
        _fill_runtime_defaults(overwrite=True)
        args._speculative_config = None
        _fill_suffix_defaults()
        return

    _fill_runtime_defaults(overwrite=True)
    args._speculative_config = config
    if config.method == "ddtree":
        args.enable_ddtree = True
    elif config.method == "dflash":
        args.enable_dflash = True
        if config.model:
            args.dflash_drafter_path = config.model
    elif config.method == "mtp":
        args.spec_decode = "mtp"
        if legacy_enable_mtp_requested:
            args.enable_mtp = True
            if config.num_speculative_tokens is not None:
                args.mtp_num_draft_tokens = config.num_speculative_tokens
            if legacy_mtp_optimistic_requested:
                args.mtp_optimistic = True
        args.mtp_sidecar = config.model
        if config.num_speculative_tokens is not None:
            args.mtp_max_k = config.num_speculative_tokens
        if config.disable_auto_k is not None:
            args.mtp_disable_auto_k = config.disable_auto_k
    elif config.method == "suffix":
        args.suffix_decoding = True
        if config.num_speculative_tokens is not None:
            args.suffix_max_draft = config.num_speculative_tokens
        if config.max_suffix_len is not None:
            args.suffix_max_suffix_len = config.max_suffix_len
        if config.min_confidence is not None:
            args.suffix_min_confidence = config.min_confidence
        if config.min_draft_len is not None:
            args.suffix_min_draft_len = config.min_draft_len

    _fill_suffix_defaults()


def _resolve_dflash_drafter_repo(args, profile) -> str:
    """Return the effective DFlash drafter repo for normalized CLI args."""

    spec_config = getattr(args, "_speculative_config", None)
    if spec_config is not None and spec_config.method == "dflash" and spec_config.model:
        return spec_config.model
    return profile.dflash_draft_model


def _preflight_dflash_mutexes_or_exit(args) -> None:
    """Reject DFlash flag combinations before optional-runtime probes."""

    if not getattr(args, "enable_dflash", False):
        return

    import sys

    spec_config = getattr(args, "_speculative_config", None)
    if spec_config is not None and getattr(spec_config, "method", None) == "dflash":
        if getattr(args, "suffix_decoding", False):
            print(
                "\n  Error: DFlash cannot combine with other spec-decode methods. "
                "DFlash runs a dedicated single-user server that bypasses "
                "BatchedEngine; other spec-decode methods only apply to the "
                "BatchedEngine path.\n"
            )
            sys.exit(1)
        return

    if (
        getattr(args, "suffix_decoding", False)
        or getattr(args, "enable_mtp", False)
        or getattr(args, "spec_decode", "none") != "none"
    ):
        print(
            "\n  Error: DFlash cannot combine with other spec-decode methods. "
            "DFlash runs a dedicated single-user server that bypasses "
            "BatchedEngine; other spec-decode methods only apply to the "
            "BatchedEngine path.\n"
        )
        sys.exit(1)
    if getattr(args, "no_spec_decode", False):
        print(
            "error: DFlash and --no-spec-decode are mutually exclusive "
            "— DFlash is a speculative-decode mode.",
            file=sys.stderr,
        )
        sys.exit(2)


def _preflight_ddtree_or_exit(args):
    """Validate DDTree flag/alias/runtime gates and cache the profile."""
    import sys

    spec_config = getattr(args, "_speculative_config", None)
    if spec_config is None or spec_config.method != "ddtree":
        print(
            'error: DDTree requires --speculative-config \'{"method":"ddtree"}\'.',
            file=sys.stderr,
        )
        sys.exit(2)

    if getattr(args, "enable_dflash", False):
        print(
            "\n  Error: DDTree cannot combine with DFlash. Pick one "
            "block-diffusion speculative-decoding server.\n"
        )
        sys.exit(1)
    if (
        getattr(args, "suffix_decoding", False)
        or getattr(args, "spec_decode", "none") != "none"
    ):
        print(
            "\n  Error: DDTree cannot combine with other spec-decode methods. "
            "DDTree runs a dedicated single-user server that bypasses "
            "BatchedEngine; other spec-decode methods only apply to the "
            "BatchedEngine path.\n"
        )
        sys.exit(1)
    if getattr(args, "no_spec_decode", False):
        print(
            "error: DDTree and --no-spec-decode are mutually "
            "exclusive — DDTree is a speculative-decode mode.",
            file=sys.stderr,
        )
        sys.exit(2)

    from .model_aliases import resolve_profile
    from .spec_decode.ddtree import DDTreeUnavailable, check
    from .spec_decode.ddtree.eligibility import have_runtime, runtime_probe_error

    alias_name = getattr(args, "_original_alias", None) or args.model
    profile = resolve_profile(alias_name)
    if profile is None:
        print(
            f"\n  Error: DDTree requires a known alias, got "
            f"{alias_name!r}. DDTree eligibility is recorded per-alias "
            f"in aliases.json; ad-hoc HuggingFace paths can't be "
            f"validated. Try ``qmlx info qwen3.5-9b-8bit``.\n"
        )
        sys.exit(1)
    try:
        check(profile, alias=alias_name)
    except DDTreeUnavailable as e:
        print(f"\n  Error: {e}\n")
        sys.exit(1)
    if not have_runtime():
        probe_error = runtime_probe_error()
        detail = f" Probe failure: {probe_error}." if probe_error else ""
        print(
            "\n  Error: DDTree requires the experimental dtree-mlx "
            "runtime. Install with: ``pip install 'dtree-mlx @ "
            f"git+https://github.com/DrHB/dtree-mlx.git'``.{detail}\n"
        )
        sys.exit(1)

    args._ddtree_alias_name = alias_name
    args._ddtree_profile = profile
    args._ddtree_drafter_repo = spec_config.model or profile.ddtree_draft_model
    args._ddtree_speculative_tokens = (
        spec_config.num_speculative_tokens or profile.ddtree_speculative_tokens
    )
    args._ddtree_tree_budget = spec_config.tree_budget or profile.ddtree_tree_budget
    return alias_name, profile


def _render_startup_banner(args, *, gc_control: bool, cors_origins: list) -> None:
    """Startup banner (issue #51; compacted by issue #61).

    2-3 lines total in BOTH render modes, so the banner AND the
    ``Starting server on …`` endpoint line below it stay on-screen on
    a 100x30 terminal at the "warming up" moment (issue #61 AC2). The
    pre-#61 rich panel (title border + body + bottom border = 4-5
    lines) and the legacy plain block (header + divider + rows = 4-5
    lines) both scrolled off a 30-row screen before the endpoint line
    printed.

    plain: the legacy 2-space-indented layout minus the header/divider
    lines; ``MCP config:`` stays at column 0 (operators grep for it,
    kept from the pre-#51 byte layout). rich: the same lines through
    :func:`vllm_mlx._ui.emit` with markup.
    """
    features: list[str] = []
    if args.enable_auto_tool_choice:
        bias_info = (
            " + logits bias" if getattr(args, "enable_tool_logits_bias", False) else ""
        )
        features.append(f"tools: {args.tool_call_parser}{bias_info}")
    if args.reasoning_parser:
        features.append(f"reasoning: {args.reasoning_parser}")
    # Banner mirrors the effective auth state via ``_auth_feature_str``
    # so the test can call the same function. Pre-fix the gate said
    # ``if args.api_key`` directly — a sidecar that set env-only saw
    # ``auth: off`` printed even though ``verify_api_key`` was
    # enforcing. ``_auth_feature_str`` keeps the banner and the actual
    # enforcement aligned and is directly unit-testable.
    auth_feature = _auth_feature_str(args.api_key)
    if auth_feature:
        features.append(auth_feature)
    if args.rate_limit > 0:
        features.append(f"rate-limit: {args.rate_limit}/min")
    if args.cloud_model:
        features.append(f"cloud: {args.cloud_model}")
    if gc_control:
        features.append("gc-control")
    if args.pin_system_prompt:
        features.append("pin-system-prompt")
    # Show CORS in the startup banner when CLI flag or env-var-driven
    # config produced an origin list (``configure_cors_from_env`` is
    # what actually resolved it — see the call site earlier in this
    # function).
    if cors_origins:
        features.append(f"cors: {', '.join(cors_origins)}")
    if args.enable_dflash:
        features.append("dflash: single-user")
    if args.enable_ddtree:
        features.append("ddtree: experimental single-user")

    model = args.model
    mcp_config = args.mcp_config

    if ui.rich:
        ui.emit(f"[cyan]🐆 qMLX[/cyan]  [bold]Model:[/] {model}", markup=True)
        if features:
            ui.emit(f"  [bold]Features:[/] {', '.join(features)}", markup=True)
        if mcp_config:
            ui.emit(f"  [bold]MCP config:[/] {mcp_config}", markup=True)
    else:
        print(f"  🐆 qMLX  Model: {model}")
        if features:
            print(f"  Features: {', '.join(features)}")
        if mcp_config:
            print(f"MCP config: {mcp_config}")


def _render_config_dump(
    args, scheduler_config, *, enable_prefix_cache: bool, logger
) -> None:
    """Startup config dump (issue #51): what the CLI actually set.

    plain: the legacy un-indented ``Key: value`` lines, printed in
    place (byte-identical to pre-#51 output). rich: the same data as a
    titled configuration panel rendered once after collection — the
    MTP eligibility check (which may ``sys.exit(2)``) still runs in
    its original position inside the collection block.
    """
    pairs: list[tuple[str, str]] = []

    def dump(key: str, value: str) -> None:
        pairs.append((key, value))
        if not ui.rich:
            print(f"{key}: {value}")

    dump("Mode", "Continuous batching (for multiple concurrent users)")
    if args.chunked_prefill_tokens > 0:
        dump("Chunked prefill", f"{args.chunked_prefill_tokens} tokens per step")
    if getattr(args, "spec_decode", "none") == "mtp":
        dump(
            "MTP",
            f"enabled via --speculative-config, "
            f"max_k={getattr(args, 'mtp_max_k', 1)}",
        )
        # Native Qwen3.5/3.6 MTP via vendored mlx-lm PR #990. The
        # config-only entrypoint is ``--speculative-config
        # '{"method":"mtp"}'``. Boot-time eligibility check fires here
        # so misuse bounces with a clear error instead of discovering
        # the mismatch mid-generation.
        from vllm_mlx.spec_decode.mtp import (
            MTPEligibility,
            detect_mtp_eligibility,
        )

        # ``_gather_kv_cache_dtype_inputs`` already reads
        # ``config.json`` for the same model the operator passed in;
        # reuse it so a side-loaded HF path or alias path both work.
        try:
            hf_cfg_eligibility, _ = _gather_kv_cache_dtype_inputs(args.model)
        except Exception:  # pragma: no cover — best-effort
            hf_cfg_eligibility = None
        has_sidecar = bool(getattr(args, "mtp_sidecar", None))
        eligibility = detect_mtp_eligibility(
            hf_cfg_eligibility, has_external_sidecar=has_sidecar
        )
        if eligibility is MTPEligibility.NONE:
            if has_sidecar:
                print(
                    "error: MTP speculative-config requires either a Qwen3.5 / "
                    "Qwen3.6 checkpoint with mtp_num_hidden_layers >= 1 in "
                    "config.json. Assistant sidecars are reserved for future "
                    "validated support and do not make this model eligible.",
                    file=sys.stderr,
                )
            else:
                print(
                    "error: MTP speculative-config requires a Qwen3.5 / "
                    "Qwen3.6 checkpoint with mtp_num_hidden_layers >= 1 in "
                    "config.json. Assistant sidecars are not currently "
                    "supported. The loaded model does not qualify.",
                    file=sys.stderr,
                )
            sys.exit(2)

        # Codex round-I BLOCKING #3 / round-K BLOCKING #2:
        # reconcile the earlier best-effort CLI-thread config read
        # with the eligibility gate's own read, and thread the
        # resulting model_type down into
        # ``scheduler_config.mtp_model_type``. Extracted into
        # :func:`_apply_mtp_cli_model_type_reconciliation` so a
        # regression test can drive the helper directly instead of
        # reimplementing the logic in the test body (round-K
        # BLOCKING #2 called out that a purely-inline reconciliation
        # block cannot be exercised without spinning up
        # ``serve_command``, which lets the test pass even if the
        # production block is later deleted).
        _apply_mtp_cli_model_type_reconciliation(
            scheduler_config=scheduler_config,
            hf_cfg_eligibility=hf_cfg_eligibility,
            logger=logger,
        )

        sidecar_note = (
            f" +sidecar={getattr(args, 'mtp_sidecar', None)}" if has_sidecar else ""
        )
        dump("Spec-decode", f"mtp ({eligibility.value}){sidecar_note}")

    # DFlash is normalized from ``--speculative-config`` near the top of
    # serve_command. By the time we reach here, args.spec_decode is
    # "none" for dflash callers. The speculative.dflash gate at the
    # start of serve_command runs the actual eligibility +
    # drafter-binding checks via the prod bridge.
    if args.suffix_decoding:
        dump(
            "SuffixDecoding",
            f"enabled, max_draft={args.suffix_max_draft}, "
            f"max_suffix={args.suffix_max_suffix_len}, "
            f"min_conf={args.suffix_min_confidence}",
        )
    dump("Stream interval", f"{args.stream_interval} tokens")
    if args.use_paged_cache:
        dump(
            "Paged cache",
            f"block_size={args.paged_cache_block_size}, max_blocks={args.max_cache_blocks}",
        )
    elif enable_prefix_cache:
        dump("Prefix cache", f"max_entries={args.prefix_cache_size}")
        # TurboQuant KV-cache compression flags (--kv-cache-turboquant / -group-size /
        # -bits) were cut in dev #57 (Metal-only cleanup); the parser no longer
        # defines them. getattr guards keep this render branch correct for the
        # flags that still exist and drop the TurboQuant dump when absent.
        mode = getattr(args, "kv_cache_turboquant", None)
        if mode:
            if mode == "k8v4":
                dump(
                    "TurboQuant K8V4",
                    f"K=8-bit Walsh-Hadamard, V=4-bit Lloyd-Max, "
                    f"group_size={getattr(args, 'kv_cache_turboquant_group_size', None)}",
                )
            else:
                bits = getattr(args, "kv_cache_turboquant_bits", None)
                bits_str = str(bits) if bits else "auto"
                dump(
                    f"TurboQuant V-cache ({mode})",
                    f"{bits_str}-bit, "
                    f"group_size={getattr(args, 'kv_cache_turboquant_group_size', None)} (K stays FP16)",
                )
        elif args.kv_cache_quantization:
            dump(
                "KV cache quantization",
                f"{args.kv_cache_quantization_bits}-bit, "
                f"group_size={args.kv_cache_quantization_group_size}",
            )

    if ui.rich and pairs:
        body = "\n".join(f"[bold]{k}:[/] {v}" for k, v in pairs)
        ui.panel("configuration", [body], plain_lines=[], style="green")


def serve_command(args):
    """Start the OpenAI-compatible server."""
    import logging
    import os
    import sys

    # Parent-PID watchdog (rapid-desktop issue #449): if the supervisor
    # passed its own PID via ``--watchdog-ppid`` or
    # ``$QMLX_WATCHDOG_PPID``, spawn a daemon thread that polls
    # ``os.getppid()`` every 2 s. When the parent dies (re-parented to
    # launchd / init), the watchdog sends SIGTERM to ourselves so the
    # FastAPI lifespan can flush + release the model — falling back to
    # SIGKILL after a 5 s grace. Installed at the top of serve_command
    # so it covers BOTH the text-LM path and the audio-mode fork below,
    # AND so it arms before the (potentially multi-minute) model
    # download — an operator who kills the desktop mid-download still
    # gets a clean reap on the sidecar. No-op when no supervisor PID
    # was passed (default).
    from ._parent_watchdog import install_parent_watchdog, resolve_expected_ppid

    install_parent_watchdog(resolve_expected_ppid(getattr(args, "watchdog_ppid", None)))

    _arg_max_tokens = getattr(args, "max_tokens", None)
    _max_tokens_is_explicit = _arg_max_tokens is not None
    effective_max_tokens = _arg_max_tokens if _arg_max_tokens is not None else 32768

    # Issue #33: ``--max-context-length`` is a token count. A negative
    # value would make the admission gate reject every request
    # (``prompt + max_tokens >= 0 > cap``), so fail fast with an
    # actionable message instead of starting a server that 400s
    # everything. ``0`` = no cap (model max stays the binding limit).
    if args.max_context_length < 0:
        print(
            "error: --max-context-length must be 0 (no cap) or a "
            f"positive token count, got {args.max_context_length}",
            file=sys.stderr,
        )
        sys.exit(2)

    _normalize_speculative_config_or_exit(args)

    # DDTree has an external experimental runtime and its validated target
    # can be multi-GB. Fail the cheap config/alias/runtime gates before the
    # version prompt and before any model prefetch so a missing dtree-mlx
    # install doesn't start a large download first.
    if getattr(args, "enable_ddtree", False):
        _preflight_ddtree_or_exit(args)

    if getattr(args, "enable_dflash", False):
        _preflight_dflash_mutexes_or_exit(args)

    # DFlash depends on the optional ``mlx-vlm`` bridge that ships in
    # the ``[dflash]`` extra. Pre-0.9.3 the missing-runtime error only
    # surfaced ~50 lines into serve_command, AFTER:
    #   - alias profile resolved (logged twice)
    #   - tool/reasoning parsers auto-configured
    #   - CORS allow-origin warning printed
    # so the operator saw five INFO lines and a banner before the
    # actionable ``Install with: pip install 'qmlx[dflash]'`` line,
    # matching Diego's earlier ``[embeddings]`` regression shape exactly.
    # Hoist the cheap ``have_runtime()`` probe to the same boot-guard tier
    # as the other extras so the error lands FIRST. ``importlib.util.
    # find_spec("mlx_vlm")`` doesn't trigger a load — safe to run on the
    # hot CLI path.
    _wants_dflash = getattr(args, "enable_dflash", False)
    if _wants_dflash:
        from .spec_decode.dflash.eligibility import have_runtime

        if not have_runtime():
            print(
                "\n  Error: DFlash speculative decoding "
                '(``--speculative-config \'{"method":"dflash"}\'``) requires '
                "mlx-vlm 0.5.0+ for the DFlash drafter hooks. Install with: "
                "``pip install 'qmlx[dflash]'``.\n"
            )
            sys.exit(1)

    # Non-interactive version check — when serve runs and a newer release
    # is available, print a one-line notice (never an interactive prompt,
    # never an auto-upgrade; operator order 10-28). Honors
    # QMLX_DISABLE_VERSION_CHECK, CI=1, and non-TTY stdin. Cached
    # piggy-backs on the existing staleness check's cache (24h TTL).
    from vllm_mlx._version_check import prompt_upgrade_if_available

    if prompt_upgrade_if_available():
        sys.exit(0)

    # Pre-fetch the model via the R2 mirror (with HF fallback) BEFORE the
    # heavy server boot. Without this, ``serve`` falls into
    # ``mlx_lm.load`` → ``huggingface_hub.snapshot_download`` directly and
    # skips the mirror entirely (#651). ``_ensure_model_downloaded`` is a
    # no-op on local paths and on fully-cached repos, so this is free on
    # the warm path.
    _ensure_model_downloaded(args.model)

    # Import unified server
    from . import server
    from .middleware.auth import configure_rate_limiter
    from .scheduler import SchedulerConfig
    from .server import app, load_model

    logger = logging.getLogger(__name__)
    uvicorn_log_level = server.configure_logging(args.log_level)

    # Validate tool calling arguments
    if args.enable_auto_tool_choice and not args.tool_call_parser:
        print("Error: --enable-auto-tool-choice requires --tool-call-parser")
        print("Example: --enable-auto-tool-choice --tool-call-parser mistral")
        sys.exit(1)

    # Validate --tool-call-parser against the live registry (not the
    # stale argparse choices list). v0.6.63 onboarding sweep finding #1.
    if args.tool_call_parser:
        # Narrow the catch: only swallow import-time / attribute access
        # failures (broken install, missing module file). Anything else
        # — a corrupt registry that's loaded but malformed, a TypeError
        # from a buggy parser's __init_subclass__, etc. — is a real bug
        # we want to surface, not paper over with "validation skipped".
        # Codex follow-up to PR #433.
        valid: list[str] | None = None
        try:
            from .tool_parsers import ToolParserManager

            valid = sorted(ToolParserManager.tool_parsers.keys())
        except (ImportError, AttributeError) as e:
            print(
                "warning: --tool-call-parser validation skipped — "
                f"tool_parsers registry unavailable ({type(e).__name__}: {e}). "
                "Proceeding without input check.",
                file=sys.stderr,
            )
        # Treat an empty registry (degenerate install) the same as a
        # failed import — skip validation rather than reject every input.
        # Without this guard, a successful import with zero registered
        # parsers would hard-fail every CLI invocation; DeepSeek
        # follow-up to PR #434.
        if valid and args.tool_call_parser not in valid:
            print(
                f"error: argument --tool-call-parser: invalid choice: "
                f"{args.tool_call_parser!r} "
                f"(choose from: {', '.join(valid)})",
                file=sys.stderr,
            )
            sys.exit(2)

    # Validate gpu-memory-utilization range
    if not (0.0 < args.gpu_memory_utilization <= 1.0):
        print(
            "Error: --gpu-memory-utilization must be between 0.0 (exclusive) and 1.0 (inclusive)"
        )
        sys.exit(1)

    # Auto-detect parser config from model name when not explicitly set.
    # --no-tool-call-parser / --no-reasoning-parser are escape hatches
    # (SOP §10): if the user opts out, do NOT let the AliasProfile auto-
    # populate args.tool_call_parser / args.reasoning_parser. Past
    # incidents: #393-class (auto-detect false positive with no opt-out).
    _opt_out_tool = getattr(args, "no_tool_call_parser", False)
    _opt_out_reasoning = getattr(args, "no_reasoning_parser", False)
    if args.tool_call_parser and _opt_out_tool:
        print(
            "error: --tool-call-parser and --no-tool-call-parser are "
            "mutually exclusive — pick one to override auto-detection.",
            file=sys.stderr,
        )
        sys.exit(2)
    if args.reasoning_parser and _opt_out_reasoning:
        print(
            "error: --reasoning-parser and --no-reasoning-parser are "
            "mutually exclusive — pick one to override auto-detection.",
            file=sys.stderr,
        )
        sys.exit(2)
    # R12-S1: snapshot whether the user explicitly passed
    # ``--tool-call-parser`` BEFORE auto-detect mutates ``args``. The
    # misbind warning below only consults this snapshot — auto-detected
    # bindings are guaranteed to match the model family by construction
    # (the auto path picks the same parser the helper would suggest), so
    # warning on them would be a contradictory "drop the flag" nudge
    # against a flag the user never passed. (Codex r4 NIT — keeps the
    # warning grounded in user intent even if a helper-side regression
    # ever started flagging in-spec cases.)
    _user_explicit_tool_call_parser = bool(args.tool_call_parser)
    if not args.tool_call_parser or not args.reasoning_parser:
        try:
            from .model_auto_config import detect_model_config

            auto_config = detect_model_config(args.model)
            if auto_config:
                if (
                    not args.tool_call_parser
                    and not _opt_out_tool
                    and auto_config.tool_call_parser
                ):
                    args.tool_call_parser = auto_config.tool_call_parser
                    args.enable_auto_tool_choice = True
                    logger.info(
                        f"Auto-configured --tool-call-parser {auto_config.tool_call_parser}"
                    )
                if (
                    not args.reasoning_parser
                    and not _opt_out_reasoning
                    and not args.no_thinking
                    and auto_config.reasoning_parser
                ):
                    args.reasoning_parser = auto_config.reasoning_parser
                    logger.info(
                        f"Auto-configured --reasoning-parser {auto_config.reasoning_parser}"
                    )
        except Exception as e:
            logger.debug(f"Auto-detection failed (non-fatal): {e}")
    if _opt_out_tool:
        logger.info(
            "Tool-call parser auto-detection disabled via --no-tool-call-parser"
        )
    if _opt_out_reasoning:
        logger.info(
            "Reasoning parser auto-detection disabled via --no-reasoning-parser"
        )

    # R12-S1: surface a startup warning when ``args.tool_call_parser``
    # is a ``deepseek_v3`` / ``deepseek_v31`` / ``deepseek_r1_0528``
    # binding but the model can't emit the matching V3 fenced-JSON wire
    # shape. See Sven r12 dogfood HIGH-1: forcing ``--tool-call-parser
    # deepseek_v3`` on ``DeepSeek-R1-Distill-Qwen-1.5B-4bit`` lands tool
    # calls with ``arguments="{}"`` because the parser correctly refuses
    # to parse the non-V3 prose the model emits.
    #
    # Runs on BOTH explicit overrides AND auto-detected bindings,
    # because ``detect_model_config`` still scans the full path — a
    # parent dir like ``/models/DeepSeek-V3/qwen-model`` can fool
    # auto-detect into ``deepseek_v3`` even though the tail model name
    # is out-of-lineage (pr-validate codex r7 BLOCKING). The helper's
    # canonical model-name classification catches that mis-pick that
    # auto-detect missed. Whether the user explicitly bound the flag is
    # tracked in ``_user_explicit_tool_call_parser`` and threaded into
    # the warning so the operator can tell who to blame: a misbound
    # flag (user error) vs. a fooled auto-detect (regex needs
    # tightening — tracked as follow-up so this PR stays scoped).
    try:
        from .model_auto_config import warn_misbound_deepseek_v3_parser

        misbind_warning = warn_misbound_deepseek_v3_parser(
            args.model, args.tool_call_parser
        )
        if misbind_warning:
            # ``logger.warning`` so the message lands in any structured
            # log sink AND surfaces in the terminal at the default
            # ``WARNING`` level (no stderr-print needed).
            # ``stacklevel=2`` so log frameworks attribute the call
            # site to the CLI entry rather than the helper module.
            logger.warning(misbind_warning, stacklevel=2)
            if not _user_explicit_tool_call_parser:
                # Auto-detect mis-pick. Emit a second WARNING line so
                # the operator knows the user didn't bind anything —
                # the ``detect_model_config`` regex was fooled by the
                # path. Forces the user to add an explicit
                # ``--tool-call-parser hermes`` (or similar) to recover
                # tool-call capability, which is the actually-correct
                # action for an out-of-lineage checkpoint.
                logger.warning(
                    "  Auto-detect note: this binding came from "
                    "AUTO-DETECT, not an explicit --tool-call-parser "
                    "flag. The detect_model_config() regex was fooled "
                    "by the path. Override with --tool-call-parser "
                    "hermes (or whatever your checkpoint actually "
                    "emits) to recover tool-call capability."
                )
    except Exception as e:  # noqa: BLE001
        logger.debug(f"deepseek_v3 misbind check failed (non-fatal): {e}")

    # Pass alias info to server (for /v1/models)
    server._model_alias = getattr(args, "_original_alias", None)

    # Configure server security settings. ``QMLX_API_KEY`` env var
    # is the secret-friendly form ``qmlx share`` uses to avoid
    # exposing the key in argv; inline ``--api-key`` overrides it for
    # backwards-compat with existing scripts. ``_resolve_api_key`` is
    # the single SSOT — both this entrypoint and the ``vllm_mlx.server``
    # ``python -m`` entry call into it, so a future policy tweak (e.g.
    # a deprecation warning when argv is used) lands in one place.
    server._api_key = server._resolve_api_key(args.api_key)
    server._default_timeout = args.timeout

    # Per-request body-size cap. Resolution order:
    #   1. ``--max-request-bytes`` (explicit CLI flag, including 0 to disable)
    #   2. ``QMLX_MAX_REQUEST_BYTES`` env var
    #   3. ``ServerConfig`` dataclass default (8 MiB)
    # See vllm_mlx/middleware/body_size.py for the DoS rationale.
    _max_body_arg = getattr(args, "max_request_bytes", None)
    if _max_body_arg is not None:
        server._max_request_bytes = max(0, int(_max_body_arg))
    else:
        _env_name = "QMLX_MAX_REQUEST_BYTES"
        _env = os.environ.get(_env_name, "").strip()
        if _env:
            try:
                server._max_request_bytes = max(0, int(_env))
            except ValueError:
                # Explicit reset (codex round-2 NIT): without this,
                # an in-process callsite that mutated ``_max_request_bytes``
                # before serve_command runs would silently leak a stale
                # value past a malformed env var, which is the worst
                # possible failure shape — bigger cap than the operator
                # intended. Fall back to the documented 8 MiB default
                # explicitly.
                server._max_request_bytes = 8 * 1024 * 1024
                logger.warning(
                    "%s=%r is not an integer; falling back to the 8 MiB default",
                    _env_name,
                    _env,
                )

    # SSE keepalive interval (F-070). Env-only (no CLI flag yet — keep
    # the surface small until operators ask for it). 0 disables. The
    # value lands on ``server._sse_keepalive_seconds`` so ``_sync_config``
    # propagates it into the live ``ServerConfig`` after ``load_model``;
    # writing the config singleton directly here would be clobbered by
    # the subsequent ``_sync_config`` (mirrors the ``_max_request_bytes``
    # pattern just above).
    _sse_env_name = "QMLX_SSE_KEEPALIVE_SECONDS"
    _sse_env = os.environ.get(_sse_env_name, "").strip()
    if _sse_env:
        try:
            server._sse_keepalive_seconds = max(0.0, float(_sse_env))
        except ValueError:
            # NOTE: the env-var name is interpolated via ``%s`` (not baked
            # into the format string) so the
            # ``tests/test_no_out_of_band_routing.py`` constant scan
            # doesn't see the literal ``QMLX_…=%r is not a number``
            # as a stand-alone string and false-positive on a routing
            # match. Same pattern the body-receive timeout block below
            # uses.
            logger.warning(
                "%s=%r is not a number; falling back to the 20 s default",
                _sse_env_name,
                _sse_env,
            )
            server._sse_keepalive_seconds = 20.0

    # Body-receive idle timeout (F-072 / H-14 slow-DoS gate). Env-only.
    # 0 disables. Same ``_sync_config``-then-route-handler ordering
    # rationale as the SSE keepalive above. Extracted into
    # :func:`_apply_body_receive_timeout_env` so tests can call the
    # SAME resolver the production binary uses — codex round-2 BLOCKING
    # on PR #786 flagged that an inline-only resolver couldn't be
    # exercised by a unit test without duplicating its logic, which
    # would mask a regression that deleted the wire-up entirely.
    _apply_body_receive_timeout_env(server, logger=logger)

    # Configure CORS (F-090 + F-091). Default: wildcard ``*`` for friendly
    # single-machine UX — qmlx is primarily run locally and a
    # browser frontend at ``http://localhost:3000`` hitting the API at
    # ``http://localhost:8000`` "just works". Operators on multi-tenant /
    # production deployments lock down via
    # ``QMLX_CORS_ALLOW_ORIGINS=https://your.app,https://other.app``.
    # The full env-var family (METHODS / HEADERS / MAX_AGE /
    # ALLOW_CREDENTIALS) still applies; see
    # ``vllm_mlx/server.py::configure_cors_from_env``.
    #
    # Wildcard + credentials is spec-invalid (Fetch spec rejects the
    # combination), so the resolver forces ``allow_credentials=False``
    # when ``*`` is in the origin list. Operators who need cookie /
    # ``Authorization`` auto-forwarding must pin to specific origins.
    cors_origins = server.configure_cors_from_env(args.cors_origins)
    if args.rate_limit > 0:
        server._rate_limiter = configure_rate_limiter(args.rate_limit, enabled=True)

    # Configure GC control
    gc_control = args.gc_control and not args.no_gc_control
    server._gc_control = gc_control

    # Configure --no-thinking: suppress chain-of-thought in chat template
    server._no_thinking = args.no_thinking

    # Configure system prompt pinning
    server._pin_system_prompt = args.pin_system_prompt

    # Configure tool calling
    if args.enable_auto_tool_choice and args.tool_call_parser:
        server._enable_auto_tool_choice = True
        server._tool_call_parser = args.tool_call_parser
        server._enable_tool_logits_bias = getattr(
            args, "enable_tool_logits_bias", False
        )
    else:
        server._enable_auto_tool_choice = False
        server._tool_call_parser = None
        server._enable_tool_logits_bias = False

    # Configure generation defaults
    if args.default_temperature is not None:
        server._default_temperature = args.default_temperature
    if args.default_top_p is not None:
        server._default_top_p = args.default_top_p
    if args.default_top_k is not None:
        server._default_top_k = args.default_top_k
    if args.default_min_p is not None:
        server._default_min_p = args.default_min_p
    if args.default_repetition_penalty is not None:
        server._default_repetition_penalty = args.default_repetition_penalty
    if args.default_presence_penalty is not None:
        server._default_presence_penalty = args.default_presence_penalty
    if args.default_frequency_penalty is not None:
        server._default_frequency_penalty = args.default_frequency_penalty

    # Configure reasoning parser
    if args.reasoning_parser:
        try:
            from .reasoning import get_parser

            parser_cls = get_parser(args.reasoning_parser)
            server._reasoning_parser = parser_cls()
            server._reasoning_parser_name = args.reasoning_parser
            logger.info(f"Reasoning parser enabled: {args.reasoning_parser}")
        except KeyError as e:
            print(f"Error: {e}")
            sys.exit(1)
        except ImportError as e:
            print(f"Error: Failed to import reasoning module: {e}")
            sys.exit(1)
        except Exception as e:
            print(
                f"Error: Failed to initialize reasoning parser "
                f"'{args.reasoning_parser}': {e}"
            )
            sys.exit(1)
    else:
        server._reasoning_parser = None

    # DFlash / DDTree mutual-exclusion gates fire BEFORE the startup banner so
    # the user sees a clean error instead of an optimistic "Features:
    # dflash" / "ddtree" line immediately followed by an exit. The deeper
    # SchedulerConfig mutex (suffix vs. mtp) stays below since it doesn't
    # involve the dedicated single-user servers.
    if args.enable_dflash and args.suffix_decoding:
        print(
            "\n  Error: DFlash cannot combine with other spec-decode methods. "
            "DFlash runs a dedicated single-user server that bypasses "
            "BatchedEngine; other spec-decode methods only apply to the "
            "BatchedEngine path.\n"
        )
        sys.exit(1)

    # DFlash eligibility gate fires here, BEFORE the startup banner —
    # so the user sees a clean error rather than an optimistic "DFlash
    # enabled" feature line followed by an exit. Cheap (just reads
    # aliases.json + checks the module spec); no model load yet.
    if args.enable_dflash:
        from .model_aliases import resolve_profile
        from .spec_decode.dflash import DFlashUnavailable, check

        # ``have_runtime()`` validated at the top-of-function boot-guard
        # tier — see the 0.9.2 dogfood comment near the audio probe.
        _alias_name = getattr(args, "_original_alias", None) or args.model
        _profile = resolve_profile(_alias_name)
        if _profile is None:
            print(
                f"\n  Error: DFlash requires a known alias, got "
                f"{_alias_name!r}. DFlash eligibility is recorded per-alias "
                f"in aliases.json; ad-hoc HuggingFace paths can't be "
                f"validated. Try ``qmlx info qwen3.5-27b-8bit``.\n"
            )
            sys.exit(1)
        try:
            check(_profile, alias=_alias_name)
        except DFlashUnavailable as e:
            print(f"\n  Error: {e}\n")
            sys.exit(1)
        # ``have_runtime()`` is already validated by the boot-guard tier
        # at the top of ``serve_command`` — see the 0.9.2 dogfood comment
        # there. We keep the import + the deeper DFlashUnavailable / alias
        # check here because they need the resolved profile, but the
        # extras-not-installed branch is unreachable by the time control
        # reaches this point.

        # Warn about flags that BatchedEngine honours but the DFlash
        # server doesn't — better to surface this once at startup than
        # to let users wonder why their tuning has no effect. Inspected
        # against the actual argparse Namespace so we only mention flags
        # the user explicitly set away from their default.
        _GPU_MEM_DEFAULT = 0.90  # keep in sync with the serve_parser default
        _dflash_ignored: list[str] = []
        if getattr(args, "enable_prefix_cache", False):
            _dflash_ignored.append("--enable-prefix-cache")
        if getattr(args, "kv_cache_quantization", None):
            _dflash_ignored.append("--kv-cache-quantization")
        # gpu-memory-utilization defaults to 0.90 (not None) in the serve
        # parser, so an ``is not None`` check would fire on every invocation.
        # Compare to the real default — only warn when the user explicitly
        # tuned it. Tolerate a tiny float-equality slack for safety.
        _gpu_mem = getattr(args, "gpu_memory_utilization", _GPU_MEM_DEFAULT)
        if _gpu_mem is not None and abs(_gpu_mem - _GPU_MEM_DEFAULT) > 1e-6:
            _dflash_ignored.append("--gpu-memory-utilization")
        if getattr(args, "enable_auto_tool_choice", False):
            _dflash_ignored.append("--enable-auto-tool-choice")
        if getattr(args, "tool_call_parser", None):
            _dflash_ignored.append("--tool-call-parser")
        if getattr(args, "reasoning_parser", None):
            _dflash_ignored.append("--reasoning-parser")
        if getattr(args, "mcp_config", None):
            _dflash_ignored.append("--mcp-config")
        if _dflash_ignored:
            print(
                "\n  ⚠ The following flags are ignored under DFlash"
                "\n    (DFlash uses a dedicated single-user server that bypasses"
                "\n    BatchedEngine):"
                f"\n      {', '.join(_dflash_ignored)}"
                "\n    Drop them from your serve command, or run without DFlash"
                "\n    if you need them.\n"
            )

    # DDTree eligibility gate mirrors DFlash: cheap alias/runtime checks
    # before the startup banner and before any model load.
    if args.enable_ddtree:
        _GPU_MEM_DEFAULT = 0.90
        _ddtree_ignored: list[str] = []
        if getattr(args, "enable_prefix_cache", False):
            _ddtree_ignored.append("--enable-prefix-cache")
        if getattr(args, "kv_cache_quantization", None):
            _ddtree_ignored.append("--kv-cache-quantization")
        _gpu_mem = getattr(args, "gpu_memory_utilization", _GPU_MEM_DEFAULT)
        if _gpu_mem is not None and abs(_gpu_mem - _GPU_MEM_DEFAULT) > 1e-6:
            _ddtree_ignored.append("--gpu-memory-utilization")
        if getattr(args, "enable_auto_tool_choice", False):
            _ddtree_ignored.append("--enable-auto-tool-choice")
        if getattr(args, "tool_call_parser", None):
            _ddtree_ignored.append("--tool-call-parser")
        if getattr(args, "reasoning_parser", None):
            _ddtree_ignored.append("--reasoning-parser")
        if getattr(args, "mcp_config", None):
            _ddtree_ignored.append("--mcp-config")
        if _ddtree_ignored:
            print(
                "\n  ⚠ The following flags are ignored under DDTree mode"
                "\n    (DDTree uses a dedicated experimental single-user "
                "server that bypasses BatchedEngine):"
                f"\n      {', '.join(_ddtree_ignored)}"
                "\n    Drop them from your serve command, or run without"
                "\n    DDTree if you need them.\n"
            )

    # Startup summary (issue #51: rich panel on a TTY, legacy block otherwise)
    print()
    _render_startup_banner(args, gc_control=gc_control, cors_origins=cors_origins)
    # Store MCP config path for FastAPI startup
    if args.mcp_config:
        os.environ["QMLX_MCP_CONFIG"] = args.mcp_config

    # R15 #300: resolve --kv-cache-dtype + --reasoning + safelist BEFORE
    # the legacy --kv-cache-quantization flag wins. When the legacy
    # --kv-cache-quantization flag is passed, honor it verbatim for
    # backwards compatibility; the new dtype flag only takes effect on
    # operators who haven't pinned the legacy bool.
    kv_cache_decision = None
    if not args.kv_cache_quantization:
        from .kv_cache_dtype import (
            dtype_to_quantization_bits,
            log_kv_cache_decision,
            resolve_kv_cache_dtype,
        )

        hf_cfg, alias_meta = _gather_kv_cache_dtype_inputs(args.model)
        kv_cache_decision = resolve_kv_cache_dtype(
            args.kv_cache_dtype,
            reasoning=args.reasoning,
            model_name=args.model,
            hf_path=(alias_meta or {}).get("hf_path"),
            hf_config=hf_cfg,
            alias_metadata=alias_meta,
        )
        log_kv_cache_decision(kv_cache_decision, model_name=args.model)
        quant, bits = dtype_to_quantization_bits(kv_cache_decision.dtype)
        # Mutate args so the existing SchedulerConfig wiring picks up
        # the resolved values without a second code path.
        args.kv_cache_quantization = quant
        args.kv_cache_quantization_bits = bits
        # Stash on the shared ServerConfig so /metrics surfaces the
        # effective dtype during the pre-engine load window — operator
        # uptime dashboards scrape within ms of process start.
        try:
            from vllm_mlx.config import get_config as _get_config

            _get_config().kv_cache_dtype = kv_cache_decision.dtype
        except Exception:
            # ServerConfig is best-effort observability; never block
            # serve start on a metrics-only side effect.
            pass
    elif args.kv_cache_quantization:
        # Legacy flag took precedence — synthesize a decision so
        # observability still has a single source of truth.
        from .kv_cache_dtype import (
            REASONING_KV_CACHE_DTYPE,
            KVCacheDtypeDecision,
        )

        # codex r1 BLOCKING #1: ``--reasoning`` must override the
        # legacy ``--kv-cache-quantization`` flag too — otherwise
        # ``qmlx serve --reasoning --kv-cache-quantization
        # --kv-cache-quantization-bits 4`` silently resolves to int4
        # and the operator who deliberately asked for the reasoning
        # profile gets the AIME-class quality cliff. Reject the
        # conflicting combo with an explicit error: silently flipping
        # the legacy bits to 8 would hide the misconfiguration.
        # bits=8 is equivalent to --reasoning's int8 pin and is
        # harmless; only bits=4 conflicts.
        if args.reasoning and args.kv_cache_quantization_bits == 4:
            print(
                "\n  Error: --reasoning is incompatible with "
                "--kv-cache-quantization --kv-cache-quantization-bits 4. "
                "The reasoning profile pins KV cache to int8 because "
                "sub-4-bit drops -20pt on AIME-class math. Either drop "
                "--reasoning or drop --kv-cache-quantization-bits 4 "
                "(or both; use --kv-cache-dtype int8 instead).\n"
            )
            sys.exit(1)

        # codex r2 BLOCKING #1: argparse pins ``--kv-cache-quantization-bits``
        # to ``choices={4,8}``, but programmatic callers (tests, library
        # users that bypass argparse) can land an out-of-range bits value
        # here. The old ``"int4" if bits == 4 else "int8"`` silently
        # labeled every non-4 value as ``int8`` even when KV would actually
        # be quantized at the requested bit width. Fail fast instead so
        # the gauge / banner / SchedulerConfig never lie about the
        # active dtype.
        if args.kv_cache_quantization_bits not in (4, 8):
            print(
                f"\n  Error: --kv-cache-quantization-bits must be 4 or 8 "
                f"(got {args.kv_cache_quantization_bits}). Use "
                f"--kv-cache-dtype for the canonical knob.\n"
            )
            sys.exit(1)
        legacy_dtype = "int4" if args.kv_cache_quantization_bits == 4 else "int8"
        # When --reasoning is set alongside the (compatible) bits=8
        # legacy flag, the operator-facing reason should still
        # advertise the reasoning profile so the startup banner is
        # consistent across the two CLI shapes.
        if args.reasoning:
            assert legacy_dtype == REASONING_KV_CACHE_DTYPE  # by the guard above
            reason = (
                f"legacy --kv-cache-quantization flag + --reasoning — "
                f"resolved to {REASONING_KV_CACHE_DTYPE} (reasoning profile "
                f"pin matches legacy bits=8)"
            )
        else:
            reason = (
                f"legacy --kv-cache-quantization flag (bits="
                f"{args.kv_cache_quantization_bits}) — equivalent to "
                f"--kv-cache-dtype {legacy_dtype}"
            )
        kv_cache_decision = KVCacheDtypeDecision(
            dtype=legacy_dtype,
            reason=reason,
            downgraded=False,
            requested=legacy_dtype,
        )
        try:
            from vllm_mlx.config import get_config as _get_config

            _get_config().kv_cache_dtype = legacy_dtype
        except Exception:
            pass

    # Build scheduler config
    enable_prefix_cache = args.enable_prefix_cache and not args.disable_prefix_cache

    # 0.9.13 PR-A codex round-E blocker #2: resolve model_type on the
    # CLI's asyncio thread and thread it down through SchedulerConfig
    # so the engine's model-load-executor dispatch step does not need
    # to re-read ``config.json`` (offline HF cache races vs. the CLI's
    # own read were being collapsed into a silent MTP no-op). Only
    # runs when the operator explicitly asked for MTP through
    # ``--speculative-config``; for the "none" path the field stays
    # None and the engine takes the pre-0.9.13 fallback branch that
    # best-effort re-reads the config on the executor.
    _cli_mtp_model_type: str | None = None
    if getattr(args, "spec_decode", "none") == "mtp":
        try:
            _hf_cfg_for_mtype, _ = _gather_kv_cache_dtype_inputs(args.model)
            if isinstance(_hf_cfg_for_mtype, dict):
                _mt = _hf_cfg_for_mtype.get("model_type")
                if isinstance(_mt, str):
                    _cli_mtp_model_type = _mt
        except Exception:  # pragma: no cover — best-effort
            _cli_mtp_model_type = None

    scheduler_config = SchedulerConfig(
        max_num_seqs=args.max_num_seqs,
        max_concurrent_requests=args.max_concurrent_requests,
        prefill_batch_size=args.prefill_batch_size,
        completion_batch_size=args.completion_batch_size,
        enable_prefix_cache=enable_prefix_cache,
        prefix_cache_size=args.prefix_cache_size,
        # Memory-aware cache options
        cache_memory_mb=args.cache_memory_mb,
        cache_memory_percent=args.cache_memory_percent,
        # Paged cache options
        use_paged_cache=args.use_paged_cache,
        paged_cache_block_size=args.paged_cache_block_size,
        max_cache_blocks=args.max_cache_blocks,
        # Server-side context cap (issue #33). ``0`` = no cap, so the
        # model's own max context length stays the binding limit. The
        # CLI <-> Config fidelity audit at
        # scripts/audit_cli_config_fidelity.py blocks merges where this
        # kwarg is missing at the construction site.
        max_context_length=args.max_context_length,
        # Chunked prefill
        chunked_prefill_tokens=args.chunked_prefill_tokens,
        # Prefill step size (chunk size). Must be plumbed here — BatchedEngine
        # reads it off scheduler_config only; the legacy load_model kwarg was
        # accepted but never used. See #400 and the CLI ↔ Config fidelity
        # audit at scripts/audit_cli_config_fidelity.py.
        prefill_step_size=args.prefill_step_size,
        # Speculative decoding selection.
        enable_mtp=getattr(args, "enable_mtp", False),
        mtp_num_draft_tokens=getattr(args, "mtp_num_draft_tokens", 1),
        mtp_optimistic=getattr(args, "mtp_optimistic", False),
        spec_decode=getattr(args, "spec_decode", "none"),
        dflash_drafter_path=getattr(args, "dflash_drafter_path", "") or "",
        # Optional external MTP sidecar path. ``None`` is the "no
        # sidecar; native-MTP path only" sentinel.
        mtp_sidecar=getattr(args, "mtp_sidecar", None),
        # 0.9.13 PR-A codex round-E blocker #2: CLI-resolved
        # ``config.json::model_type`` for the dispatch step. See the
        # ``_cli_mtp_model_type`` block above for why this is
        # resolved on the CLI thread instead of on the executor.
        mtp_model_type=_cli_mtp_model_type,
        # 0.9.13 PR-B: EV depth controller knobs.
        mtp_max_k=getattr(args, "mtp_max_k", 3),
        mtp_disable_auto_k=getattr(args, "mtp_disable_auto_k", False),
        # SuffixDecoding
        enable_suffix_decoding=args.suffix_decoding,
        suffix_max_draft=args.suffix_max_draft,
        suffix_max_suffix_len=args.suffix_max_suffix_len,
        suffix_min_confidence=args.suffix_min_confidence,
        suffix_min_draft_len=args.suffix_min_draft_len,
        # KV cache quantization (R15 #300: dtype string is the canonical
        # observability surface; ``_quantization`` / ``_bits`` are the
        # wire-level toggles that drive ``mlx_lm.QuantizedKVCache``).
        kv_cache_dtype=(
            kv_cache_decision.dtype if kv_cache_decision is not None else "bf16"
        ),
        kv_cache_quantization=args.kv_cache_quantization,
        kv_cache_quantization_bits=args.kv_cache_quantization_bits,
        kv_cache_quantization_group_size=args.kv_cache_quantization_group_size,
        kv_cache_min_quantize_tokens=args.kv_cache_min_quantize_tokens,
        # R15-P1 (task #296): disk-backed KV checkpointing at 256-tok
        # boundaries. ``0`` disables; the runtime module guards every
        # hot-path call with ``should_checkpoint`` so the cost when off
        # is one int comparison.
        kv_disk_checkpoint_interval=getattr(args, "kv_disk_checkpoint_interval", 256),
        # SSD-first (#16): restore-on-miss is on by default; --disable-disk-kv-restore
        # opts out. Mirrors the --enable/--disable-prefix-cache pattern.
        kv_disk_restore_enabled=(
            getattr(args, "enable_disk_kv_restore", True)
            and not getattr(args, "disable_disk_kv_restore", False)
        ),
        # D-METAL-CAP: thread the user's --gpu-memory-utilization into
        # SchedulerConfig so the admission gate enforces the same cap
        # that the device backend's memory limit only treats as a
        # guideline. The
        # CLI ↔ Config fidelity audit blocks merges where this kwarg
        # exists on SchedulerConfig but is missing at the construction
        # site — without this line, ``--gpu-memory-utilization 0.45``
        # would still set the soft Metal hint but the admission-time
        # check would stay disabled (SchedulerConfig default 0.0),
        # silently recreating the D-METAL-CAP regression.
        gpu_memory_utilization=args.gpu_memory_utilization,
    )

    # Startup config dump (issue #51: rich panel on a TTY, legacy
    # "Key: value" lines elsewhere — byte-identical plain output).
    _render_config_dump(
        args,
        scheduler_config,
        enable_prefix_cache=enable_prefix_cache,
        logger=logger,
    )

    # Check port availability before loading model (avoid wasting RAM on conflict).
    # Set SO_REUSEADDR to match uvicorn's bind behavior — without it, this
    # preflight fails on a port still in TCP TIME_WAIT (e.g. just after a
    # previous qmlx process exited), even though uvicorn would happily
    # bind it. Caused spurious "port in use" errors for back-to-back server
    # starts in the validation pipeline.
    #
    # Skip in --listen-fd mode: the supervisor has already bound the socket
    # and handed us the fd. There is no host/port for us to check, and any
    # bind we attempt here would race or collide with the inherited socket.
    if getattr(args, "listen_fd", None) is None:
        # Shared helper so the legacy ``python -m vllm_mlx.server``
        # entrypoint (vllm_mlx/server.py) can call the same probe
        # without duplicating the wildcard-alias / loopback-shadow
        # logic. See ``_port_preflight_or_die`` for why we probe both
        # the requested host AND 127.0.0.1 when the requested host is
        # a wildcard alias.
        _port_preflight_or_die(args.host, args.port, model=args.model)

    # Alias-level unified-memory floor (codex #1069 round 3 [NIT #3]).
    # Fires BEFORE _check_disk_space so the user sees the actionable
    # "your Mac is too small for this Ultra-only alias" hint before we
    # start a 166 GB download.
    _check_alias_min_memory(args.model)

    # Check disk space before downloading model
    _check_disk_space(args.model, force=getattr(args, "force_disk_check", False))

    # Pre-flight memory check — warn (don't abort) if model + working set
    # would push unified memory past the kernel-panic threshold (issue #324).
    _check_memory_capacity(args.model)

    # DFlash fork: when method=dflash is set, skip BatchedEngine entirely
    # and run the dedicated DFlash server. The eligibility check above has
    # already validated the alias, so by here we have a known-good profile.
    if args.enable_dflash:
        # DFlash IS a speculative-decode path. The --no-spec-decode escape
        # hatch (SOP §10) must reject it here — otherwise the user thinks
        # they've disabled spec-decode but DFlash silently proceeds via
        # its dedicated server, never touching EngineCore / ModelConfig.
        if getattr(args, "no_spec_decode", False):
            print(
                "error: DFlash and --no-spec-decode are mutually "
                "exclusive — DFlash is a speculative-decode mode.",
                file=sys.stderr,
            )
            sys.exit(2)
        from .model_aliases import resolve_profile
        from .spec_decode.dflash.server import run_dflash_server

        _alias_name = getattr(args, "_original_alias", None) or args.model
        _profile = resolve_profile(_alias_name)
        # The eligibility check at top of serve_command guarantees this
        # passes — assert to be defensive against future refactors.
        assert (
            _profile is not None and _profile.supports_dflash
        ), f"DFlash profile invariant violated for {_alias_name!r}"
        # The vLLM-style surface uses ``model`` for the drafter override.
        run_dflash_server(
            main_model_repo=_profile.hf_path,
            drafter_repo=_resolve_dflash_drafter_repo(args, _profile),
            host=args.host,
            port=args.port,
            served_model_name=args.served_model_name or _alias_name,
            default_max_tokens=effective_max_tokens,
            cors_origins=cors_origins,
            uvicorn_log_level=uvicorn_log_level,
            no_thinking=args.no_thinking,
        )
        return

    # DDTree fork: same blast-radius boundary as DFlash. It is a
    # speculative-decode mode, but the MVP runs through the external
    # dtree-mlx runtime rather than BatchedEngine.
    if args.enable_ddtree:
        from .spec_decode.ddtree.server import run_ddtree_server

        _alias_name = getattr(args, "_ddtree_alias_name", None)
        _profile = getattr(args, "_ddtree_profile", None)
        if _alias_name is None or _profile is None:
            _alias_name, _profile = _preflight_ddtree_or_exit(args)
        assert (
            _profile is not None and _profile.supports_ddtree
        ), f"DDTree profile invariant violated for {_alias_name!r}"
        assert _profile.ddtree_draft_model is not None
        assert _profile.ddtree_speculative_tokens is not None
        assert _profile.ddtree_tree_budget is not None
        run_ddtree_server(
            main_model_repo=_profile.hf_path,
            drafter_repo=getattr(args, "_ddtree_drafter_repo", None)
            or _profile.ddtree_draft_model,
            speculative_tokens=getattr(args, "_ddtree_speculative_tokens", None)
            or _profile.ddtree_speculative_tokens,
            tree_budget=getattr(args, "_ddtree_tree_budget", None)
            or _profile.ddtree_tree_budget,
            host=args.host,
            port=args.port,
            served_model_name=args.served_model_name or _alias_name,
            default_max_tokens=args.max_tokens,
            cors_origins=cors_origins,
            uvicorn_log_level=uvicorn_log_level,
            no_thinking=args.no_thinking,
            api_key=server._api_key,
        )
        return

    # Load model with unified server
    if args.mllm and args.no_mllm:
        print(
            "error: --mllm and --no-mllm are mutually exclusive — "
            "pick one to override auto-detection.",
            file=sys.stderr,
        )
        sys.exit(2)
    if getattr(args, "force_hybrid", False) and getattr(args, "no_hybrid", False):
        print(
            "error: --force-hybrid and --no-hybrid are mutually exclusive — "
            "pick one to override auto-detection.",
            file=sys.stderr,
        )
        sys.exit(2)
    if getattr(args, "force_spec_decode", False) and getattr(
        args, "no_spec_decode", False
    ):
        print(
            "error: --force-spec-decode and --no-spec-decode are mutually "
            "exclusive — pick one to override auto-detection.",
            file=sys.stderr,
        )
        sys.exit(2)
    if getattr(args, "force_openai_harmony_streaming", False) and getattr(
        args, "no_openai_harmony_streaming", False
    ):
        print(
            "error: --force-openai-harmony-streaming and "
            "--no-openai-harmony-streaming are mutually exclusive — pick one "
            "to override the HarmonyStreamingRouter auto-upgrade gate (#516).",
            file=sys.stderr,
        )
        sys.exit(2)
    try:
        load_model(
            args.model,
            scheduler_config=scheduler_config,
            stream_interval=args.stream_interval,
            max_tokens=effective_max_tokens,
            max_tokens_is_explicit=_max_tokens_is_explicit,
            force_mllm=args.mllm,
            force_text=args.no_mllm,
            gpu_memory_utilization=args.gpu_memory_utilization,
            cloud_model=args.cloud_model,
            cloud_threshold=args.cloud_threshold,
            cloud_api_base=args.cloud_api_base,
            cloud_api_key=args.cloud_api_key,
            served_model_name=args.served_model_name,
            force_hybrid=getattr(args, "force_hybrid", False),
            no_hybrid=getattr(args, "no_hybrid", False),
            force_spec_decode=getattr(args, "force_spec_decode", False),
            no_spec_decode=getattr(args, "no_spec_decode", False),
            force_openai_harmony_streaming=getattr(
                args, "force_openai_harmony_streaming", False
            ),
            no_openai_harmony_streaming=getattr(
                args, "no_openai_harmony_streaming", False
            ),
        )
    except Exception as e:
        # Show clean error instead of raw traceback. Catch the typed
        # HF exception class for the 404 case; fall back to substring
        # match for legacy callers (older huggingface_hub) and for
        # non-HF errors that still spell out "not found".
        from huggingface_hub.utils import RepositoryNotFoundError

        is_404 = isinstance(e, RepositoryNotFoundError) or (
            "404" in str(e) or "not found" in str(e).lower()
        )
        if is_404:
            shown = getattr(args, "_original_alias", args.model)
            print(f"\n  Error: Model '{shown}' not found on HuggingFace.")
            _print_unknown_model_help(
                shown, full_path_example="mlx-community/Qwen3.5-9B-4bit"
            )
        else:
            print(f"\n  Error loading model: {e}")
        sys.exit(1)

    # Start server
    # Note: Metal shader warmup runs in the FastAPI lifespan hook (server.py).
    # The "Ready:" banner is printed FROM that hook once warmup completes and
    # the port is actually bound — printing it here would lie to users who
    # curl immediately and get connection-refused while shaders compile.
    host_display = "localhost" if args.host == "0.0.0.0" else args.host
    listen_fd = getattr(args, "listen_fd", None)
    live = bool(getattr(args, "live", False))
    if not live:
        print()
    if live and listen_fd is None and not ui.rich:
        # issue #51 phase 3: the strip needs a TTY + rich. Plain mode
        # (pipe / NO_COLOR / QMLX_PLAIN=1) emits the one info line and
        # runs the usual blocking uvicorn path below.
        print()
        print("  --live: plain mode — no live strip. Use `qmlx status`")
        print("          (or `qmlx status --watch`) for a one-shot view.")
    elif live and listen_fd is not None:
        # Socket activation: the strip is driven in-process, but under
        # supervisor-managed fd handoff there is normally no TTY at all.
        # Keep it a no-op with an honest info line (issue #51).
        print()
        print("  --live: no-op with --listen-fd (no terminal to drive).")
    if listen_fd is not None:
        # Socket activation path — supervisor pre-bound the listening
        # socket. We don't know the actual address from the fd without a
        # ``getsockname`` lookup; surfacing fd=<N> in the banner is the
        # honest thing to print here.
        print(
            f"  Starting server on inherited fd {listen_fd} "
            "(warming up — this can take a few seconds)"
        )
    else:
        # issue #61: the endpoint line prints in ALL modes, including
        # ``--live`` rich mode. The live strip only shows the endpoint
        # after ``ready`` flips, so without this line a 100x30
        # operator sees no URL during the whole warming-up phase.
        print(
            f"  Starting server on http://{host_display}:{args.port} (warming up — this can take a few seconds)"
        )
    from vllm_mlx._version_check import print_staleness_warning_if_any

    print_staleness_warning_if_any()
    print()

    # Stash the source of truth for the lifespan "Ready:" banner —
    # which shape depends on the bind mode:
    #
    #   * Default (host+port): stamp ``bind_host``/``bind_port`` so the
    #     banner prints ``Ready: http://host:port/v1``.
    #   * ``--listen-fd``: stamp ``bind_listen_fd`` instead. The
    #     supervisor's ``getsockname`` is the only honest source for the
    #     address — stamping ``args.host``/``args.port`` here would lie
    #     to log readers (the supervisor might have bound to a different
    #     address). Codex rounds 1+3 PR #696 review.
    from vllm_mlx.config import get_config

    # Always reset BOTH source-of-truth fields before stamping the
    # active branch — the singleton config persists across in-process
    # ``serve_command`` invocations (test harnesses, embedded usage), so
    # a prior host/port stash would otherwise take precedence over a
    # subsequent fd stash (and vice-versa) and the Ready banner would
    # lie about which listener is live. Codex round-4 PR #696 review.
    _cfg = get_config()
    _cfg.bind_host = None
    _cfg.bind_port = None
    _cfg.bind_listen_fd = None
    if listen_fd is None:
        _cfg.bind_host = host_display
        _cfg.bind_port = args.port
    else:
        _cfg.bind_listen_fd = listen_fd
    # ``--live`` (issue #51): the strip shows the endpoint on the ready
    # flip — suppress the one-shot "Ready:" banner on that path only.
    _cfg.suppress_ready_banner = bool(live and ui.rich and listen_fd is None)

    if live and ui.rich and listen_fd is None:
        _run_uvicorn_live(app, args, uvicorn_log_level)
    else:
        _run_uvicorn(app, args, uvicorn_log_level)


def _format_bytes(n: int) -> str:
    """Render a byte count as a 1-decimal IEC-suffixed string (GiB/MiB/KiB).

    Picks the largest unit where the value is >= 1; falls back to bytes.
    Returns ``"0 B"`` for zero / negative.

    Aligned with ``vllm_mlx._download_gate._format_size`` so the same
    byte count rendered by ``ls --cached`` and by the B2 confirmation
    prompt uses the same suffix convention (Codex/DeepSeek round-3 NIT:
    ``5.0 G`` vs ``5.0 GiB`` for the same model is the kind of paper-
    cut that makes users think two screens are talking about different
    sizes).
    """
    if n <= 0:
        return "0 B"
    for unit, factor in (
        ("GiB", 1024**3),
        ("MiB", 1024**2),
        ("KiB", 1024),
    ):
        if n >= factor:
            return f"{n / factor:.1f} {unit}"
    return f"{n} B"


def _dir_size_bytes(path: str) -> int:
    """Recursive on-disk size of ``path`` (follows blob symlinks).

    HF cache stores model weights as ``blobs/<sha>`` files referenced via
    symlinks under ``snapshots/<rev>/<file>``. ``os.scandir`` recurses
    through both — we follow links so a snapshot's reported size matches
    the user's mental model of "how much disk this model uses".
    """
    total = 0
    try:
        for entry in os.scandir(path):
            try:
                if entry.is_dir(follow_symlinks=False):
                    total += _dir_size_bytes(entry.path)
                else:
                    # follow_symlinks=True so blob symlinks count their
                    # underlying file size, matching ``du -sL``.
                    total += entry.stat(follow_symlinks=True).st_size
            except OSError:
                continue
    except OSError:
        return total
    return total


def _scan_hf_cache_models() -> list[tuple[str, int, float]]:
    """Return ``[(hf_repo, size_bytes, last_modified_epoch), ...]`` for every
    ``models--<org>--<name>`` directory in the HF cache.

    Empty list when the cache dir doesn't exist (fresh install) or has no
    model entries (e.g. only datasets were downloaded). Datasets/spaces
    (``datasets--*``, ``spaces--*``) are deliberately skipped.
    """
    try:
        from huggingface_hub.constants import HF_HUB_CACHE
    except Exception:
        HF_HUB_CACHE = os.path.expanduser("~/.cache/huggingface/hub")
    if not os.path.isdir(HF_HUB_CACHE):
        return []
    out: list[tuple[str, int, float]] = []
    for name in os.listdir(HF_HUB_CACHE):
        if not name.startswith("models--"):
            continue
        # ``models--org--name`` → ``org/name``. Some legacy entries are
        # ``models--name`` (no org) for single-segment repos; pass those
        # through unchanged so the user still sees them in the listing.
        parts = name[len("models--") :].split("--", 1)
        repo = "/".join(parts) if len(parts) == 2 else parts[0]
        full = os.path.join(HF_HUB_CACHE, name)
        try:
            mtime = os.path.getmtime(full)
        except OSError:
            mtime = 0.0
        size = _dir_size_bytes(full)
        out.append((repo, size, mtime))
    return out


def _print_cached_models() -> None:
    """Render the ``--cached`` view: locally-downloaded HF cache entries
    cross-referenced against the alias registry.

    Each row: ``Alias | HF repo | Size on disk | Last modified``. Models
    not in the alias registry are shown with alias=``(unmapped)`` so the
    user still sees what's eating disk space. Empty cache prints a hint
    pointing at ``pull`` / ``chat``.
    """
    import time as _time

    from vllm_mlx.model_aliases import list_profiles

    rows = _scan_hf_cache_models()
    print()
    if not rows:
        print(
            "  No models cached yet. Run 'qmlx pull <alias>' or "
            "'qmlx chat <alias>' to download one."
        )
        print()
        return

    # Reverse-map HF repo path → alias name so the alias column matches the
    # user's mental model (``qwen3.5-4b-4bit`` not ``mlx-community/Qwen3.5-4B...``).
    profiles = list_profiles()
    hf_to_alias: dict[str, str] = {}
    for alias, p in profiles.items():
        hf_to_alias.setdefault(p.hf_path, alias)

    cols = (
        ("Alias", 22),
        ("HF repo", 50),
        ("Size", 9),
        ("Modified", 12),
    )
    width = sum(w for _, w in cols) + len(cols) - 1
    sep = "  " + "─" * width
    header = "  " + " ".join(f"{name:<{w}}" for name, w in cols)
    print(f"  Cached models ({len(rows)} on disk)")
    print(sep)
    print(header)
    print(sep)

    now = _time.time()
    total_bytes = 0
    # Sort by size descending so the biggest-disk-hog row is first — the
    # most useful ordering for "what do I rm to free space?".
    for repo, size, mtime in sorted(rows, key=lambda r: -r[1]):
        total_bytes += size
        alias = hf_to_alias.get(repo, "(unmapped)")
        # Render modified as a human delta: "2 days ago" beats raw epoch.
        if mtime <= 0:
            mod = "?"
        else:
            delta = max(0, int(now - mtime))
            if delta < 3600:
                mod = f"{delta // 60}m ago"
            elif delta < 86400:
                mod = f"{delta // 3600}h ago"
            else:
                mod = f"{delta // 86400}d ago"
        # Truncate over-long HF paths so the row doesn't wrap on a
        # narrow terminal; the alias column carries the canonical name.
        repo_disp = repo if len(repo) <= 50 else (repo[:47] + "...")
        print(f"  {alias:<22} {repo_disp:<50} {_format_bytes(size):<9} {mod:<12}")
    print(sep)
    print(f"  Total: {_format_bytes(total_bytes)}")
    print()
    print("  Tip: `qmlx rm <hf-repo>` to free disk space")
    print()


def _installed_alias_set(profiles) -> set[str]:
    """Aliases whose weights are already local (issue #62: sort first).

    ``is_repo_cached`` (vllm_mlx/_download_gate.py) is the same
    weight-file-presence probe ``qmlx serve`` / ``qmlx chat`` use to
    decide whether a resolved path is loadable: the ``refs/main``-pinned
    snapshot must contain the ``model*.safetensors`` shards mlx-lm's
    loader globs. A config.json-only partial cache (interrupted pull)
    or a cached non-existence sentinel does not count as installed
    (review m4 on PR #64). Purely local — no network, no hang.
    """
    from vllm_mlx._download_gate import is_repo_cached

    installed: set[str] = set()
    for alias, p in profiles.items():
        hf = getattr(p, "hf_path", None)
        if hf and is_repo_cached(hf):
            installed.add(alias)
    return installed


def models_command(args):
    """List available model aliases with their per-model profile capabilities.

    Default view pulls from ``list_profiles()`` so every alias's
    ``tool_call_parser`` / ``reasoning_parser`` / ``is_hybrid`` /
    ``supports_spec_decode`` / ``suffix_decoding_tier`` shows up — letting
    users pick a model on capabilities, not just on name.

    Cells with no information render blank (issue #62): unset parsers, an
    unbenched suffix tier (``unknown``), an unbenched DFlash/DDTree gate
    (no ``✓``), and a plain unsupported spec-decode all leave the cell
    empty. Only positive, decision-relevant facts are printed — the data
    gap is not the star of the table.

    ``--cached`` swaps to a disk-only view: scans the HuggingFace cache,
    cross-references against the alias registry, and renders
    ``Alias | HF repo | Size on disk | Last modified``. Also reachable as
    the top-level ``qmlx ls`` alias.

    The default view presents the qwen3.* catalog only (2026-10-23
    operator directive — the CLI's available-models surface is
    qwen3.*-only; the bring-up model Qwen3.5-9B-4bit is the canonical
    served model). Non-qwen3 aliases stay resolvable by explicit name or
    full HF path; they are simply not listed.
    """
    from vllm_mlx._version_check import print_staleness_warning_if_any
    from vllm_mlx.model_aliases import list_visible_profiles

    print_staleness_warning_if_any()

    if getattr(args, "cached", False):
        _print_cached_models()
        return

    profiles = list_visible_profiles()
    rows: list[tuple[str, ...]] = []
    for alias in sorted(profiles.keys()):
        p = profiles[alias]
        # Blank the absent cells (issue #62): a wall of "unknown" / "—" /
        # "✗" read as data when it is only the registry admitting it has
        # no number yet. Unset → ""; a positive capability stays "✓".
        tools = p.tool_call_parser or ""
        reasoning = p.reasoning_parser or ""
        if p.is_hybrid:
            # Hybrid models cannot use spec-decode or suffix-decode regardless
            # of the supports_spec_decode flag (mlx-lm BatchGenerator gate).
            # The "hybrid" marker is itself the data — keep it.
            spec = "hybrid"
            tier = ""
        else:
            spec = "✓" if p.supports_spec_decode else ""
            tier = (
                ""
                if p.suffix_decoding_tier in ("unknown", "n/a")
                else str(p.suffix_decoding_tier)
            )
        # DFlash column — eligible aliases show ✓, everything else blank
        # (issue #62: a column that is "—" for 50 of 51 rows is a wall,
        # not data). We don't re-run the eligibility gate here (which would
        # also check that mlx-vlm 0.5.0+ is installed) — that's a runtime
        # concern; the registry column is pure declarative state.
        dflash = "✓" if p.supports_dflash else ""
        ddtree = "✓" if p.supports_ddtree else ""
        rows.append((alias, tools, reasoning, spec, tier, dflash, ddtree))

    # issue #62 (defect 1): installed rows first, then a terminal-height
    # cap on the TTY path so the column header can never scroll off the
    # top of the screen. The overflow collapses into a one-line pointer
    # at ``--all``. Pipe output stays uncapped (script-safe).
    installed = _installed_alias_set(profiles)
    rows.sort(
        key=lambda r: 0 if r[0] in installed else 1
    )  # stable: alpha within groups

    truncated_count = 0
    term_cols, term_lines = (80, 24)
    if ui.rich:
        term_cols, term_lines = shutil.get_terminal_size(fallback=(80, 24))
        if not getattr(args, "all_models", False):
            # Fixed chrome: leading blank + title + blank + table top border /
            # header / separator / bottom border (4) + trailing blank + the
            # 4-line tip block = 12 lines; the pointer line below reserves
            # one more when truncating. With the single-line-row contract
            # (M1, issue #62) every row renders as exactly one line, so
            # chrome + keep + pointer = term_lines exactly.
            max_rows = term_lines - 12
            if 0 < max_rows < len(rows):
                # Reserve one line for the "… N more" pointer when truncating.
                keep = max_rows - 1 if max_rows >= 2 else max_rows
                truncated_count = len(rows) - keep
                rows = rows[:keep]

    # issue #62 (defect 3): installed-vs-available marker. The registry
    # knows exactly what is local (``installed`` above) — lead those rows
    # with "● " and dim the pullable remainder on the TTY path. Plain
    # (pipe) mode gets the same prefix, no dimming (no ANSI there).
    # The prefix rides inside the alias field: alias_width = longest+2
    # leaves exactly 2 spare columns, so no column width changes.
    row_styles: list[str | None] = []
    marked_rows: list[tuple[str, ...]] = []
    for r in rows:
        if r[0] in installed:
            marked_rows.append(("● " + r[0], *r[1:]))
            row_styles.append(None)
        else:
            marked_rows.append(r)
            row_styles.append("dim")
    rows = marked_rows

    local_n = len(installed)
    title = f"  Available models ({len(profiles)} aliases)"
    if local_n:
        title += f" — {local_n} local"

    print()
    print(title)
    if ui.rich:
        # issue #51: bordered rich table (auto widths) instead of the
        # hand-computed fixed layout below.
        print()
        headers = [
            ("Alias", None),
            ("Tools", None),
            ("Reasoning", None),
            ("Spec-Decode", None),
            ("Suffix Tier", None),
            ("DFlash", None),
            ("DDTree", None),
        ]
        # issue #62 (M1): exactly one rendered line per row at any width.
        # rich's auto-width shrinks the Alias column below the longest
        # "● <alias>" cell at narrow widths, folding those cells (and
        # wrapping the "Suffix Tier" header) into 2-3 lines — which broke
        # the chrome/row-count assumption above. Clip the alias with "…"
        # so the table's desired width fits the terminal: the six fixed
        # columns keep their full content width, the Alias column absorbs
        # the remainder. Overhead = 3*n_cols - 1 (n_cols border lines +
        # 2 padding per column minus the two pad_edge corners, pad_edge is
        # off in rich_table).
        col_w = [
            max(len(h[0] if isinstance(h, tuple) else h), *(len(r[i]) for r in rows))
            for i, h in enumerate(headers)
        ]
        alias_budget = term_cols - (3 * len(headers) - 1) - sum(col_w[1:])
        if rows and 0 < alias_budget < max(len(r[0]) for r in rows):
            rows = [
                (r[0][: alias_budget - 1] + "…", *r[1:])
                if len(r[0]) > alias_budget
                else r
                for r in rows
            ]
        ui.rich_table(
            headers,
            rows,
            footer=[
                "Tip: `qmlx info <alias>` for the full per-model profile",
                "`qmlx pull <alias>` to download",
                "`qmlx chat <alias>` for an interactive REPL",
                "`qmlx serve <alias>` for an OpenAI-compatible server",
            ],
            style="cyan",
            row_styles=row_styles,
        )
        if truncated_count:
            print(f"  … {truncated_count} more — full list: `qmlx models --all`")
        print()
        return

    # Alias width is computed from the actual registry so new long names
    # (e.g. ``deepseek-coder-v2-lite-16b-4bit``, 31 chars) don't push the
    # rest of their row out of column alignment. 24 is the historical
    # floor — never shrink below it so short rows still feel padded.
    # Other widths sized to fit values currently in aliases.json:
    # tool 16 (qwen3_coder_xml + 1 pad), reasoning 12 (deepseek_r1 + 1),
    # spec 10 ("✗ hybrid"), tier 11, dflash 7, ddtree 7.
    alias_width = max(24, max((len(a) for a in profiles), default=0) + 2)
    cols = (
        ("Alias", alias_width),
        ("Tools", 16),
        ("Reasoning", 12),
        ("Spec-Decode", 10),
        ("Suffix Tier", 11),
        ("DFlash", 7),
        ("DDTree", 7),
    )
    width = sum(w for _, w in cols) + len(cols) - 1
    sep = "  " + "─" * width
    header = "  " + " ".join(f"{name:<{w}}" for name, w in cols)
    print(sep)
    print(header)
    print(sep)

    for row in rows:
        row = (
            f"  {row[0]:<{alias_width}} {row[1]:<16} {row[2]:<12} "
            f"{row[3]:<10} {row[4]:<11} {row[5]:<7} {row[6]:<7}"
        )
        print(row)

    print(sep)

    print()
    print("  Tip: `qmlx info <alias>` for the full per-model profile")
    print("       `qmlx pull <alias>` to download")
    print("       `qmlx chat <alias>` for an interactive REPL")
    print("       `qmlx serve <alias>` for an OpenAI-compatible server")
    print()


def _format_pull_duration(seconds: float) -> str:
    """Render a duration as ``Xs`` (< 60s) or ``Xm Ys`` (>= 60s).

    Sub-minute keeps one decimal so a 4.2s pull doesn't read as ``4s``;
    once we cross a minute the decimals are noise. ``round`` (not
    ``int``) on the whole-second branch means ``119.9s`` reads as
    ``2m 0s`` instead of ``1m 59s``.
    """
    if seconds < 0:
        seconds = 0.0
    if seconds < 60:
        return f"{seconds:.1f}s"
    total = int(round(seconds))
    minutes, secs = divmod(total, 60)
    return f"{minutes}m {secs}s"


def _snapshot_size_bytes(path) -> int:
    """Sum file sizes under ``path`` (recursively, following symlinks).

    The HF cache stores ``snapshots/<rev>/<file>`` as symlinks into
    ``blobs/<sha>``; ``stat()`` follows the link so the byte count is
    the real on-disk weight, matching what the user just downloaded.
    Quietly tolerates partial / missing trees so the summary line is
    a print, not a crash, in degenerate cache states.
    """
    from pathlib import Path

    root = Path(path)
    if not root.exists():
        return 0
    total = 0
    try:
        for entry in root.rglob("*"):
            try:
                if entry.is_file():
                    total += entry.stat().st_size
            except OSError:
                continue
    except OSError:
        pass
    return total


def _print_pull_summary(repo_id: str, snapshot_dir, elapsed: float) -> None:
    """Emit the pull completion summary (panel on a TTY, one line in plain)."""
    size = _snapshot_size_bytes(snapshot_dir)
    duration = _format_pull_duration(elapsed)
    if ui.rich:
        ui.panel(
            "pull complete",
            [
                f"[cyan]{repo_id}[/cyan]  [green]{_format_bytes(size)}[/green]  in {duration}"
            ],
            plain_lines=[],
            style="green",
        )
        return
    print(
        f"  Downloaded {repo_id} — {_format_bytes(size)} in "
        f"{_format_pull_duration(elapsed)}"
    )


def pull_command(args):
    """Download a model to the HuggingFace cache without serving."""
    import time

    from huggingface_hub import snapshot_download
    from huggingface_hub.errors import HFValidationError
    from huggingface_hub.utils import RepositoryNotFoundError

    repo_id = args.model  # already alias-resolved by main()
    t0 = time.monotonic()

    # R2-first / HuggingFace-fallback per file. Default mirror is
    # ``https://models.rapidmlx.com``; set ``QMLX_MODEL_MIRROR=""``
    # to force HF only. The function prints its own progress + summary.
    if _try_mirror_prefetch(repo_id):
        from pathlib import Path

        try:
            from huggingface_hub.constants import HF_HUB_CACHE

            cache_root = Path(HF_HUB_CACHE)
        except Exception:
            cache_root = Path.home() / ".cache" / "huggingface" / "hub"
        owner, _, repo = repo_id.partition("/")
        repo_root = cache_root / f"models--{owner}--{repo}"
        try:
            rev = (repo_root / "refs" / "main").read_text().strip()
            snapshot_dir = repo_root / "snapshots" / rev
            print(f"  Cached at: {snapshot_dir}")
        except OSError:
            snapshot_dir = repo_root
            print(f"  Cached at: {repo_root}")
        _print_pull_summary(repo_id, snapshot_dir, time.monotonic() - t0)
        return
    # Mirror returned False — fall through to plain snapshot_download.
    # Either the catalog was unreachable, the alias isn't catalog-listed,
    # or one or more files failed both R2 and HF in the per-file pool.
    # snapshot_download will retry from HF with its own (more robust)
    # error reporting.
    print(f"\n  Pulling {repo_id} from HuggingFace ...")
    try:
        path = snapshot_download(repo_id)
    except HFValidationError:
        # Malformed HF repo id (e.g. ``foo/bar/baz``) — surface the same
        # friendly "unknown model" hint the alias path uses instead of a
        # raw stack trace.
        shown = getattr(args, "_original_alias", repo_id)
        print(
            f"\n  Error: '{shown}' is not a valid HuggingFace repo id "
            "(expected ``namespace/name``)."
        )
        _print_unknown_model_help(
            shown, full_path_example="mlx-community/Qwen3.5-9B-4bit"
        )
        sys.exit(1)
    except Exception as e:
        is_404 = isinstance(e, RepositoryNotFoundError) or (
            "404" in str(e) or "not found" in str(e).lower()
        )
        if is_404:
            shown = getattr(args, "_original_alias", repo_id)
            print(f"\n  Error: Model '{shown}' not found on HuggingFace.")
            _print_unknown_model_help(
                shown, full_path_example="mlx-community/Qwen3.5-9B-4bit"
            )
            sys.exit(1)
        raise
    print(f"  Cached at: {path}")
    _print_pull_summary(repo_id, path, time.monotonic() - t0)


def rm_command(args):
    """Remove a model from the HuggingFace cache.

    Default flow prompts for confirmation, defaulting to N — a real user
    typo (``qmlx rm qwn3.5-9b-4bit`` → matches a 6 GB model) could
    silently nuke gigabytes of weights pre-0.9.7. EOF (non-TTY pipe,
    ctrl-D) also cancels rather than being treated as accept-by-default.
    ``-y/--yes`` skips the prompt for scripts.
    """
    from huggingface_hub import scan_cache_dir

    repo_id = args.model
    cache = scan_cache_dir()
    # Filter by repo_type=="model" — same repo_id can refer to a dataset or
    # space, and we don't want ``qmlx rm foo`` deleting a dataset.
    matching = [
        r for r in cache.repos if r.repo_id == repo_id and r.repo_type == "model"
    ]
    if not matching:
        print(f"\n  '{repo_id}' is not in the HuggingFace cache.")
        print("  Nothing to remove.")
        sys.exit(1)

    repo = matching[0]
    size_str = _format_bytes(repo.size_on_disk)

    if not getattr(args, "yes", False):
        try:
            response = input(f"Remove {repo_id} ({size_str})? [y/N] ").strip().lower()
        except EOFError:
            # Non-TTY (piped stdin, ctrl-D) — treat as cancel, never as
            # silent-yes. Matches ``apt`` / ``brew`` muscle memory.
            print("Aborted.")
            sys.exit(0)
        if response not in ("y", "yes"):
            print("Aborted.")
            sys.exit(0)

    revisions = [rev.commit_hash for rev in repo.revisions]
    strategy = cache.delete_revisions(*revisions)
    strategy.execute()
    print(f"Freed {size_str}")


def ps_command(_args):
    """List running qmlx servers (process scan)."""
    import time

    import psutil

    rows: list[tuple[int, str, str, str]] = []
    for proc in psutil.process_iter(["pid", "cmdline", "create_time"]):
        try:
            cmd = proc.info["cmdline"] or []
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
        if not any(("qmlx" in c or "vllm_mlx" in c) and "serve" in cmd for c in cmd):
            continue

        # 0.9.0 dogfood: ``qmlx serve`` runs under a ``caffeinate
        # -is qmlx serve ...`` wrapper on macOS to prevent sleep.
        # The wrapper's argv carries the same ``qmlx`` / ``serve``
        # tokens as the real server, so the substring match above
        # double-counts it as a second row (same port, different PID).
        # The wrapper is never the actual server — its argv[0] basename
        # is the only reliable way to filter it out without missing the
        # case where caffeinate is launched via an absolute path.
        if cmd and os.path.basename(cmd[0]) == "caffeinate":
            continue

        # Extract model arg and --port flag. argparse accepts options
        # before positionals, so the model is the first non-flag token
        # after `serve` whose prior token isn't a value-taking flag.
        # The small list of flags here is conservative; unknown flags
        # are assumed to NOT take a value.
        VALUE_FLAGS = {
            "--host",
            "--port",
            "--api-key",
            "--tool-call-parser",
            "--reasoning-parser",
            "--log-level",
            "--mcp-config",
            "--cors-origins",
            "--cloud-model",
            "--cloud-api-base",
            "--cloud-api-key",
            "--served-model-name",
            "--max-tokens",
            "--gpu-memory-utilization",
        }
        model = "(unknown)"
        port = "8000"  # serve's default
        try:
            i = cmd.index("serve") + 1
            # Pre-PR this loop ``break``ed on the first positional, so a
            # ``qmlx serve qwen3.5-4b-4bit --port 8005`` ended with
            # port="8000" because the positional model token came before
            # ``--port``. Keep scanning for flags after we've captured the
            # model — argparse accepts them on either side.
            model_seen = False
            while i < len(cmd):
                tok = cmd[i]
                if tok.startswith("--"):
                    if "=" in tok:
                        key, val = tok.split("=", 1)
                        if key == "--port":
                            port = val
                        i += 1
                    elif tok in VALUE_FLAGS:
                        if tok == "--port" and i + 1 < len(cmd):
                            port = cmd[i + 1]
                        i += 2
                    else:
                        i += 1
                else:
                    if not model_seen:
                        model = tok
                        model_seen = True
                    i += 1
        except ValueError:
            pass

        uptime_s = max(0, int(time.time() - proc.info["create_time"]))
        h, m = uptime_s // 3600, (uptime_s % 3600) // 60
        uptime = f"{h}h{m:02d}m" if h else f"{m}m{uptime_s % 60:02d}s"
        rows.append((proc.info["pid"], port, model, uptime))

    if not rows:
        print("\n  No qmlx servers running.")
        return

    ordered = sorted(rows, key=lambda r: int(r[1]))  # numeric port sort
    if ui.rich:
        ui.rich_table(
            ["PID", "PORT", "MODEL", "UPTIME"],
            [[str(r[0]), str(r[1]), r[2], r[3]] for r in ordered],
            title="qmlx servers",
            style="cyan",
            footer=[f"{len(ordered)} server(s) running"],
        )
        return

    print()
    print(f"  {'PID':<8}{'PORT':<8}{'MODEL':<40}{'UPTIME':<10}")
    print(f"  {'-' * 66}")
    # Sort numerically by port — string sort would put "10000" before "8000".
    for pid, port, model, uptime in ordered:
        print(f"  {pid:<8}{port:<8}{model:<40}{uptime:<10}")
    print()


def status_command(args):
    """Show live status of a running qmlx server (issue #51, phase 3).

    One-shot by default; ``--watch`` polls until Ctrl-C. Field-by-field
    mapping is pinned by tests (AC6) against the ``/v1/status`` payload.
    """
    import requests

    target = (getattr(args, "target", None) or "127.0.0.1:8000").strip()
    if target.startswith(("http://", "https://")):
        base = target.rstrip("/")
    else:
        base = f"http://{target}"
    timeout = float(getattr(args, "timeout", 3.0))

    def fetch() -> dict:
        r = requests.get(f"{base}/v1/status", timeout=timeout)
        r.raise_for_status()
        return r.json()

    if getattr(args, "watch", False):
        # --watch: poll until Ctrl-C. Rich mode drives a rich.live region
        # (transient — leaves no residue); plain mode re-prints the
        # one-line strip each tick (no erase bytes — pipe-safe).
        def render() -> str:
            try:
                stats = fetch()
            except Exception:  # noqa: BLE001 — show, keep polling
                return "warming up… (no server reachable)"
            if ui.rich:
                return ui.render_live_line(stats)
            return _plain_live_line(stats)

        try:
            with ui.live(render, interval=0.5):
                pass
        except KeyboardInterrupt:
            print()
        return

    try:
        stats = fetch()
    except Exception:  # noqa: BLE001 — connection refused, DNS, 404…
        print(f"\n  No server reachable at {base}")
        print("  Start one with: qmlx serve <model>")
        sys.exit(1)

    rows = ui.status_kv_rows(stats)
    if ui.rich:
        ui.rich_table(
            ["FIELD", "VALUE"],
            [[k, v] for k, v in rows],
            title=f"qmlx status — {base}",
            style="cyan",
        )
        return
    print()
    print(ui.render_status_table(stats))
    print()


def _plain_live_line(stats: dict) -> str:
    """Plain one-line status strip (no markup) for ``status --watch``."""
    model = stats.get("model") or "-"
    state = "generating" if stats.get("status") == "generating" else "ready"
    line = f"  {model} · {state} · run {stats.get('num_running', 0)} / wait {stats.get('num_waiting', 0)}"
    tps = stats.get("generation_tps")
    if tps:
        line += f" · {tps:.1f} tok/s"
    return line


def _tui_hint_or_exit() -> None:
    """Exit(1) with the one-line install hint when textual is missing.

    Must run BEFORE ``from vllm_mlx import tui`` — the tui module itself
    imports textual at top level (AC9: bare install prints the hint and
    exits 1, no traceback).
    """
    try:
        import textual  # noqa: F401
    except Exception:  # noqa: BLE001 — any import failure = extra missing
        print("TUI extra not installed. Run: pip install 'qmlx[tui]'")
        sys.exit(1)


def tui_command(args):
    """Textual chat TUI — ``qmlx tui [model]`` (issue #51, phase 4)."""
    # Hint check MUST precede the import — vllm_mlx.tui imports textual at
    # module top level, so a bare install must see the friendly hint (exit 1)
    # instead of an ImportError traceback (AC9).
    _tui_hint_or_exit()
    from vllm_mlx import tui as _tui

    # ``main()`` pre-resolves ``args.model`` (alias → HF path) exactly like
    # chat; the TUI requests use the alias the user typed so it matches
    # the served name when a server was spawned for this model.
    args.model = getattr(args, "_original_alias", args.model)
    _tui.run(args)


def _spawn_chat_server(
    model: str,
    log_path: str,
    served_name: str | None = None,
    *,
    register_in: list | None = None,
    log_handle=None,
) -> tuple[object, str]:
    """Spawn a `serve` subprocess on an ephemeral port for chat REPL use.

    Returns (Popen handle, base_url).

    ``register_in`` is an optional list (typically the chat REPL's
    ``_active_procs``). When provided, the new ``Popen`` is appended to it
    *immediately* after construction — narrowing the SIGTERM-orphan race
    that exists between ``Popen()`` returning and the caller registering
    the handle. Caller-side ``register_in.append(proc)`` would still leave
    one Python statement of unprotected window; doing it inside this
    function closes that window for the caller.

    ``log_handle`` is the ``managed_tempfile_path`` context-manager handle
    that owns ``log_path``. When provided, ownership is transferred to the
    proc inside a SIGTERM/SIGINT-masked critical section that also performs
    the ``register_in`` append and the ``_qmlx_log*`` attribute set.
    Without the mask + atomic transfer, a signal landing between
    ``_active_procs.append`` and the caller's later ``handle.release()``
    could fire ``_teardown_proc`` (which intentionally keeps non-empty
    logs for post-mortem) — then the ``with`` block's ``finally`` would
    unlink the kept log anyway, violating the keep-non-empty-log policy
    documented on ``_teardown_proc``. Codex round-1 BLOCKING #1.

    If ``served_name`` is given, it is passed via ``--served-model-name`` so
    the spawned server exposes the alias as the API model name (e.g. user
    typed ``qwen3.5-4b-4bit`` → API requests use ``qwen3.5-4b-4bit`` rather than the
    expanded HF path).
    """
    import signal as _signal
    import socket
    import subprocess

    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
    base_url = f"http://127.0.0.1:{port}"
    cmd = [
        sys.executable,
        "-m",
        "vllm_mlx.cli",
        "serve",
        model,
        "--host",
        "127.0.0.1",
        "--port",
        str(port),
        "--log-level",
        "WARNING",
    ]
    if served_name and served_name != model:
        cmd.extend(["--served-model-name", served_name])
    log = open(log_path, "w")  # noqa: SIM115 — kept open for proc lifetime
    # Tell the child main() that the parent already gated (or that this is
    # an internal spawn, where prompting would deadlock anyway because the
    # child stdin is not a TTY). Without this, the child's B2 gate would
    # see a stdin pipe and re-evaluate against a potentially-stale cache.
    child_env = os.environ.copy()
    child_env["QMLX_CHAT_SPAWN"] = "1"
    # Parent-PID watchdog (rapid-desktop #449 sibling fix). The
    # SIGTERM-handler + atexit pair installed below cannot fire under
    # SIGKILL of the chat REPL — the spawned ``serve`` would otherwise
    # outlive ``qmlx chat`` and keep the model + port locked. The
    # watchdog inside the child polls ``os.getppid()`` every 2 s and
    # self-terminates the moment the live PPID stops matching this
    # stamp.
    #
    # Direct assignment (NOT setdefault). Codex r2 MAJOR: if the chat
    # REPL itself was launched under a supervisor that already exported
    # ``QMLX_WATCHDOG_PPID=<grandparent_pid>``, ``setdefault``
    # would carry the grandparent's PID into the child env. The
    # watchdog would then compare ``os.getppid()`` (= chat REPL's PID,
    # the IMMEDIATE parent) against the grandparent PID, mismatch on
    # first poll, and self-terminate the freshly-booted server. The
    # spawner owns the watchdog relationship for the spawn it just
    # created — overwrite is correct.
    child_env["QMLX_WATCHDOG_PPID"] = str(os.getpid())
    # Atomic critical section: block SIGTERM/SIGINT delivery around
    # the whole ``Popen()`` + register + attribute-set + ``release()``
    # sequence. We use ``pthread_sigmask(SIG_BLOCK, ...)`` so the
    # parent thread's mask blocks the signals (queued, delivered when
    # restored).
    #
    # POSIX caveat (codex pr_validate round-3 BLOCKING): both the
    # signal mask AND the signal disposition are inherited across
    # ``fork`` + ``execve``. If we Popen() while the mask blocks
    # SIGTERM/SIGINT, the child server inherits the block and won't
    # honour normal shutdown. The fix is a ``preexec_fn`` that
    # explicitly UNBLOCKS the signals in the child between ``fork``
    # and ``exec`` so the child starts with a clean mask.
    #
    # ``preexec_fn`` runs in the child after fork, before exec, and
    # is exactly the right hook for this. There is no async-signal-
    # safety concern because we are still pre-exec; the child has
    # not yet been replaced with a new image.
    #
    # On platforms without ``pthread_sigmask`` (Windows), fall back
    # to the ``SIG_IGN`` shape — Windows ``subprocess`` doesn't have
    # the same fork/exec model, and the chat REPL is not a Windows
    # feature anyway.
    has_pthread_sigmask = hasattr(_signal, "pthread_sigmask")
    sigset = {_signal.SIGTERM, _signal.SIGINT}
    _prev_mask = None
    _prev_term = _prev_int = None

    def _child_unblock_signals():
        """preexec_fn: clear inherited SIGTERM/SIGINT mask in the child
        so it starts with default mask + default disposition.
        """
        try:
            _signal.pthread_sigmask(_signal.SIG_UNBLOCK, sigset)
        except (ValueError, OSError):
            pass

    try:
        if has_pthread_sigmask:
            try:
                _prev_mask = _signal.pthread_sigmask(_signal.SIG_BLOCK, sigset)
            except (ValueError, OSError):
                _prev_mask = None
        else:
            try:
                _prev_term = _signal.signal(_signal.SIGTERM, _signal.SIG_IGN)
            except (ValueError, OSError):
                pass
            try:
                _prev_int = _signal.signal(_signal.SIGINT, _signal.SIG_IGN)
            except (ValueError, OSError):
                pass
        try:
            proc = subprocess.Popen(  # noqa: S603
                cmd,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
                env=child_env,
                # Codex pr_validate r3 BLOCKING: clear the inherited
                # signal mask in the child so it can be terminated
                # normally. ``preexec_fn`` is the documented hook for
                # post-fork / pre-exec setup; the child cannot reach
                # ``exec`` until this runs.
                preexec_fn=_child_unblock_signals if has_pthread_sigmask else None,
            )
        except (OSError, ValueError):
            # Popen raised before constructing the child — the log handle
            # would otherwise leak. Re-raise after closing. The ``finally``
            # below still restores the signal mask / handlers.
            log.close()
            raise
        # Register first so a SIGTERM landing between here and the caller's
        # next statement still tears the child down.
        if register_in is not None:
            register_in.append(proc)
        # Stash the log handle and path on the proc object so the chat REPL
        # can close+unlink them when the proc is torn down (fixes the file
        # descriptor + tempfile leak across `/model` swaps).
        proc._qmlx_log = log
        proc._qmlx_log_path = log_path
        # Hand the tempfile path off to ``_teardown_proc`` BEFORE we
        # leave the masked section. Once released, the ``with`` block's
        # ``finally`` in the caller is a no-op for this path.
        if log_handle is not None:
            log_handle.release()
    finally:
        # Best-effort restore so post-spawn signals route normally. Any
        # SIGTERM/SIGINT that landed while blocked is delivered HERE
        # (kernel-queued, exactly the desired behaviour: the chat's
        # installed handler now sees the proc in ``_active_procs``).
        if has_pthread_sigmask:
            if _prev_mask is not None:
                try:
                    _signal.pthread_sigmask(_signal.SIG_SETMASK, _prev_mask)
                except (ValueError, OSError):
                    pass
        else:
            for signum, prev in (
                (_signal.SIGTERM, _prev_term),
                (_signal.SIGINT, _prev_int),
            ):
                if prev is not None:
                    try:
                        _signal.signal(signum, prev)
                    except (ValueError, OSError):
                        pass
    return proc, base_url


def _wait_for_chat_server(base_url: str, proc, timeout_s: int = 600) -> None:
    """Block until /health/ready returns 200, the proc exits, or timeout.

    On a TTY, draws a spinner + elapsed-seconds counter to stderr so the
    user can see the chat REPL is alive while the spawned server loads
    weights (typically 20-90 s for 4-30 B models on Apple Silicon). The
    line is erased before this function returns so the caller's next
    print lands on a clean line.
    """
    import time

    import requests

    # issue #51: the spinner is a ``_ui`` call — rich mode uses a rich
    # status line, plain mode replays the legacy ANSI frames byte-for-byte
    # when stderr is a TTY (and is a no-op otherwise).
    deadline = time.monotonic() + timeout_s
    tick = 0
    with ui.spinner("loading model ...", interval=0.1):
        while time.monotonic() < deadline:
            if proc.poll() is not None:
                raise RuntimeError(
                    f"server exited early (code {proc.returncode}); "
                    "see chat-server.log for details"
                )
            # Animate at 10 fps; only poll /health once a second to keep
            # the spinner smooth and the network polite.
            if tick % 10 == 0:
                try:
                    r = requests.get(f"{base_url}/health/ready", timeout=2)
                    if r.status_code == 200:
                        return
                except requests.RequestException:
                    pass
            time.sleep(0.1)
            tick += 1
    raise TimeoutError(
        f"server did not become ready within {timeout_s}s "
        "(large models can take longer — pass --ready-timeout)"
    )


def _has_short_pattern_dominating_suffix(
    text: str,
    *,
    window: int = 600,
    max_period: int = 300,
) -> bool:
    """Return True if the trailing ``window`` chars of ``text`` are
    periodic with a cycle length ≤``max_period``.

    Catches the degenerate-model cases the rolling whitespace-token
    counter in ``_stream_chat_response`` misses:

    - ``"BarleyBarleyBarley..."`` (no whitespace separator) — the entire
      suffix collapses to a single ``str.split()`` token whose count
      never increments. Real qwen3.5-4b-4bit regression surfaced in the
      0.6.28 onboarding test.
    - Long-cycle phrase loops, e.g. a ~280-char clause that repeats
      verbatim until ``max_tokens``. Surfaced when asked "describe the
      entire history of the Roman Empire in one long unbroken sentence".

    Implementation: compute the KMP failure function over the trailing
    window. The smallest period of the *entire* window is
    ``len(s) - fail[-1]``; a short period (≤``max_period``) means the
    window is dominated by that repetition starting from offset 0.

    Note: KMP itself does NOT detect periods that begin mid-window
    (rotated patterns). Mid-window degeneracy gets caught because this
    helper is invoked after every streaming chunk — once the model has
    been looping long enough to fill the window, the rolling 600-char
    suffix aligns with the pattern and the smallest-period check fires.
    A pure end-of-stream check would miss rotated cases.

    Cost is ``O(window)`` time and memory per call regardless of
    pattern length (the failure-function array is allocated each
    invocation) — much cheaper than the prior
    ``O(window * pattern_max_len)`` anchored scan, and cheap enough
    to run on every streaming chunk.

    The defaults (window=600, max_period=300) leave room for legitimate
    repetitive content like ``[0, 0, 0, ...]`` lists shorter than the
    window. *Long* lists of truly identical values the user explicitly
    asked for will get cut — a user hitting that false positive can
    ``/reset`` and rephrase. The cost of NOT cutting genuine model
    degeneracy (2000+ tokens of garbage) is far higher.
    """
    if len(text) < window:
        return False
    tail = text[-window:]
    n = len(tail)
    # KMP failure function: ``fail[i]`` = longest proper prefix of
    # ``tail[: i + 1]`` that is also a suffix.
    fail = [0] * n
    for i in range(1, n):
        j = fail[i - 1]
        while j > 0 and tail[i] != tail[j]:
            j = fail[j - 1]
        if tail[i] == tail[j]:
            j += 1
        fail[i] = j
    # Smallest period of ``tail``. Always >= 1 (fail[-1] <= n-1, since
    # ``fail`` is the longest *proper* prefix-suffix). ``period == n``
    # means no nontrivial period — the entire window is its own only
    # period and content is aperiodic. Defaults guarantee
    # ``max_period < window`` so this case never trips, but a caller
    # with ``max_period >= window`` would otherwise see aperiodic
    # strings flagged. Explicit ``period < n`` guard locks the contract.
    period = n - fail[-1]
    return period < n and period <= max_period


def _stream_chat_response(
    base_url: str,
    payload: dict,
    timeout_s: int,
    metrics: dict | None = None,
) -> str:
    """POST /v1/chat/completions with stream=True and print tokens as they
    arrive. Returns the full assistant content (concatenated content deltas).

    Reasoning-content deltas (Qwen3, DeepSeek-R1, etc.) are streamed to stdout
    in dim ANSI so the user sees thinking, but excluded from the returned
    string — chat history stores only the final answer, matching the
    OpenAI-compat split between ``content`` and ``reasoning_content``.

    Plain streaming: tokens land directly in the user's terminal as they
    arrive. We deliberately do NOT use ``rich.Live`` + ``Markdown`` here:
    Live re-renders the panel on every refresh and, when the console's
    cursor-overwrite path is unreliable (recordings, some terminal
    multiplexers), each refresh appends rather than overwrites — turning
    a 200-token response into a wall of repeated text. Live markdown
    rendering deserves a separate, more careful effort with explicit
    fallback detection; for now correctness wins over formatting.
    """
    import json

    import requests

    DIM = "\x1b[2m"
    BOLD = "\x1b[1m"
    RESET = "\x1b[0m"
    MAGENTA = "\x1b[35m"
    CYAN = "\x1b[36m"
    is_tty = sys.stdout.isatty() and "NO_COLOR" not in os.environ
    in_reasoning = False
    full = ""

    # ----- Streaming markdown colorer ------------------------------------
    # Body text streams in the terminal's default color (Claude-Code-style
    # — accents only on chrome). Inline coloring handles the markers users
    # see most often: ``\`code\``` (cyan), ``\`\`\`fence\`\`\``` (dim cyan
    # block), ``**bold**`` (ANSI bold), and ATX headers (``#`` … ``####``)
    # at line start. Lists / italic stay raw so the parser stays small.
    HEADING_STYLE = {
        1: BOLD + CYAN,  # `# h1`     — most prominent
        2: BOLD + MAGENTA,  # `## h2`    — secondary
        3: BOLD,  # `### h3`   — bold only
        4: CYAN,  # `#### h4`  — cyan
        5: MAGENTA,  # `##### h5` — magenta
        6: DIM,  # `###### h6`— dim
    }
    _state = {
        "in_fence": False,  # inside a ``` block
        "in_inline_code": False,  # inside a `code` span
        "in_bold": False,  # inside **bold**
        "in_heading": False,  # inside an ATX heading line
        "at_line_start": True,  # cursor is at start of a logical line
        "pending": "",  # buffered chars awaiting lookahead
    }

    def _emit_with_inline_md(piece: str) -> None:
        if not is_tty:
            sys.stdout.write(piece)
            sys.stdout.flush()
            return
        text = _state["pending"] + piece
        _state["pending"] = ""
        out: list[str] = []
        i, n = 0, len(text)
        while i < n:
            c = text[i]
            # Newline closes any line-scoped span (heading) and resets the
            # line-start anchor so the next `#`/`*`/etc. is interpreted in
            # the right context.
            if c == "\n":
                if _state["in_heading"]:
                    out.append(RESET)
                    _state["in_heading"] = False
                out.append("\n")
                _state["at_line_start"] = True
                i += 1
                continue
            # ATX heading: `#`..`######` followed by space at line start.
            # We skip this inside fences (a `#` at line start there is
            # almost always a comment, not a heading).
            if _state["at_line_start"] and c == "#" and not _state["in_fence"]:
                # Count consecutive `#` (1..6).
                j = i
                while j < n and j - i < 6 and text[j] == "#":
                    j += 1
                # Need to see one more char after the hashes to decide
                # heading vs literal "###foo" — buffer if we don't have it.
                if j == n:
                    _state["pending"] = text[i:]
                    break
                hashes = j - i
                if 1 <= hashes <= 6 and text[j] == " ":
                    style = HEADING_STYLE.get(hashes, BOLD)
                    out.append(style)
                    out.append(text[i : j + 1])  # emit "## "
                    _state["in_heading"] = True
                    _state["at_line_start"] = False
                    i = j + 1
                    continue
                # Not a heading — fall through to literal emission below.
            if c == "`":
                # Need 2 chars of lookahead to disambiguate ``` vs `.
                if i + 2 >= n:
                    _state["pending"] = text[i:]
                    break
                if text[i : i + 3] == "```":
                    if _state["in_fence"]:
                        out.append("```" + RESET)
                        _state["in_fence"] = False
                    else:
                        out.append(DIM + CYAN + "```")
                        _state["in_fence"] = True
                    _state["at_line_start"] = False
                    i += 3
                    continue
                # Single backtick.
                if _state["in_fence"]:
                    out.append("`")
                elif _state["in_inline_code"]:
                    out.append("`" + RESET)
                    _state["in_inline_code"] = False
                else:
                    out.append(CYAN + "`")
                    _state["in_inline_code"] = True
                _state["at_line_start"] = False
                i += 1
                continue
            if c == "*" and not _state["in_fence"] and not _state["in_inline_code"]:
                if i + 1 >= n:
                    _state["pending"] = text[i:]
                    break
                if text[i : i + 2] == "**":
                    if _state["in_bold"]:
                        out.append("**" + RESET)
                        _state["in_bold"] = False
                    else:
                        out.append(BOLD + "**")
                        _state["in_bold"] = True
                    _state["at_line_start"] = False
                    i += 2
                    continue
            out.append(c)
            # Whitespace (other than newline, handled above) keeps the
            # line-start anchor true so leading-indent headings still
            # parse — e.g., a list item's child paragraph is rare here.
            if c not in " \t":
                _state["at_line_start"] = False
            i += 1
        sys.stdout.write("".join(out))
        sys.stdout.flush()

    def _close_open_md_spans() -> None:
        if is_tty and (
            _state["in_fence"]
            or _state["in_inline_code"]
            or _state["in_bold"]
            or _state["in_heading"]
        ):
            sys.stdout.write(RESET)
            sys.stdout.flush()
        if _state["pending"]:
            sys.stdout.write(_state["pending"])
            sys.stdout.flush()
            _state["pending"] = ""

    # ----- Repetition guard ----------------------------------------------
    # Models occasionally degenerate into the same token repeated until
    # max_tokens — filling the screen with "Barley Barley Barley...".
    # Two complementary checks run per delta:
    #
    # 1. Whitespace-token-consecutive: the SAME whitespace-split token
    #    repeats ≥``REPEAT_LIMIT`` times in a row. O(1) rolling counter.
    #    Catches the common form ``"Barley Barley Barley..."``. Earlier
    #    guards used "≤2 unique in last 30" but fired on legit content
    #    like ``[0, 0, 0, ...]`` and markdown table separators, so the
    #    bar is now stricter.
    #
    # 2. Character-level pattern check (``_has_short_pattern_dominating_
    #    suffix``): the trailing window is dominated by a short repeating
    #    pattern. Catches the form ``"BarleyBarleyBarley..."`` (no
    #    whitespace separator), where ``piece.split()`` produces one
    #    giant token whose count never increments — this was a real
    #    qwen3.5-4b-4bit regression in 0.6.28 (issue surfaced post-release).
    REPEAT_LIMIT = 25
    repeat_last: str | None = None
    repeat_run = 0
    repetition_aborted = False

    with requests.post(
        f"{base_url}/v1/chat/completions",
        json=payload,
        stream=True,
        timeout=timeout_s,
    ) as resp:
        if resp.status_code != 200:
            # With stream=True the body may still be partial / mid-chunk when
            # the server closed the socket; read defensively so we surface a
            # useful HTTP code instead of a ChunkedEncodingError.
            try:
                body = resp.text[:500]
            except Exception:
                body = "(no body)"
            raise RuntimeError(f"HTTP {resp.status_code}: {body}")
        for line in resp.iter_lines(decode_unicode=True):
            if not line or not line.startswith("data: "):
                continue
            data = line[6:]
            if data == "[DONE]":
                break
            try:
                chunk = json.loads(data)
            except json.JSONDecodeError:
                continue
            # When the caller passes ``stream_options.include_usage``,
            # the server emits a final chunk with empty choices and a
            # populated ``usage`` block. Capture it for the speed line.
            usage = chunk.get("usage")
            if usage and metrics is not None:
                metrics["completion_tokens"] = usage.get("completion_tokens")
                metrics["prompt_tokens"] = usage.get("prompt_tokens")
            # The usage-only final chunk has ``choices=[]``; guard
            # against an IndexError there.
            choices = chunk.get("choices") or []
            delta = choices[0].get("delta", {}) if choices else {}
            # ``finish_reason`` arrives on the last token chunk (after
            # which the server may still emit a usage-only chunk).
            # Capture the most recent non-null value so the caller can
            # surface a "length" warning if the answer was truncated.
            if choices and metrics is not None:
                fr = choices[0].get("finish_reason")
                if fr is not None:
                    metrics["finish_reason"] = fr
            reasoning = delta.get("reasoning_content")
            piece = delta.get("content")
            if reasoning:
                if not in_reasoning:
                    if is_tty:
                        sys.stdout.write(f"{MAGENTA}[thinking]{RESET} {DIM}")
                    else:
                        sys.stdout.write("[thinking] ")
                    in_reasoning = True
                sys.stdout.write(reasoning)
                sys.stdout.flush()
            if piece:
                if in_reasoning:
                    sys.stdout.write(f"{RESET}\n  " if is_tty else "\n")
                    in_reasoning = False
                # Detect repetition BEFORE emitting. If a single coalesced
                # delta contains the cutoff inside it (server batched many
                # repeated tokens into one chunk), find the position and
                # only emit the prefix up to that token — otherwise the
                # user sees the full degenerate dump before the abort
                # message lands.
                #
                # Rolling counter: each new whitespace-separated token in
                # this delta either extends the current consecutive run
                # or resets it. Aborts only on a single token repeated
                # ``REPEAT_LIMIT`` times in a row, not on diverse-but-
                # repetitive content like ``[0, 0, 0, ...]`` or markdown
                # tables.
                cutoff_idx: int | None = None
                tokens = piece.split()
                for i, tok in enumerate(tokens):
                    if tok == repeat_last:
                        repeat_run += 1
                    else:
                        repeat_last = tok
                        repeat_run = 1
                    if repeat_run >= REPEAT_LIMIT:
                        repetition_aborted = True
                        cutoff_idx = i
                        break
                if cutoff_idx is not None:
                    # Find the byte position in ``piece`` corresponding to
                    # the start of the cutoff token, so we can emit only
                    # the prefix. ``str.split()`` collapses runs of
                    # whitespace, so we walk the original text token-by-
                    # token to recover the offset.
                    pos = 0
                    seen = 0
                    while seen < cutoff_idx and pos < len(piece):
                        # Skip leading whitespace.
                        while pos < len(piece) and piece[pos].isspace():
                            pos += 1
                        # Skip the token itself.
                        while pos < len(piece) and not piece[pos].isspace():
                            pos += 1
                        seen += 1
                    prefix = piece[:pos]
                    if prefix:
                        _emit_with_inline_md(prefix)
                        full += prefix
                else:
                    _emit_with_inline_md(piece)
                    full += piece
                # Char-level guard: catches no-whitespace degenerate
                # output like ``"BarleyBarleyBarley..."`` that the
                # whitespace-token counter misses (the entire chunk
                # collapses to one giant token whose consecutive count
                # never climbs). Cheap enough to run on every chunk.
                #
                # Trade-off: runs *after* the chunk is already emitted,
                # so the user sees one extra chunk of garbage before
                # the abort message lands. We accept this — slicing
                # mid-chunk would require re-running KMP per byte (or
                # binary search) on every delta, and degenerate chunks
                # are typically small (≤64 chars) since servers stream
                # token-by-token.
                if not repetition_aborted and _has_short_pattern_dominating_suffix(
                    full
                ):
                    repetition_aborted = True
                if repetition_aborted:
                    break
    _close_open_md_spans()
    if in_reasoning and is_tty:
        sys.stdout.write(RESET)
        sys.stdout.flush()
    if repetition_aborted:
        msg = (
            f"\n\n  {DIM}(response cut: model began repeating itself — "
            f"try /reset or a larger model){RESET}"
            if is_tty
            else "\n\n(response cut: repetition detected)"
        )
        sys.stdout.write(msg)
        sys.stdout.flush()
    return full


def chat_command(args):
    """Interactive REPL chat with a model.

    Spawns a local `serve` on an ephemeral port (or connects to an existing
    server via --base-url / --port), then loops stdin → /v1/chat/completions
    (streaming) → stdout. Maintains multi-turn history; `/reset` clears it.
    Exits cleanly on Ctrl-D, Ctrl-C, or `exit` / `quit`.
    """
    import atexit
    import signal
    import subprocess

    from vllm_mlx._tempfile_safe import managed_tempfile_path

    base_url: str
    proc = None
    log_path: str | None = None
    # Tracks every spawned server (initial + every /model candidate) so
    # the SIGTERM/atexit cleanup tears down in-flight candidates too —
    # not just the bound ``proc``. A SIGTERM landing while a /model
    # swap is mid-spawn would otherwise orphan the candidate server.
    _active_procs: list[subprocess.Popen] = []

    # TTY-gated ANSI palette for the chat UI. NO_COLOR is honoured.
    _is_tty = sys.stdout.isatty() and "NO_COLOR" not in os.environ
    BOLD = "\x1b[1m" if _is_tty else ""
    DIM = "\x1b[2m" if _is_tty else ""
    GREEN = "\x1b[32m" if _is_tty else ""
    CYAN = "\x1b[36m" if _is_tty else ""
    YELLOW = "\x1b[33m" if _is_tty else ""
    RED = "\x1b[31m" if _is_tty else ""
    RESET = "\x1b[0m" if _is_tty else ""

    def _teardown_proc(p) -> None:
        """Terminate a spawned chat server and free its log file.

        Used by `_cleanup` (process exit) and `_switch_model` (mid-
        session swap). Idempotent — safe to call when the proc has
        already exited or never existed. Also reaps the killed child
        with wait(timeout=1) so repeated /model swaps don't leave
        zombies until the parent exits.
        """
        if p is None:
            return
        try:
            if p.poll() is None:
                try:
                    p.terminate()
                    p.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    try:
                        p.kill()
                        # Reap the SIGKILL'd child — without this,
                        # repeated /model swaps stack zombie entries.
                        try:
                            p.wait(timeout=1)
                        except subprocess.TimeoutExpired:
                            pass
                    except (ProcessLookupError, OSError):
                        pass
                except (ProcessLookupError, OSError):
                    pass
        finally:
            # Drop from the tracked set so a subsequent _cleanup walk
            # doesn't double-tear it down.
            try:
                _active_procs.remove(p)
            except ValueError:
                pass
            # Close the log handle and reap the tempfile so /model
            # swaps don't leak FDs. Both attributes set by
            # _spawn_chat_server.
            #
            # Log file unlink policy: zero-byte logs (no server output
            # ever flushed — typical for a clean spawn that never logged
            # a warning) are unlinked; non-empty logs are LEFT IN PLACE
            # so a user investigating a crash or post-mortem error still
            # has the server's stderr to look at. Previously every log
            # was unlinked, which scrubbed useful debugging breadcrumbs
            # along with the noise.
            fh = getattr(p, "_qmlx_log", None)
            if fh is not None:
                try:
                    fh.close()
                except OSError:
                    pass
            lp = getattr(p, "_qmlx_log_path", None)
            if lp:
                try:
                    size = os.path.getsize(lp)
                except OSError:
                    size = -1  # treat unknown as "leave alone"
                if size == 0:
                    try:
                        os.unlink(lp)
                    except FileNotFoundError:
                        pass
                    except OSError:
                        pass

    # Guard against re-entry: ``_cleanup`` is registered once with
    # ``atexit`` AND fired from the SIGTERM handler. Without an idempotent
    # check, a SIGTERM during shutdown would walk ``_active_procs``,
    # _teardown_proc would empty it, then atexit's invocation would walk
    # an empty list — harmless today, but the explicit flag keeps the
    # contract obvious and survives future helpers that read the list
    # before iterating.
    _cleanup_state = {"done": False}

    def _cleanup():
        # Walk every tracked proc — covers the active server and any
        # in-flight /model candidate. Iterate over a snapshot since
        # _teardown_proc mutates _active_procs. Idempotent: a second call
        # short-circuits so atexit + SIGTERM-handler ordering doesn't
        # matter.
        if _cleanup_state["done"]:
            return
        # Mask BOTH SIGTERM and SIGINT for the duration of the loop.
        # Codex round-3 BLOCKING #1: with only SIGTERM masked, a SIGINT
        # landing mid-teardown raises KeyboardInterrupt, unwinds the
        # for-loop, the surrounding ``finally`` issues ``sys.exit(143)``,
        # and atexit's later call sees ``done=True`` (set at function
        # entry, original implementation) → procs after the interrupted
        # one get orphaned. Move the ``done`` flag to AFTER the loop AND
        # mask SIGINT so a Ctrl-C-during-cleanup can't kill the unwind.
        _prev_term = _prev_int = None
        try:
            _prev_term = signal.signal(signal.SIGTERM, signal.SIG_IGN)
        except (ValueError, OSError):
            pass
        try:
            _prev_int = signal.signal(signal.SIGINT, signal.SIG_IGN)
        except (ValueError, OSError):
            pass
        try:
            for p in list(_active_procs):
                _teardown_proc(p)
            _cleanup_state["done"] = True
        finally:
            # Best-effort restore so post-cleanup signals route normally.
            # If restore raises, swallow — we're about to exit anyway.
            for signum, prev in (
                (signal.SIGTERM, _prev_term),
                (signal.SIGINT, _prev_int),
            ):
                if prev is not None:
                    try:
                        signal.signal(signum, prev)
                    except (ValueError, OSError):
                        pass

    # Install SIGTERM handler + atexit BEFORE any spawn. Otherwise a
    # SIGTERM landing in the window between `Popen()` and `signal.signal`
    # uses Python's default handler (calls `_exit`, skips atexit) and
    # orphans the spawned server. SIGINT is *deliberately* left on the
    # default handler so Ctrl-C unblocks ``input()`` via the natural
    # KeyboardInterrupt path, the REPL loop's ``except
    # KeyboardInterrupt: break`` fires, and atexit runs ``_cleanup``.
    # On non-tty stdin (piped input) the SIGINT path is never exercised,
    # so the SIGTERM + atexit pair is what reaps the spawned server.
    #
    # Re-entry: a second SIGTERM landing mid-cleanup (common from process
    # supervisors that escalate after a short grace period) would
    # otherwise call _cleanup again — _teardown_proc's
    # ``proc.terminate() + proc.wait(timeout=5)`` would block while the
    # outer cleanup is still mid-wait, leaving the child orphaned.
    # ``_cleanup`` masks both SIGTERM and SIGINT internally for the
    # duration of its teardown loop (Codex round-3 BLOCKING #1), so the
    # handler here only needs to drive the lifecycle: cleanup → exit.
    # The try/finally guarantees sys.exit fires even if _teardown_proc
    # raises (rare — only on the secondary proc.kill() escalation).
    def _sigterm_handler(*_):
        try:
            _cleanup()
        finally:
            sys.exit(143)

    try:
        signal.signal(signal.SIGTERM, _sigterm_handler)
    except (ValueError, OSError):
        pass
    atexit.register(_cleanup)

    if args.base_url:
        base_url = args.base_url.rstrip("/")
        if base_url.endswith("/v1"):
            base_url = base_url[:-3]
    elif args.port is not None:
        # Pre-flight probe: a valid-range but unbound port previously
        # dropped the user into the REPL and only failed on the first
        # message with a raw HTTPConnectionPool stack trace. Probe once
        # with a 1 s timeout so the failure is friendly + actionable.
        import socket as _socket

        try:
            with _socket.create_connection(("127.0.0.1", args.port), timeout=1):
                pass
        except OSError:
            # OSError covers ConnectionRefusedError + socket.timeout
            # (which is an alias for ``TimeoutError`` in Python 3.10+).
            print(
                f"\n  {RED}Error:{RESET} no qmlx server reachable at "
                f"127.0.0.1:{args.port}."
            )
            print(f"    Start one with: qmlx serve <alias> --port {args.port}")
            print("    Or omit --port to spawn one automatically.")
            sys.exit(1)
        base_url = f"http://127.0.0.1:{args.port}"
    else:
        # Pre-download in the foreground so the HF tqdm progress bar lands
        # in the user's terminal. Otherwise the serve subprocess swallows
        # the bar into the log file and `qmlx chat` looks frozen for
        # several minutes on first run with a fresh model.
        _ensure_model_downloaded(args.model)

        # GH #719: ``NamedTemporaryFile(...).name`` leaked one zero-byte
        # log per invocation if ANYTHING raised between path creation
        # and the proc being appended to ``_active_procs`` (where
        # ``_teardown_proc`` would otherwise reap it). The
        # ``managed_tempfile_path`` helper registers an atexit unlink
        # the moment the path exists, so the race window is closed:
        # cleanup runs on context exit, on ``sys.exit``, or via atexit
        # if the body propagates. The handle is passed through to
        # ``_spawn_chat_server`` which performs the
        # register/attribute-set/release as a single SIGTERM-masked
        # critical section, so ``_teardown_proc``'s keep-non-empty-log
        # policy cannot be undone by a signal during the handoff
        # (codex round-1 BLOCKING #1).
        with managed_tempfile_path(prefix="qmlx-chat-", suffix=".log") as _log_handle:
            log_path = _log_handle.path
            print(f"\n  Starting server {DIM}(log: {log_path}){RESET} ...")
            # If main() resolved an alias, expose the alias as the API model name
            # so the chat request body matches what the user typed.
            original = getattr(args, "_original_alias", None)
            proc, base_url = _spawn_chat_server(
                args.model,
                log_path,
                served_name=original,
                register_in=_active_procs,
                log_handle=_log_handle,
            )

        try:
            _wait_for_chat_server(base_url, proc, timeout_s=args.ready_timeout)
        except (RuntimeError, TimeoutError) as e:
            print(f"\n  {RED}Failed to start server:{RESET} {e}")
            sys.exit(1)
        print(f"  {GREEN}✓ Ready.{RESET}\n")

    from vllm_mlx._version_check import print_staleness_warning_if_any

    print_staleness_warning_if_any()

    # Resolve ``--max-tokens``. Default is None at the argparse layer so
    # we can distinguish "user did not pass it" from "user passed 2048
    # explicitly". When ``--think`` is set and the user did not supply a
    # value, raise the default from 2048 to 4096 so the reasoning trace +
    # final answer both fit (the round-1 finding: ``chat qwen3.5-4b-4bit
    # --think`` filled the 2048 budget with reasoning and emitted an
    # empty answer with ``finish_reason='length'``).
    user_passed_max_tokens = args.max_tokens is not None
    if args.max_tokens is None:
        args.max_tokens = 4096 if args.think else 2048
    if args.think and not user_passed_max_tokens:
        print(
            f"  {DIM}(--think on; raised --max-tokens to {args.max_tokens} — "
            f"pass --max-tokens to override){RESET}"
        )

    print(
        f"  🐆 {BOLD}Chat{RESET} — "
        f"{DIM}type {RESET}{BOLD}/help{RESET}{DIM} for commands, "
        f"Ctrl-D to exit.{RESET}"
    )
    # First-launch-only banner for the agents/codex tip. The marker-file
    # gate keeps the tip from re-appearing on every chat launch (persona-3
    # finding: irritating by launch #50). Marker logic is skipped entirely
    # when stdout is not a TTY or NO_COLOR is set — pipe/CI runs shouldn't
    # pollute the user's config dir, and the banner is fluff there anyway.
    _is_pipe_or_no_color = (not sys.stdout.isatty()) or ("NO_COLOR" in os.environ)
    if not _is_pipe_or_no_color and not _has_seen_tip("chat_intro_codex"):
        print(
            f"  {DIM}For a Claude Code-like TUI: `qmlx agents codex --setup`, "
            f"then run `codex` in any project.{RESET}\n"
        )
        _mark_tip_seen("chat_intro_codex")
    else:
        # Maintain the existing blank-line spacing the banner used to
        # provide — keeps the prompt layout consistent across runs.
        print()

    served_name = getattr(args, "_original_alias", args.model)

    # issue #51 phase 4: ``chat --tui`` — Textual TUI instead of the REPL
    # loop. base_url is already resolved above (--base-url / --port probe /
    # spawn + ready-wait); a spawned server (if any) stays in _active_procs
    # so _cleanup reaps it when the TUI exits.
    if getattr(args, "tui", False):
        # Hint check MUST precede the import — vllm_mlx.tui imports textual
        # at module top level (AC9: bare install → hint + exit 1, no traceback).
        _tui_hint_or_exit()
        from vllm_mlx import tui as _tui

        args.model = served_name  # TUI requests use the served name
        _tui.run(args)
        _cleanup()
        return

    messages: list[dict] = []
    if args.system:
        messages.append({"role": "system", "content": args.system})

    # The qmlx server's ChatCompletionRequest exposes a top-level
    # ``enable_thinking`` field — ``chat_template_kwargs`` is not a recognized
    # request field and would be silently dropped.
    #
    # Default thinking OFF in the REPL. Reasoning models (Qwen3.5/3.6, etc.)
    # otherwise emit raw chain-of-thought to stdout AND, on the default
    # qwen3.5-4b-4bit model, degenerate into infinite repetition until max-tokens
    # truncates the response — producing zero usable output for a brand-new
    # user. ``--think`` opts back in for users who explicitly want to see
    # reasoning traces; ``--no-think`` is preserved as the legacy form.
    extra: dict = {}
    if not args.think:
        extra["enable_thinking"] = False

    import time

    import requests

    # Importing ``readline`` upgrades the built-in ``input()`` so that
    # the arrow keys recall earlier prompts (and Ctrl-A/E/U/R work).
    # The module is stdlib on macOS/Linux; on Windows it doesn't exist
    # and we fall back to plain input(). When readline IS available we
    # need to wrap the colored prompt's ANSI escapes in \001/\002 so
    # readline's column counter doesn't include the invisible bytes —
    # otherwise long history entries wrap incorrectly and Ctrl-A jumps
    # to the wrong column (especially on libedit-backed Apple system
    # python). The wrappers are no-op on a terminal, so it's safe to
    # always emit them when readline is loaded.
    have_readline = False
    try:
        import readline  # noqa: F401 — side-effect import

        have_readline = True
    except ImportError:
        pass

    def _wrap_invisible(esc: str) -> str:
        if have_readline and esc:
            return "\001" + esc + "\002"
        return esc

    if _is_tty:
        prompt = _wrap_invisible(BOLD + CYAN) + ">" + _wrap_invisible(RESET) + " "
        cont_prompt = _wrap_invisible(DIM) + "…" + _wrap_invisible(RESET) + " "
    else:
        prompt = "> "
        cont_prompt = "… "

    def _print_help():
        print(
            f"\n  {BOLD}Slash commands{RESET}\n"
            f"    {BOLD}/help{RESET}, {BOLD}/?{RESET}          show this help\n"
            f"    {BOLD}/reset{RESET}, {BOLD}/clear{RESET}     clear conversation history\n"
            f"    {BOLD}/model <alias>{RESET}     switch model "
            f"{DIM}(restarts the server, resets history){RESET}\n"
            f"    {BOLD}/save <path>{RESET}       save conversation to a markdown file\n"
            f"    {BOLD}/exit{RESET}, {BOLD}/quit{RESET}, {BOLD}/bye{RESET}    "
            f"exit chat {DIM}(or Ctrl-D){RESET}\n"
            f"\n  {BOLD}Multi-line input{RESET}\n"
            f'    type {BOLD}"""{RESET} on its own line to start, again to end '
            f"{DIM}(paste code blocks){RESET}\n"
            f"\n  {BOLD}Keys{RESET}\n"
            f"    {BOLD}Ctrl-C{RESET}             cancel the current response, "
            f"or exit at empty prompt\n"
            f"    {BOLD}Ctrl-D{RESET}             exit\n"
        )

    def _save_conversation(path_arg: str):
        # Refuse early on an empty conversation — otherwise we create a
        # near-empty file then lock the user out of the same path on
        # the next try (since exclusive-mode open refuses overwrite).
        non_system = [m for m in messages if m.get("role") != "system"]
        if not non_system:
            print(
                f"  {YELLOW}Nothing to save yet.{RESET} "
                f"{DIM}(send a chat turn first){RESET}\n"
            )
            return
        path = os.path.expanduser(path_arg)
        # Auto-create parent directories; otherwise users see a confusing
        # "No such file or directory" for /save logs/2026-05/convo.md.
        parent = os.path.dirname(os.path.abspath(path))
        if parent:
            try:
                os.makedirs(parent, exist_ok=True)
            except OSError as exc:
                print(f"  {RED}Save failed:{RESET} cannot create {parent}: {exc}\n")
                return
        try:
            # Mode "x" (O_CREAT | O_EXCL) is atomic — refuses if the path
            # already exists, with no TOCTOU window between exists() and
            # open() that an exists()-then-open("w") check has. Also
            # naturally rejects existing symlinks pointing elsewhere.
            with open(path, "x", encoding="utf-8") as f:
                f.write(f"# qmlx chat — {served_name}\n\n")
                for m in messages:
                    if m["role"] == "system":
                        continue
                    f.write(f"## {m['role'].capitalize()}\n\n{m['content']}\n\n")
            print(f"  {GREEN}✓{RESET} Saved {len(messages)} messages to {path}\n")
        except FileExistsError:
            print(
                f"  {YELLOW}{path} already exists.{RESET} "
                f"{DIM}(/save won't overwrite — pick a different path){RESET}\n"
            )
        except IsADirectoryError:
            print(
                f"  {RED}Save failed:{RESET} {path} is a directory — "
                f"{DIM}give a file path, not a directory{RESET}\n"
            )
        except OSError as exc:
            print(f"  {RED}Save failed:{RESET} {exc}\n")

    def _read_multiline() -> str:
        lines: list[str] = []
        while True:
            try:
                more = input(cont_prompt)
            except (EOFError, KeyboardInterrupt):
                # Tell the user how many lines they're losing — silent
                # discard on Ctrl-C/Ctrl-D mid-paste is hostile.
                if lines:
                    print(
                        f"\n  {YELLOW}(multi-line cancelled — "
                        f"{len(lines)} line{'' if len(lines) == 1 else 's'} "
                        f"discarded){RESET}\n"
                    )
                else:
                    print(f"\n  {YELLOW}(multi-line cancelled){RESET}\n")
                return ""
            if more.rstrip() == '"""':
                # Preserve leading/trailing whitespace verbatim — the
                # heredoc is meant for code paste, where stripping
                # indentation actively corrupts the input.
                return "\n".join(lines)
            lines.append(more)

    def _switch_model(new_alias: str) -> None:
        """Hot-swap the spawned chat server to a new model alias.

        Order matters: validate + pre-download the new model BEFORE
        terminating the old one. If anything fails (bogus alias, disk
        gate, network), the old server stays running and the REPL is
        usable. Only when the new model is on-disk and the new server is
        spawn-ready do we tear down the old proc and rebind.
        """
        nonlocal proc, base_url, log_path, served_name, messages
        if proc is None:
            print(
                f"  {YELLOW}/model is only available when chat spawns its "
                f"own server (not with --base-url / --port).{RESET}\n"
            )
            return
        from vllm_mlx.model_aliases import resolve_model

        resolved = resolve_model(new_alias) or new_alias
        print(f"  {DIM}Preparing {new_alias} → {resolved} ...{RESET}")

        # 1a. Gate before download: the main() entry-point gate only
        #     fires on the CLI invocation, so an uncached /model swap
        #     would otherwise start a 40+ GB pull with no prompt.
        #     Mirror main()'s cheap env/TTY short-circuit so we don't
        #     pay the 5-second HF metadata round-trip on every /model
        #     swap when the user opted into AUTO_PULL or is on non-TTY
        #     stdin. ``confirm_or_abort`` self-skips again internally
        #     but skipping ``estimate_repo_size_bytes`` saves the wait.
        if "/" in resolved and not os.path.exists(resolved):
            _env_val = os.environ.get("QMLX_AUTO_PULL", "").strip().lower()
            _auto_yes = _env_val in {"1", "true", "yes"}
            _interactive = sys.stdin.isatty()
            if not _auto_yes and _interactive:
                from vllm_mlx._download_gate import (
                    confirm_or_abort,
                    estimate_repo_size_bytes,
                    is_repo_cached,
                )

                if not is_repo_cached(resolved):
                    try:
                        confirm_or_abort(
                            resolved,
                            estimate_repo_size_bytes(resolved),
                        )
                    except SystemExit:
                        # User said no — keep the current server up.
                        print(
                            f"  {YELLOW}Model switch cancelled{RESET} "
                            f"{DIM}(previous server still running).{RESET}\n"
                        )
                        return

        # 1. Pre-download the new model (this also runs the disk-space
        #    gate). The current server keeps running while we do this so
        #    a download failure leaves the user where they were.
        try:
            _ensure_model_downloaded(resolved)
        except SystemExit:
            # Disk gate aborted via sys.exit(1); old server is untouched.
            print(
                f"  {RED}Model switch aborted{RESET} "
                f"{DIM}(disk gate); previous server still running.{RESET}\n"
            )
            return
        except RuntimeError as exc:
            # Definitive 404 from HF; old server stays.
            print(
                f"  {RED}Model switch aborted:{RESET} {exc}  "
                f"{DIM}(previous server still running){RESET}\n"
            )
            return

        # 2. Allocate a new log file and spawn the new server. We don't
        #    tear down the old one yet; we want a working candidate
        #    before we commit. ``managed_tempfile_path`` (GH #719)
        #    guarantees the log path is unlinked if the spawn raises
        #    before the proc is registered onto ``_active_procs`` —
        #    the leak window in the original ``NamedTemporaryFile(...).name``
        #    pattern. The handle is passed into ``_spawn_chat_server``
        #    so the register/attribute-set/release happens under one
        #    SIGTERM/SIGINT mask, preserving ``_teardown_proc``'s
        #    keep-non-empty-log policy on signal-during-handoff (codex
        #    round-1 BLOCKING #1).
        with managed_tempfile_path(
            prefix="qmlx-chat-", suffix=".log"
        ) as _new_log_handle:
            new_log_path = _new_log_handle.path
            print(f"  Starting server {DIM}(log: {new_log_path}){RESET} ...")
            # ``register_in=_active_procs`` makes the candidate visible to
            # ``_cleanup`` *inside* ``_spawn_chat_server`` — before the
            # readiness wait, before any further Python statement runs in
            # this scope. A SIGTERM/Ctrl-C during the (possibly multi-second)
            # load tears the child down via the cleanup walk.
            new_proc, new_base_url = _spawn_chat_server(
                resolved,
                new_log_path,
                served_name=new_alias,
                register_in=_active_procs,
                log_handle=_new_log_handle,
            )
        try:
            _wait_for_chat_server(new_base_url, new_proc, timeout_s=args.ready_timeout)
        except (RuntimeError, TimeoutError) as exc:
            print(
                f"  {RED}Failed to start new server:{RESET} {exc}  "
                f"{DIM}(previous server still running){RESET}\n"
            )
            # Roll back: tear down the half-spawned new proc + free its
            # log file. The old proc/base_url/log_path stay bound.
            _teardown_proc(new_proc)
            return

        # 3. New server is healthy — commit. Rebind ``proc`` BEFORE
        #    tearing down the old one so a SIGTERM during teardown
        #    walks the new (still-running) proc, not just a freshly
        #    killed corpse.
        old_proc = proc
        proc = new_proc
        base_url = new_base_url
        log_path = new_log_path
        served_name = new_alias
        messages = [{"role": "system", "content": args.system}] if args.system else []
        _teardown_proc(old_proc)
        print(
            f"  {GREEN}✓ Switched to {new_alias}.{RESET} "
            f"{DIM}(history cleared){RESET}\n"
        )

    while True:
        try:
            line = input(prompt).rstrip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            continue
        # Heredoc-pasted content must NEVER be dispatched as a slash
        # command — a markdown doc whose first line starts with `/path`
        # or whose content includes `/save` would otherwise be silently
        # eaten by the slash dispatcher. Track the source so we know.
        is_heredoc = False
        if line == '"""':
            line = _read_multiline()
            if not line:
                continue
            is_heredoc = True
        if not is_heredoc:
            # Parse the leading word as the command and dispatch on
            # *exact* match. ``startswith("/save")`` would otherwise treat
            # ``/savefoo`` as ``/save`` (with arg ``foo``), silently
            # writing a file from a typo. Same for ``/modelfoo``.
            # ``str.split(maxsplit=1)`` (no separator arg) splits on any
            # whitespace, so ``/save\tpath.md`` works the same as
            # ``/save path.md``.
            parts = line.split(maxsplit=1)
            cmd = parts[0] if parts else ""
            rest = parts[1].strip() if len(parts) > 1 else ""
            # ``/bye`` is an Ollama-muscle-memory alias for ``/exit`` /
            # ``/quit``. ``/?`` mirrors ``/help`` and was already
            # supported; both alias sets are advertised in ``/help``.
            if cmd in ("exit", "quit", "/exit", "/quit", "/bye"):
                break
            if cmd in ("/help", "/?"):
                _print_help()
                continue
            if cmd in ("/reset", "/clear"):
                messages = (
                    [{"role": "system", "content": args.system}] if args.system else []
                )
                print(f"  {DIM}(history cleared){RESET}\n")
                continue
            if cmd == "/save":
                if not rest:
                    print(f"  {YELLOW}Usage: /save <path>{RESET}\n")
                else:
                    _save_conversation(rest)
                continue
            if cmd == "/model":
                if not rest:
                    print(
                        f"  {YELLOW}Usage: /model <alias>{RESET}  "
                        f"{DIM}(see `qmlx models`){RESET}\n"
                    )
                else:
                    _switch_model(rest)
                continue
            if cmd.startswith("/"):
                print(
                    f"  {YELLOW}Unknown command: {cmd}{RESET}  "
                    f"{DIM}(type /help){RESET}\n"
                )
                continue

        messages.append({"role": "user", "content": line})
        payload = {
            "model": served_name,
            "messages": messages,
            "max_tokens": args.max_tokens,
            "temperature": args.temperature,
            "stream": True,
            "stream_options": {"include_usage": True},
            **extra,
        }
        # Claude-Code-style turn marker: a colored bullet introduces the
        # assistant's response so the user can visually scan turn
        # boundaries when scrolling back through long conversations.
        sys.stdout.write(f"\n  {CYAN}●{RESET} ")
        sys.stdout.flush()
        metrics: dict = {}
        start_t = time.monotonic()
        try:
            assistant = _stream_chat_response(
                base_url,
                payload,
                timeout_s=args.response_timeout,
                metrics=metrics,
            )
        except KeyboardInterrupt:
            print(f"\n  {YELLOW}(response interrupted){RESET}\n")
            messages.pop()
            continue
        except RuntimeError as e:
            print(f"\n  {RED}{e}{RESET}\n")
            messages.pop()
            continue
        except requests.RequestException as e:
            # Connection refused, timeout, dropped midstream — keep the REPL
            # alive and roll back the failed user turn so the next request
            # doesn't carry a dangling user role with no assistant reply.
            print(f"\n  {RED}Request failed:{RESET} {e}\n")
            messages.pop()
            continue
        elapsed = time.monotonic() - start_t
        # Speed line: prefer server-reported usage, fall back to a rough
        # 4-chars-per-token estimate when the server doesn't ship usage
        # in the stream.
        tokens = metrics.get("completion_tokens")
        if not tokens:
            tokens = max(1, len(assistant) // 4)
            tokens_label = f"~{tokens}"
        else:
            tokens_label = str(tokens)
        if assistant and elapsed > 0:
            tps = tokens / elapsed
            print(
                f"\n  {DIM}{tokens_label} tok · {elapsed:.1f}s · "
                f"{tps:.0f} tok/s{RESET}\n"
            )
        else:
            print()
        # Length-cut + empty-content warning. When the server stops
        # because ``finish_reason == "length"`` AND no visible content
        # was streamed (only reasoning), the user otherwise sees an
        # empty bullet and has no signal that the budget was the
        # problem. This is the round-1 ``--think`` regression: 2048-
        # token budget filled by reasoning on small models, zero answer.
        if metrics.get("finish_reason") == "length" and not assistant:
            print(
                f"  {YELLOW}(reasoning consumed the full --max-tokens "
                f"budget; bump --max-tokens for a final answer){RESET}\n"
            )
        if assistant:
            messages.append({"role": "assistant", "content": assistant})
        else:
            messages.pop()


def info_command(args):
    """Print the per-model profile for a model name or alias.

    Stage 1 (regex match) only — does NOT load the model, so this is fast
    and works without weights. Stage 2 (ArraysCache probe) is skipped.
    """
    from vllm_mlx.model_aliases import resolve_model, resolve_profile
    from vllm_mlx.model_auto_config import (
        detect_model_config,
        format_profile_table,
    )

    # ``main()`` (cli.py:~3400) pre-resolves ``args.model`` from alias →
    # HF path before dispatch, stashing the user-typed alias on
    # ``args._original_alias``. Pull from that first so DFlash
    # eligibility (alias-keyed) and the start-command hint render with
    # the alias the user actually typed, not the resolved HF repo.
    original_alias = getattr(args, "_original_alias", None) or args.model
    name = args.model
    resolved = (
        resolve_model(name) if not getattr(args, "_original_alias", None) else None
    )
    if resolved and resolved != name:
        print(f"  alias: {name} → {resolved}")
        name = resolved

    cfg = detect_model_config(name)
    print()
    print(format_profile_table(name, cfg))
    print()

    # DFlash eligibility — render the report so users can see which
    # gates pass/fail without consulting the docs. Skipped for unknown
    # models since AliasProfile is alias-keyed.
    profile = resolve_profile(original_alias)
    if profile is not None:
        _print_dflash_status(original_alias, profile)
        _print_ddtree_status(original_alias, profile)

    if cfg is None:
        print("  No pattern matched — runtime probe will run when the model loads.")
        print()


def _print_dflash_status(alias: str, profile) -> None:
    """Render a 3-row DFlash status block for ``qmlx info <alias>``.

    Shows each gate (declared support / not MoE / not 4-bit / drafter
    present) so a user who tried DFlash and got a vague error can see
    exactly which gate they're tripping.
    """
    from vllm_mlx.spec_decode.dflash.eligibility import (
        _looks_like_4bit,
        have_runtime,
        report,
    )

    r = report(profile, alias=alias)
    inner = 60
    sep = "─" * inner

    def _row(text: str) -> str:
        return f"│ {text:<{inner}} │"

    def _yes(ok: bool, msg_ok: str, msg_no: str) -> str:
        return ("✓ " + msg_ok) if ok else ("✗ " + msg_no)

    rows = [
        (
            "Declared support",
            _yes(profile.supports_dflash, "yes (supports_dflash=true)", "no"),
        ),
        ("Not MoE", _yes(not profile.is_moe, "yes (dense)", "no (MoE)")),
        (
            "Precision ≥8-bit",
            _yes(
                not _looks_like_4bit(profile.hf_path),
                "yes",
                "no (4-bit/mxfp4/nvfp4)",
            ),
        ),
        (
            "Drafter declared",
            _yes(
                bool(profile.dflash_draft_model),
                profile.dflash_draft_model or "yes",
                "no (dflash_draft_model unset)",
            ),
        ),
        (
            "mlx-vlm 0.5.0+",
            _yes(have_runtime(), "installed", "missing (need qmlx[dflash])"),
        ),
    ]

    eligible = not r.reasons and have_runtime()
    summary = "✓ eligible" if eligible else "✗ ineligible"

    # Box-less lines feed the rich panel; the plain box is rebuilt below
    # from the same lines so both modes share one source of truth.
    lines = [f"DFlash eligibility: {summary}", ""]
    for k, v in rows:
        lines.append(f"{k:<18}: {v}")

    top = "┌" + "─" * (inner + 2) + "┐"
    bot = "└" + "─" * (inner + 2) + "┘"
    body = [top, _row(f"DFlash eligibility: {summary}"), _row(sep)]
    for k, v in rows:
        body.append(_row(f"{k:<18}: {v}"))
    body.append(bot)
    ui.panel(
        "DFlash eligibility",
        lines,
        plain_lines=body,
        style="green" if eligible else "yellow",
    )
    print()
    if eligible:
        print(
            f"  Start with: qmlx serve {alias} "
            """--speculative-config '{"method":"dflash"}'"""
        )
        print()


def _print_ddtree_status(alias: str, profile) -> None:
    """Render DDTree status for ``qmlx info <alias>``."""
    from vllm_mlx.spec_decode.ddtree.eligibility import have_runtime, report
    from vllm_mlx.spec_decode.dflash.eligibility import _looks_like_4bit

    r = report(profile, alias=alias)
    inner = 60
    sep = "─" * inner

    def _row(text: str) -> str:
        return f"│ {text:<{inner}} │"

    def _yes(ok: bool, msg_ok: str, msg_no: str) -> str:
        return ("✓ " + msg_ok) if ok else ("✗ " + msg_no)

    rows = [
        (
            "Declared support",
            _yes(profile.supports_ddtree, "yes (supports_ddtree=true)", "no"),
        ),
        ("Not MoE", _yes(not profile.is_moe, "yes (dense)", "no (MoE)")),
        (
            "Precision ≥8-bit",
            _yes(
                not _looks_like_4bit(profile.hf_path),
                "yes",
                "no (4-bit/mxfp4/nvfp4)",
            ),
        ),
        (
            "Drafter declared",
            _yes(
                bool(profile.ddtree_draft_model),
                profile.ddtree_draft_model or "yes",
                "no (ddtree_draft_model unset)",
            ),
        ),
        (
            "Spec tokens",
            _yes(
                profile.ddtree_speculative_tokens is not None,
                str(profile.ddtree_speculative_tokens),
                "missing",
            ),
        ),
        (
            "Tree budget",
            _yes(
                profile.ddtree_tree_budget is not None,
                str(profile.ddtree_tree_budget),
                "missing",
            ),
        ),
        (
            "dtree-mlx runtime",
            _yes(
                have_runtime(),
                "installed",
                "missing/import-broken",
            ),
        ),
    ]

    eligible = not r.reasons and have_runtime()
    summary = "✓ eligible" if eligible else "✗ ineligible"

    # Box-less lines feed the rich panel; the plain box is rebuilt below
    # from the same lines so both modes share one source of truth.
    lines = [f"DDTree eligibility: {summary}", ""]
    for k, v in rows:
        lines.append(f"{k:<18}: {v}")

    top = "┌" + "─" * (inner + 2) + "┐"
    bot = "└" + "─" * (inner + 2) + "┘"
    body = [top, _row(f"DDTree eligibility: {summary}"), _row(sep)]
    for k, v in rows:
        body.append(_row(f"{k:<18}: {v}"))
    body.append(bot)
    ui.panel(
        "DDTree eligibility",
        lines,
        plain_lines=body,
        style="green" if eligible else "yellow",
    )
    print()
    if eligible:
        print(
            f"  Start with: qmlx serve {alias} "
            """--speculative-config '{"method":"ddtree"}'"""
        )
        print()


def agents_command(args):
    """List, configure, and test agent integrations."""
    from vllm_mlx.agents import get_profile, list_profiles
    from vllm_mlx.agents.adapter import get_setup_instructions, setup_agent_config

    agent_name = args.agent_name
    base_url = args.base_url

    # No agent specified → list all profiles
    if not agent_name:
        profiles = list_profiles()
        table_rows = []
        for p in profiles:
            fc = "FC" if p.needs_function_calling else ""
            stars = f"{p.stars // 1000}K" if p.stars and p.stars >= 1000 else ""
            if p.recommended_models:
                shown = p.recommended_models[:3]
                models = ", ".join(shown)
                if len(p.recommended_models) > 3:
                    models += f" +{len(p.recommended_models) - 3}"
            else:
                models = ""
            table_rows.append([p.name, p.display_name, stars, fc, models])

        footer = [
            f"{len(profiles)} agents supported",
            "Usage: qmlx agents <name>          Show setup guide",
            "       qmlx agents <name> --setup   Auto-configure",
            "       qmlx agents <name> --test    Run integration tests",
        ]
        if ui.rich:
            print()
            ui.rich_table(
                ["NAME", "DISPLAY", "STARS", "FC", "RECOMMENDED MODELS"],
                table_rows,
                title="Supported AI Agents",
                style="cyan",
                footer=footer,
            )
            return

        print()
        print("  Supported AI Agents")
        print("  " + "─" * 56)
        for p in profiles:
            fc = "FC" if p.needs_function_calling else "  "
            stars = f"{p.stars // 1000}K" if p.stars and p.stars >= 1000 else ""
            if p.recommended_models:
                shown = p.recommended_models[:3]
                models = ", ".join(shown)
                if len(p.recommended_models) > 3:
                    models += f" +{len(p.recommended_models) - 3}"
            else:
                models = ""
            print(f"  {p.name:<15} {p.display_name:<20} {stars:>5}  [{fc}]  {models}")
        print()
        print(f"  {len(profiles)} agents supported")
        print("  Usage: qmlx agents <name>          Show setup guide")
        print("         qmlx agents <name> --setup   Auto-configure")
        print("         qmlx agents <name> --test    Run integration tests")
        print()
        return

    # Get profile
    profile = get_profile(agent_name)
    if not profile:
        print(f"  Unknown agent: {agent_name}")
        print("  Run 'qmlx agents' to see available agents.")
        sys.exit(1)

    # --test: run integration tests
    if args.test:
        from vllm_mlx.agents.testing import AgentTestRunner

        model_id = args.model or None
        runner = AgentTestRunner(
            profile,
            base_url=base_url,
            model_id=model_id,
            agent_version=args.agent_version,
        )
        if not runner._server_available():
            print(f"\n  Server not running at {base_url}")
            print("  Start it first: qmlx serve <model>")
            sys.exit(1)

        report = runner.run()
        success = report.print_summary()
        sys.exit(0 if success else 1)

    # --setup: auto-configure agent
    if args.setup:
        # Detect model from running server
        model_id = args.model or "default"
        if model_id == "default":
            try:
                import httpx

                resp = httpx.get(f"{base_url}/models", timeout=3)
                model_id = resp.json()["data"][0]["id"]
            except Exception:
                pass

        summary = setup_agent_config(
            profile, base_url, model_id, agent_version=args.agent_version
        )
        print(f"\n  {profile.display_name} configured!")
        print(f"  {summary}")
        print()
        return

    # Default: show setup instructions
    # Pass "default" to trigger auto-detection of running model
    model_id = args.model or "default"
    instructions = get_setup_instructions(
        profile, base_url, model_id, agent_version=args.agent_version
    )
    print()
    print(instructions)
    print()


def upgrade_command(args):
    """Detect install method and (optionally) run the right upgrade command."""
    import subprocess

    from vllm_mlx._version_check import (
        _installed_version,
        _parse_version,
        detect_install_method,
        get_latest_version,
    )

    current = _installed_version() or "dev"
    print()
    print(f"  Current:  qmlx {current}")

    latest = get_latest_version(force_refresh=True)
    if latest is None:
        print("  Latest:   (could not reach GitHub — check your network)\n")
        sys.exit(1)
    print(f"  Latest:   qmlx {latest}")

    cur = _parse_version(current)
    lat = _parse_version(latest)
    if cur is not None and lat is not None and cur >= lat:
        print("\n  ✓ Already up to date.\n")
        return

    info = detect_install_method()
    print(f"  Install:  {info.method} ({info.binary_path or 'unknown path'})")
    print(f"  Command:  {info.upgrade_command}")
    print()

    if info.method == "unknown":
        print(
            "  Could not auto-detect install method — run the command above manually.\n"
        )
        return

    if getattr(args, "dry_run", False):
        print("  (dry-run — not executed; rerun without --dry-run to apply.)\n")
        return

    if args.yes:
        confirmed = True
    else:
        # Default Y — the user already typed the upgrade command;
        # punishing the Enter key with a no-op skip is bad UX. EOF on
        # stdin is treated as Enter (proceed), mirroring the download
        # gate. Ctrl-C is the only "skip" path — it returns silently
        # without ``sys.exit`` because upgrade is a leaf operation, so
        # there's nothing downstream to abort; cf. the gate, which
        # exits 1 because it's gatekeeping a multi-GB download.
        try:
            answer = input("  Run now? [Y/n] ").strip().lower()
        except EOFError:
            answer = ""
        except KeyboardInterrupt:
            print()
            return
        confirmed = answer not in {"n", "no"}

    if not confirmed:
        print("  Skipped — run the command above when ready.\n")
        return

    print()
    try:
        # Use argv form (shell=False) so paths with spaces in
        # ``sys.executable`` (or any other argv entry) can't be reinterpreted
        # as shell separators. install.sh's pipe is wrapped as ``bash -c``
        # in upgrade_argv, so we still get the pipe semantics it needs.
        result = subprocess.run(info.upgrade_argv, check=False)
    except KeyboardInterrupt:
        print("\n  Interrupted.\n")
        sys.exit(130)
    print()
    sys.exit(result.returncode)


def main():
    from importlib.metadata import version as pkg_version

    try:
        _version = pkg_version("qmlx")
    except Exception:
        _version = "dev"

    parser = argparse.ArgumentParser(
        description="qMLX: multi-backend MLX inference engine (Metal, ROCm, CUDA)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
  qmlx chat                                      # interactive REPL (defaults to qwen3.5-4b-4bit)
  qmlx chat qwen3.5-9b-4bit --think                   # larger model, surface reasoning
  qmlx serve qwen3.5-9b-4bit --port 8000              # OpenAI-compatible server
  qmlx serve mlx-community/Qwen3.5-9B-4bit       # full HF repo also works
  qmlx models                                    # list all aliases
  qmlx info qwen3.5-9b-4bit                           # show per-alias profile
""",
    )
    parser.add_argument("--version", "-V", action="version", version=f"qmlx {_version}")
    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # Serve command. ``allow_abbrev=False`` blocks unique-prefix matches
    # like ``--no-thin`` resolving silently to ``--no-thinking``: with the
    # hidden ``--no-think`` cross-alias added in D4, both flags share the
    # ``--no-thi`` prefix and prefix matching becomes ambiguous (an
    # ambiguity which argparse does NOT report by default for hidden
    # aliases). Force users to type the flag in full.
    serve_parser = subparsers.add_parser(
        "serve",
        help="Start OpenAI-compatible server",
        allow_abbrev=False,
    )
    serve_parser.add_argument(
        "model", type=str, help="Model to serve"
    ).completer = alias_completer
    serve_parser.add_argument(
        "--served-model-name",
        type=str,
        default=None,
        help="The model name used in the API. If not specified, the model argument is used.",
    )
    serve_parser.add_argument(
        "--force-disk-check",
        action="store_true",
        help=(
            "Skip the pre-flight disk-space check that aborts when the model "
            "is larger than free disk. Use only if you know the HF cache lives "
            "on a different filesystem (e.g. external drive via HF_HOME)."
        ),
    )
    serve_parser.add_argument(
        "--host",
        type=str,
        default="127.0.0.1",
        help=(
            "Host to bind (default: 127.0.0.1, loopback-only). Pass "
            '0.0.0.0 (or "") to expose the server on every '
            "interface (LAN reachable) — only do this once the "
            "bearer-auth posture has been reviewed. The wildcard "
            "bind also widens the PortSweep collision window: macOS "
            "lets a wildcard listener coexist with a more-specific "
            "(127.0.0.1) listener on the same port, so a second "
            "server may start and silently shadow the first on the "
            "loopback path. The pre-flight bind check below probes "
            "127.0.0.1 explicitly whenever --host is a wildcard "
            "alias to keep that bypass closed."
        ),
    )
    serve_parser.add_argument("--port", type=int, default=8000, help="Port to bind")
    # issue #51 phase 3: live status strip on the terminal. TTY+rich only —
    # plain mode (pipe / NO_COLOR / QMLX_PLAIN=1) emits one info line and
    # falls back to the usual blocking run; --listen-fd is a no-op. Display-only
    # flag: never reaches SchedulerConfig, so the CLI↔Config fidelity audit
    # is unaffected.
    serve_parser.add_argument(
        "--live",
        action="store_true",
        default=False,
        help="Live status strip while serving (TTY only; no-op on pipes)",
    )
    # Socket activation — let an external supervisor (launchd, systemd,
    # parent process) bind the listening socket and execve into
    # ``qmlx`` with the pre-bound fd. This closes the bind→auth
    # TOCTOU window described in issue #574: no co-located process can
    # land an unauthenticated request between socket bind and FastAPI
    # auth dependency registration, because by the time
    # ``qmlx serve`` runs, the app (with auth dependencies wired
    # into chat/embeddings/audio/models routers) is already constructed
    # before ``uvicorn.run`` starts ``accept()``-ing on the fd.
    #
    # When ``--listen-fd`` is set, ``--host``/``--port`` are IGNORED:
    # the supervisor controls the bind address. The "Ready:" banner
    # prints the inherited fd shape (``Ready: inherited fd N``) — NOT
    # the user-supplied host/port, since those don't reflect the
    # supervisor's actual bind. Setting both ``--listen-fd`` and a
    # non-default ``--port`` is allowed but the port has no effect;
    # the active listener is the inherited fd.
    serve_parser.add_argument(
        "--listen-fd",
        type=_listen_fd_arg,
        default=None,
        metavar="FD",
        help=(
            "File descriptor of a pre-bound listening socket (3-1023). "
            "Used for socket activation (launchd/systemd/parent-process "
            "supervision) — supervisor binds the loopback socket, "
            "validates auth secret, then execve's into qmlx. "
            "When set, --host/--port are ignored for binding."
        ),
    )
    serve_parser.add_argument(
        "--log-level",
        type=_log_level_choice,
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Log level for Python logging and uvicorn (case-insensitive)",
    )
    serve_parser.add_argument(
        "--max-num-seqs", type=int, default=256, help="Max concurrent sequences"
    )
    serve_parser.add_argument(
        "--max-concurrent-requests",
        type=int,
        default=256,
        help=(
            "Admission cap on in-flight requests (queued + running). When "
            "exceeded, new requests return HTTP 503 with Retry-After. "
            "Default 256; operators on memory-constrained devices may want "
            "to set this near ``--max-num-seqs`` to limit queue depth."
        ),
    )
    serve_parser.add_argument(
        "--prefill-batch-size", type=int, default=8, help="Prefill batch size"
    )
    serve_parser.add_argument(
        "--completion-batch-size", type=int, default=32, help="Completion batch size"
    )
    serve_parser.add_argument(
        "--enable-prefix-cache",
        action="store_true",
        default=True,
        help="Enable prefix caching for repeated prompts (default: enabled)",
    )
    serve_parser.add_argument(
        "--disable-prefix-cache",
        action="store_true",
        help="Disable prefix caching",
    )
    serve_parser.add_argument(
        "--prefix-cache-size",
        type=int,
        default=100,
        help="Max entries in prefix cache (default: 100, legacy mode only)",
    )
    # Memory-aware cache options (recommended for large models)
    serve_parser.add_argument(
        "--cache-memory-mb",
        type=int,
        default=None,
        help="Cache memory limit in MB (default: auto-detect ~20%% of RAM)",
    )
    serve_parser.add_argument(
        "--cache-memory-percent",
        type=float,
        default=0.20,
        help="Fraction of available RAM for cache if auto-detecting (default: 0.20)",
    )
    # KV cache quantization options
    # ``--kv-cache-dtype`` (R15 task #300) is the canonical knob: int4 is
    # the new default because Apple Silicon decode is memory-bandwidth-
    # bound and a 4×-smaller KV cache cuts bandwidth proportionally
    # (mlx#3134 UMA discussion, Feb 2026 — Phi-3.5-mini +1.1%
    # throughput, 3.2× more context room on Qwen2.5-14B). The
    # safelist in :mod:`vllm_mlx.kv_cache_dtype` auto-downgrades
    # sliding-window (Gemma 3, GPT-OSS) and MLA (DeepSeek V3+,
    # Kimi-K2.5) families to bf16 where int4 breaks decode quality.
    # ``--reasoning`` pins to int8 for AIME-class hard math where
    # sub-4-bit drops -20pt on thinking variants.
    #
    # Qwen3.5-9B-4bit bench (M3, 292-tok prompt, 5×400-tok decode median):
    # int4 113.6 tok/s / 119 ms TTFT / 5388 MB RSS vs bf16 113.7 tok/s /
    # 120 ms TTFT / 5392 MB RSS — int4 is a free swap at this size; the
    # +1.1 % / 3.2× headroom land at multi-k contexts (PR #910 comment).
    serve_parser.add_argument(
        "--kv-cache-dtype",
        type=str,
        default="int4",
        choices=["bf16", "int8", "int4"],
        help=(
            "KV cache dtype (R15 #300, default: int4). Apple Silicon decode "
            "is memory-bandwidth-bound; int4 yields ~4× less bandwidth per "
            "decode step with 97-98%% quality retention. Sliding-window "
            "(Gemma 3, GPT-OSS) and MLA (DeepSeek V3+, Kimi K2.5) models "
            "auto-downgrade to bf16. Use --reasoning for AIME / hard math."
        ),
    )
    serve_parser.add_argument(
        "--reasoning",
        action="store_true",
        default=False,
        help=(
            "Reasoning profile: pins --kv-cache-dtype to int8 regardless of "
            "the dtype flag (sub-4-bit drops -20pt on AIME-class math for "
            "Qwen3 thinking variants)."
        ),
    )
    serve_parser.add_argument(
        "--kv-cache-quantization",
        action="store_true",
        help=(
            "[deprecated alias of --kv-cache-dtype int8] Quantize stored "
            "KV caches to reduce memory (8-bit by default). When both "
            "flags are passed, this one wins for backwards compatibility."
        ),
    )
    serve_parser.add_argument(
        "--kv-cache-quantization-bits",
        type=int,
        default=8,
        choices=[4, 8],
        help="Bit width for KV cache quantization (default: 8)",
    )
    serve_parser.add_argument(
        "--kv-cache-quantization-group-size",
        type=int,
        default=64,
        help="Group size for KV cache quantization (default: 64)",
    )
    serve_parser.add_argument(
        "--kv-cache-min-quantize-tokens",
        type=int,
        default=256,
        help="Minimum tokens for quantization to apply (default: 256)",
    )
    # R15-P1 (task #296): disk-backed KV checkpointing at 256-tok boundaries.
    # 0 disables the feature entirely (no scheduler-hot-path cost, no
    # ~/.cache/qmlx/kv_checkpoints/ directory creation); the default
    # 256 matches MLX-LM's KVCache.step and LMCache's external-chunk size
    # so the on-disk shape aligns with the in-memory shape on reload.
    serve_parser.add_argument(
        "--kv-disk-checkpoint-interval",
        type=int,
        default=256,
        help=(
            "Token interval at which the scheduler snapshots KV state to "
            "~/.cache/qmlx/kv_checkpoints/ for resume / shared-prefix "
            "reload (R15 #296, default 256). 0 disables. Pairs with the "
            "QMLX_KV_CHECKPOINT_MAX_BYTES env var (default 20 GiB) "
            "for the oldest-first disk-cap eviction policy."
        ),
    )
    serve_parser.add_argument(
        "--enable-disk-kv-restore",
        action="store_true",
        default=True,
        help=(
            "Reload a verified KV prefix from disk on a cache miss instead "
            "of re-prefilling (R15 #303, default: enabled — SSD-first, #16). "
            "Requires --kv-disk-checkpoint-interval. Byte-verified and dtype/"
            "schema/memory gated; any mismatch falls back to prefill."
        ),
    )
    serve_parser.add_argument(
        "--disable-disk-kv-restore",
        action="store_true",
        help="Disable disk KV restore-on-miss (opt out of SSD-first reuse).",
    )
    serve_parser.add_argument(
        "--stream-interval",
        type=int,
        default=1,
        help="Tokens to batch before streaming (1=smooth, higher=throughput)",
    )
    serve_parser.add_argument(
        "--max-tokens",
        type=int,
        default=None,
        help="Default max tokens for generation (default: 32768)",
    )
    serve_parser.add_argument(
        "--continuous-batching",
        action="store_true",
        default=True,
        help="Enable continuous batching (default: on).",
    )
    serve_parser.add_argument(
        "--speculative-config",
        dest="speculative_config",
        default=None,
        help=(
            "vLLM-style speculative decoding JSON config. This frontend "
            "parses method/model/num_speculative_tokens now. DFlash "
            "requires the qmlx[dflash] extra and is available with "
            '\'{"method":"dflash"}\', DDTree with '
            '\'{"method":"ddtree"}\', and MTP with '
            '\'{"method":"mtp","num_speculative_tokens":3,'
            '"disable_auto_k":false}\'. SuffixDecoding is an explicit, '
            "workload-specific flag for high prompt/output-overlap traffic "
            "and is available with "
            '\'{"method":"suffix","num_speculative_tokens":8}\'.'
        ),
    )
    # Hidden deprecated aliases. They are intentionally absent from help;
    # normalization folds them into the same SpeculativeConfig path as
    # --speculative-config so old commands do not revive old implementations.
    serve_parser.add_argument(
        "--enable-dflash",
        action="store_true",
        default=False,
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--enable-ddtree",
        action="store_true",
        default=False,
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--spec-decode",
        dest="spec_decode",
        choices=["none", "dflash", "mtp"],
        default="none",
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--dflash-drafter-path",
        default="",
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--enable-mtp",
        action="store_true",
        default=False,
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--mtp-num-draft-tokens",
        type=int,
        default=1,
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--mtp-optimistic",
        action="store_true",
        default=False,
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--mtp-sidecar",
        default=None,
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--mtp-max-k",
        dest="mtp_max_k",
        type=int,
        default=None,
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--mtp-disable-auto-k",
        action="store_true",
        default=False,
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--suffix-decoding",
        action="store_true",
        default=False,
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--suffix-max-draft",
        type=int,
        default=None,
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--suffix-max-suffix-len",
        type=int,
        default=None,
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--suffix-min-confidence",
        type=float,
        default=None,
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--suffix-min-draft-len",
        type=int,
        default=None,
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--gpu-memory-utilization",
        type=float,
        default=0.90,
        help="Fraction of device memory for Metal allocation limit and emergency "
        "cache clear threshold (0.0-1.0, default: 0.90). Increase to 0.95 for "
        "large models (200GB+) that need more memory headroom.",
    )
    # Paged cache options (experimental)
    serve_parser.add_argument(
        "--use-paged-cache",
        action="store_true",
        help="Use paged KV cache for memory efficiency (experimental)",
    )
    serve_parser.add_argument(
        "--paged-cache-block-size",
        type=int,
        default=64,
        help="Tokens per cache block (default: 64)",
    )
    serve_parser.add_argument(
        "--max-cache-blocks",
        type=int,
        default=1000,
        help="Maximum number of cache blocks (default: 1000)",
    )
    # Server-side context cap (issue #33). 0 = no cap (the model's own
    # max context stays the binding limit, preserving pre-#33 behaviour).
    serve_parser.add_argument(
        "--max-context-length",
        type=int,
        default=0,
        help="Cap the served context length in tokens "
        "(prompt + max_tokens); a request above the cap gets HTTP 400 "
        "context_length_exceeded at admission. 0 = no cap, the model's own "
        "maximum context length is the limit (default: 0). "
        "Independent of --max-cache-blocks and composes with it as an AND: "
        "this is a deterministic per-request token cap (400), while "
        "--max-cache-blocks is a KV-capacity lever that bounds aggregate "
        "resident context by max_cache_blocks * paged_cache_block_size and "
        "drives backpressure/eviction (503), not a 400. When both are set a "
        "request must clear the token cap AND fit the block budget; this flag "
        "does not resize the KV cache and vice versa.",
    )
    # Chunked prefill
    serve_parser.add_argument(
        "--chunked-prefill-tokens",
        type=int,
        default=0,
        help="Max prefill tokens per scheduler step (0=disabled). "
        "Breaks large prompts into chunks to prevent concurrent requests from starving. "
        "Recommended for Claude Code and agentic workloads with large tool schemas: "
        "--chunked-prefill-tokens 2048",
    )
    # Prefill step size
    serve_parser.add_argument(
        "--prefill-step-size",
        type=int,
        default=2048,
        help="Chunk size for prompt prefill processing. Larger values use more memory "
        "but can improve prefill throughput. (default: 2048)",
    )
    # MCP options
    serve_parser.add_argument(
        "--mcp-config",
        type=str,
        default=None,
        help="Path to MCP configuration file (JSON/YAML) for tool integration",
    )
    # Security options
    # ``--api-key`` accepts an inline value OR falls back to the
    # ``QMLX_API_KEY`` env var. ``qmlx share`` uses the env-var
    # form so the bearer key never lands in argv (visible to ``ps`` for
    # any local user). Inline value still works for backwards-compat
    # with existing scripts; if both are set, the inline value wins.
    serve_parser.add_argument(
        "--api-key",
        type=str,
        default=None,
        help=(
            "API key for authentication (if not set, falls back to the "
            "QMLX_API_KEY env var; if neither, no auth required)"
        ),
    )
    serve_parser.add_argument(
        "--cors-origins",
        type=str,
        nargs="+",
        default=None,
        metavar="ORIGIN",
        help=(
            "Allowed CORS origins (default: * for all origins). "
            "Example: --cors-origins http://localhost:3000 https://myapp.com"
        ),
    )
    serve_parser.add_argument(
        "--rate-limit",
        type=int,
        default=0,
        help="Rate limit requests per minute per client (0 = disabled)",
    )
    # Hard cap on per-request body size — DoS defense.
    # See ``vllm_mlx/middleware/body_size.py`` for the rationale (pre-fix:
    # a 10 MB body silently ran a ~60 s full prefill on a 27B alias before
    # the client timed out; rapid-desktop#273 + #463). Default 8 MiB fits
    # a 128k-token prompt with tool schemas; 0 disables the cap.
    serve_parser.add_argument(
        "--max-request-bytes",
        type=int,
        default=None,
        help=(
            "Maximum HTTP request body size in bytes (default: 8 MiB = "
            "8388608). Requests over this cap are rejected with HTTP 413 "
            "before JSON parsing or tokenization runs. 0 disables the cap. "
            "Falls back to the QMLX_MAX_REQUEST_BYTES env var if unset."
        ),
    )
    serve_parser.add_argument(
        "--timeout",
        type=float,
        default=1800.0,
        help="Default request timeout in seconds (default: 1800 = 30 min)",
    )
    # Tool calling options
    serve_parser.add_argument(
        "--enable-auto-tool-choice",
        action="store_true",
        help="Enable auto tool choice for supported models. Use --tool-call-parser to specify which parser to use.",
    )
    serve_parser.add_argument(
        "--tool-call-parser",
        type=str,
        default=None,
        # Choices NOT enforced at argparse level — the canonical set is the
        # ToolParserManager registry, which has ~39 entries (canonical
        # names + per-family aliases like ``deepseek_v31``, ``llama4``,
        # ``moonshot`` for kimi, ``nous`` for hermes). The argparse hard-
        # coded list drifted to 19 over multiple releases and rejected
        # legitimate aliases users discovered via ``qmlx info``.
        # Validation now happens post-parse in
        # ``_validate_tool_call_parser_choice`` against the live registry.
        # v0.6.63 onboarding sweep finding #1.
        help=(
            "Select the tool call parser for the model. Canonical options: "
            "auto (auto-detect), mistral, qwen/qwen3/qwen3_xml (reasoning models, "
            "<tool_call>JSON</tool_call> format), qwen3_coder/qwen3_coder_xml "
            "(Coder model, <function=NAME> XML format), llama/llama3/llama4, "
            "hermes/nous, deepseek/deepseek_v3/deepseek_v31, kimi/moonshot/kimi_k2, "
            "granite/granite3, nemotron/nemotron3, xlam, functionary/meetkai, "
            "glm47/glm4, minimax/minimax_m2, harmony/gpt-oss/gpt_oss, "
            "gemma4/gemma_4, seed_oss/seed. "
            "Run `python -c 'from vllm_mlx.tool_parsers import ToolParserManager;"
            "print(sorted(ToolParserManager.tool_parsers))'` for the live list. "
            "Required for --enable-auto-tool-choice."
        ),
    )
    # Tool logits bias (jump-forward decoding for tool call structural tokens)
    serve_parser.add_argument(
        "--enable-tool-logits-bias",
        action="store_true",
        default=False,
        help="Bias logits toward structural tool call tokens for faster generation. "
        "Only active when --tool-call-parser is also set. Currently supports minimax.",
    )
    # Reasoning parser options - choices loaded dynamically from registry
    from .reasoning import list_parsers

    reasoning_choices = list_parsers()
    serve_parser.add_argument(
        "--reasoning-parser",
        type=str,
        default=None,
        choices=reasoning_choices,
        help=(
            "Enable reasoning content extraction with specified parser. "
            "Extracts <think>...</think> tags into reasoning_content field. "
            f"Options: {', '.join(reasoning_choices)}."
        ),
    )
    serve_parser.add_argument(
        "--no-thinking",
        action="store_true",
        default=False,
        help=(
            "Disable reasoning/thinking parser even if auto-detected. "
            "Thinking tokens will appear as regular content. "
            "Useful for faster responses when chain-of-thought is not needed."
        ),
    )
    # Hidden cross-alias mirroring ``chat --no-thinking`` (see the chat
    # parser for the full rationale). ``serve --no-think`` lands on the
    # same ``no_thinking`` destination so users who reach for the shorter
    # name don't get an ``unrecognized arguments`` error.
    serve_parser.add_argument(
        "--no-think",
        dest="no_thinking",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    serve_parser.add_argument(
        "--no-tool-call-parser",
        dest="no_tool_call_parser",
        action="store_true",
        default=False,
        help=(
            "Force-disable tool-call parser auto-detection from the alias "
            "profile. Escape hatch (SOP §10) when AliasProfile's auto-"
            "selected parser misfires for a specific deployment. Mutually "
            "exclusive with --tool-call-parser."
        ),
    )
    serve_parser.add_argument(
        "--no-reasoning-parser",
        dest="no_reasoning_parser",
        action="store_true",
        default=False,
        help=(
            "Force-disable reasoning parser auto-detection from the alias "
            "profile. Distinct from --no-thinking (which also suppresses "
            "the chain-of-thought prompt template) — this flag ONLY skips "
            "the auto-config step. Mutually exclusive with --reasoning-parser."
        ),
    )
    # SOP §10 profile-override escape hatches. Pair every binary
    # auto-routing field with both force-on and force-off CLI flags so
    # users always have an override path when the AliasProfile
    # auto-detection misfires. Registered in
    # tests/test_no_mllm_flag.py::test_auto_routing_flags_have_force_on_and_force_off_pair.
    serve_parser.add_argument(
        "--force-hybrid",
        dest="force_hybrid",
        action="store_true",
        default=False,
        help=(
            "Force-treat the model as a hybrid (linear-attention / Mamba) "
            "architecture even when AliasProfile says otherwise. Disables "
            "spec/suffix decode paths that are unsound on hybrids. "
            "Mutually exclusive with --no-hybrid."
        ),
    )
    serve_parser.add_argument(
        "--no-hybrid",
        dest="no_hybrid",
        action="store_true",
        default=False,
        help=(
            "Force-treat the model as non-hybrid (full attention) even when "
            "AliasProfile says it's hybrid. Use when the profile mis-labels "
            "your model and you want spec/suffix decode enabled. "
            "Mutually exclusive with --force-hybrid."
        ),
    )
    serve_parser.add_argument(
        "--force-spec-decode",
        dest="force_spec_decode",
        action="store_true",
        default=False,
        help=(
            "Force-enable speculative-decode eligibility even when "
            "AliasProfile says the model doesn't support it. Risky on "
            "hybrid models — use only when you've verified the profile "
            "is wrong. Mutually exclusive with --no-spec-decode."
        ),
    )
    serve_parser.add_argument(
        "--no-spec-decode",
        dest="no_spec_decode",
        action="store_true",
        default=False,
        help=(
            "Force-disable speculative-decode eligibility (suffix / MTP / "
            "DFlash / DDTree) even when AliasProfile says the model supports it. "
            "Mutually exclusive with --force-spec-decode."
        ),
    )
    # #516 — HarmonyStreamingRouter auto-upgrade escape hatches (G11).
    # PR #515 introduced an auto-upgrade from the legacy harmony state
    # machine to openai-harmony's StreamableParser for matched-vocab
    # gpt-oss tokenizers. The auto-detection is conservative (three-layer
    # compat check) but the SOP requires every binary auto-routing
    # decision expose both force-on and force-off CLI flags.
    serve_parser.add_argument(
        "--force-openai-harmony-streaming",
        dest="force_openai_harmony_streaming",
        action="store_true",
        default=False,
        help=(
            "Force-on: construct HarmonyStreamingRouter even when the "
            "compat gate would reject. Use to debug a regression in the "
            "gate itself; production should leave this off. Mutually "
            "exclusive with --no-openai-harmony-streaming."
        ),
    )
    serve_parser.add_argument(
        "--no-openai-harmony-streaming",
        dest="no_openai_harmony_streaming",
        action="store_true",
        default=False,
        help=(
            "Force-off: skip the HarmonyStreamingRouter upgrade and use "
            "the legacy custom harmony state machine even on matched-vocab "
            "gpt-oss tokenizers. Escape hatch for a hypothetical false "
            "positive in the compat gate. Mutually exclusive with "
            "--force-openai-harmony-streaming."
        ),
    )
    # GC control (Tier 0 optimization)
    serve_parser.add_argument(
        "--gc-control",
        action="store_true",
        default=True,
        help="Enable Python GC pausing during generation to avoid latency spikes (default: enabled)",
    )
    serve_parser.add_argument(
        "--no-gc-control",
        action="store_true",
        help="Disable GC control (allow normal Python GC during generation)",
    )
    # Pinned prefix cache (Tier 0 optimization)
    serve_parser.add_argument(
        "--pin-system-prompt",
        action="store_true",
        default=False,
        help="Auto-pin system prompt in prefix cache to prevent eviction under memory pressure",
    )
    # Multimodal option
    serve_parser.add_argument(
        "--mllm",
        action="store_true",
        help="Force load model as multimodal (vision) even if name doesn't match auto-detection patterns",
    )
    serve_parser.add_argument(
        "--no-mllm",
        "--text-only",
        dest="no_mllm",
        action="store_true",
        help="Force load model as text-only LLM even when auto-detection would route it to the multimodal/VLM path. Escape hatch for incomplete vision-tower checkpoints (#393) and text-only forks of multimodal architectures whose config.json still declares vision_config.",
    )
    # Generation defaults
    serve_parser.add_argument(
        "--default-temperature",
        type=float,
        default=None,
        help="Override default temperature for all requests (default: use model default)",
    )
    serve_parser.add_argument(
        "--default-top-p",
        type=float,
        default=None,
        help="Override default top_p for all requests (default: use model default)",
    )
    serve_parser.add_argument(
        "--default-top-k",
        type=int,
        default=None,
        help="Override default top_k for all requests (default: use model default)",
    )
    serve_parser.add_argument(
        "--default-min-p",
        type=float,
        default=None,
        help="Override default min_p for all requests (default: use model default)",
    )
    serve_parser.add_argument(
        "--default-repetition-penalty",
        type=float,
        default=None,
        help="Override default repetition_penalty for all requests (default: use model default)",
    )
    serve_parser.add_argument(
        "--default-presence-penalty",
        type=float,
        default=None,
        help="Override default presence_penalty for all requests (default: use model default)",
    )
    serve_parser.add_argument(
        "--default-frequency-penalty",
        type=float,
        default=None,
        help="Override default frequency_penalty for all requests (default: use model default)",
    )
    # Cloud routing options
    serve_parser.add_argument(
        "--cloud-model",
        type=str,
        default=None,
        help="Cloud model string for litellm (e.g. 'anthropic/claude-sonnet-4-5-20250929'). "
        "When set, large-context requests are routed to the cloud provider.",
    )
    serve_parser.add_argument(
        "--cloud-threshold",
        type=int,
        default=20000,
        help="New token threshold to trigger cloud routing (default: 20000). "
        "Only requests with more new (uncached) tokens than this are routed.",
    )
    serve_parser.add_argument(
        "--cloud-api-base",
        type=str,
        default=None,
        help="Custom API base URL for cloud model (for OpenAI-compatible providers like Zhipu).",
    )
    serve_parser.add_argument(
        "--cloud-api-key",
        type=str,
        default=None,
        help="API key for cloud model (overrides environment variable).",
    )
    # Parent-PID watchdog (rapid-desktop issue #449). When set, the
    # sidecar polls ``os.getppid()`` every 2 s and self-terminates if
    # the parent dies (re-parent to launchd / init on macOS/Linux). The
    # supervisor passes its own PID at spawn so a SIGKILL on the desktop
    # cannot leave a 30 GB orphan holding the model + port. ``0`` /
    # negative / unset disables. The ``QMLX_WATCHDOG_PPID`` env var
    # is honoured as a fallback when the CLI flag is omitted; the flag
    # wins when both are present.
    serve_parser.add_argument(
        "--watchdog-ppid",
        type=int,
        default=None,
        metavar="PID",
        help=(
            "Self-terminate when the parent with this PID dies (defeats "
            "orphan-sidecar after SIGKILL on the supervisor). Honors "
            "$QMLX_WATCHDOG_PPID as a fallback. Set to 0 / unset to "
            "disable."
        ),
    )
    # Models command. ``ls`` is registered as a top-level alias that
    # defaults to ``models --cached`` (the locally-cached view) — two
    # muscle-memory entry points, one underlying impl.
    models_parser = subparsers.add_parser("models", help="List available model aliases")
    models_parser.add_argument(
        "--cached",
        action="store_true",
        default=False,
        help="Only list models that are downloaded to the local HuggingFace "
        "cache (alias, HF repo, size on disk, last modified).",
    )
    models_parser.add_argument(
        "--all",
        dest="all_models",
        action="store_true",
        default=False,
        help=(
            "Show every alias — disables the terminal-height cap (issue #62). "
            "Installed rows still sort first."
        ),
    )
    subparsers.add_parser(
        "ls",
        help="List models in the local HuggingFace cache (alias for `models --cached`)",
    )

    # Version + help — utility commands that mirror the existing flags but
    # are scriptable as plain subcommands.
    subparsers.add_parser("version", help="Show version number")
    help_parser = subparsers.add_parser("help", help="Show help for a subcommand")
    help_parser.add_argument(
        "subcommand", nargs="?", help="Subcommand to show help for (omit for top-level)"
    )

    # Pull / rm / ps — Ollama-style cache and process management.
    pull_parser = subparsers.add_parser(
        "pull", help="Download a model to the HuggingFace cache (no server)"
    )
    pull_parser.add_argument(
        "model", help="Model alias (e.g. qwen3.5-4b-4bit) or HF repo (org/name)"
    ).completer = alias_completer
    rm_parser = subparsers.add_parser(
        "rm", help="Remove a cached model from the HuggingFace cache"
    )
    rm_parser.add_argument(
        "model", help="Model alias (e.g. qwen3.5-4b-4bit) or HF repo (org/name)"
    ).completer = alias_completer
    rm_parser.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Skip the confirmation prompt and remove the model immediately.",
    )
    subparsers.add_parser("ps", help="List running qmlx servers")

    # Status — read-only /v1/status client (issue #51, phase 3).
    status_parser = subparsers.add_parser(
        "status",
        help="Show live status of a running qmlx server",
        description=(
            "Query a running qmlx server's /v1/status endpoint and render "
            "the result (one-shot by default; --watch polls until Ctrl-C)."
        ),
    )
    status_parser.add_argument(
        "target",
        nargs="?",
        default=None,
        help="host:port or base URL of a running server (default: 127.0.0.1:8000)",
    )
    status_parser.add_argument(
        "--watch",
        action="store_true",
        help="Poll until Ctrl-C instead of one-shot",
    )
    status_parser.add_argument(
        "--timeout",
        type=float,
        default=3.0,
        help="Per-request timeout in seconds (default: 3.0)",
    )

    # TUI — Textual chat TUI (issue #51, phase 4; optional [tui] extra).
    tui_parser = subparsers.add_parser(
        "tui",
        help="Textual chat TUI (requires the [tui] extra)",
    )
    tui_parser.add_argument(
        "model",
        nargs="?",
        default="qwen3.5-4b-4bit",
        help="Model alias to display (server-side model name).",
    ).completer = alias_completer
    tui_parser.add_argument(
        "--port", type=int, default=None, help="Port of a running server to connect to"
    )
    tui_parser.add_argument(
        "--base-url",
        default=None,
        help="Base URL of a running server (http://host:port)",
    )
    tui_parser.add_argument("--system", type=str, default=None, help="System prompt")

    # Upgrade — detect install method and run the right upgrade command
    upgrade_parser = subparsers.add_parser(
        "upgrade",
        help="Upgrade qmlx to the latest version (brew / pip / install.sh)",
    )
    upgrade_parser.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Skip the confirmation prompt and run the upgrade immediately.",
    )
    upgrade_parser.add_argument(
        "--dry-run",
        action="store_true",
        help=(
            "Print the detected install method and the upgrade command, "
            "then exit without running it."
        ),
    )

    # Chat — interactive REPL backed by a (spawned or existing) server.
    # ``run`` is exposed as a subparser alias purely for Ollama-muscle-memory
    # parity (``ollama run <model>``). Both names route to ``chat_command``.
    chat_parser = subparsers.add_parser(
        "chat",
        aliases=["run"],
        help="Interactive chat REPL with a model",
        description=(
            "Interactive chat REPL with a model.\n\n"
            "Note: 'qmlx run' is an alias for 'chat' (Ollama compatibility)."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        # See serve_parser for the rationale: ``--think``/``--no-think`` +
        # ``--thinking``/``--no-thinking`` cross-aliases create ambiguous
        # prefixes that argparse silently resolves to whichever flag was
        # added first.
        allow_abbrev=False,
    )
    chat_parser.add_argument(
        "model",
        nargs="?",
        default="qwen3.5-4b-4bit",
        help="Model alias (e.g. qwen3.5-4b-4bit) or HF repo (org/name). "
        "Defaults to qwen3.5-4b-4bit when omitted.",
    ).completer = alias_completer
    chat_parser.add_argument(
        "--system",
        type=str,
        default=None,
        help="System prompt prepended to the conversation",
    )
    chat_parser.add_argument(
        "--think",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Enable thinking/reasoning mode (default: off in chat REPL — "
        "reasoning models like Qwen3.5 otherwise leak raw chain-of-thought "
        "and can loop until max-tokens). Use --think to surface reasoning, "
        "--no-think is also accepted for back-compat.",
    )
    # Hidden cross-alias for users who picked up the ``--no-thinking`` muscle
    # memory from ``qmlx serve``. ``serve --no-thinking`` and
    # ``chat --no-think`` mean different things internally (server-side
    # parser disable vs. per-request ``enable_thinking=false``), but the
    # flag-name difference trips users. We accept the wrong-side name as
    # an alias for the right-side semantics: ``chat --no-thinking`` simply
    # forwards to the same destination as ``--no-think``.
    chat_parser.add_argument(
        "--no-thinking",
        dest="think",
        action="store_false",
        help=argparse.SUPPRESS,
    )
    chat_parser.add_argument(
        "--max-tokens",
        type=int,
        default=None,
        help="Max tokens per assistant response (default: 2048; raised to "
        "4096 when --think is set so reasoning + answer fit the budget).",
    )
    chat_parser.add_argument(
        "--temperature",
        type=float,
        default=0.7,
        help="Sampling temperature (default: 0.7)",
    )
    chat_parser.add_argument(
        "--port",
        type=_port_arg,
        default=None,
        help="Connect to existing server on 127.0.0.1:<port> instead of spawning",
    )
    chat_parser.add_argument(
        "--base-url",
        type=str,
        default=None,
        help="Connect to existing server URL (e.g. http://host:8000) "
        "instead of spawning. Overrides --port.",
    )
    chat_parser.add_argument(
        "--ready-timeout",
        type=int,
        default=600,
        help="Seconds to wait for the spawned server to become ready (default: 600)",
    )
    chat_parser.add_argument(
        "--tui",
        action="store_true",
        help="Use the Textual TUI instead of the REPL (requires the [tui] extra)",
    )
    chat_parser.add_argument(
        "--response-timeout",
        type=int,
        default=600,
        help="Seconds to wait for a single assistant response (default: 600)",
    )

    # Info command — show the per-model profile (parsers + capability gates)
    info_parser = subparsers.add_parser(
        "info",
        help="Show the per-model profile for a model name or alias",
    )
    info_parser.add_argument(
        "model",
        help="Model alias (e.g. qwen3.5-4b-4bit) or HF repo (e.g. mlx-community/SmolLM3-3B-4bit)",
    ).completer = alias_completer

    # Jlens command — read a model's internal "draft" with the Jacobian lens
    jlens_parser = subparsers.add_parser(
        "jlens",
        help="Read a model's internal thoughts across layers (Jacobian lens)",
    )
    jlens_parser.add_argument(
        "prompt",
        help='Prompt to trace, e.g. "why is the sky blue"',
    )
    jlens_parser.add_argument(
        "--model",
        "-m",
        default="qwen3-1.7b",
        help="Model alias or HF repo to inspect (default: qwen3-1.7b)",
    ).completer = alias_completer
    jlens_parser.add_argument(
        "--step",
        type=int,
        default=2,
        help="Probe every Nth layer (default: 2; use 1 for full-resolution)",
    )
    jlens_parser.add_argument(
        "--json",
        action="store_true",
        help="Emit machine-readable JSON instead of the rendered view",
    )
    jlens_parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Show full per-layer readouts and the answer's rank trajectory",
    )

    # Agents command
    agents_parser = subparsers.add_parser(
        "agents", help="List, configure, and test agent integrations"
    )
    agents_parser.add_argument(
        "agent_name",
        nargs="?",
        default=None,
        help="Agent name (e.g. codex, opencode, qwen-code, aider). Omit to list all.",
    )
    agents_parser.add_argument(
        "--setup",
        action="store_true",
        help="Auto-configure the agent to point at this server",
    )
    agents_parser.add_argument(
        "--test",
        action="store_true",
        help="Run integration tests for this agent",
    )
    agents_parser.add_argument(
        "--model",
        type=str,
        default=None,
        help="Model to use (default: auto-detect from running server)",
    ).completer = alias_completer
    agents_parser.add_argument(
        "--base-url",
        type=str,
        default="http://localhost:8000/v1",
        help="qMLX server URL (default: http://localhost:8000/v1)",
    )
    agents_parser.add_argument(
        "--agent-version",
        type=str,
        default=None,
        help="Agent version for version-specific config (e.g. 0.8.5)",
    )

    # Doctor command — pure env-health probe (≤5 s, no model load, no server).
    # Launch subcommand — one-shot bootstrap that patches IDE/agent
    # client configs (Cline, Claude Code, Continue, Cursor) to route
    # at the local qmlx server. See GH issue #566 for motivation.
    # Registered AFTER share so the help-text ordering reads
    # serve→…→share→launch, matching the rough "more common first" flow.
    from vllm_mlx.launch.cli import register as _register_launch

    _register_launch(subparsers)

    args = parser.parse_args()

    # Resolve model aliases before dispatch.
    #
    # The doctor subcommand is exempt for historical reasons (and as a
    # belt-and-suspenders guard now that doctor doesn't take ``--model``):
    # an env-health probe should never trigger an alias→path lookup.
    if (
        hasattr(args, "model")
        and args.model
        and getattr(args, "command", None) != "doctor"
    ):
        from vllm_mlx.model_aliases import resolve_model

        resolved = resolve_model(args.model)
        if resolved != args.model:
            # Keep stdout pure JSON for machine-readable modes (jlens --json);
            # the human-facing alias banner goes to stderr there.
            _alias_stream = (
                sys.stderr
                if getattr(args, "command", None) == "jlens"
                and getattr(args, "json", False)
                else sys.stdout
            )
            print(f"  Alias: {args.model} → {resolved}", file=_alias_stream)
            args._original_alias = args.model
            args.model = resolved
        elif "/" not in args.model and not os.path.exists(args.model):
            # Not an alias, not a HuggingFace org/name path, not a local
            # directory — fail fast with suggestions instead of letting
            # the request hit HuggingFace and 404 with a 30-line trace.
            print(
                f"\n  Error: '{args.model}' is not a known alias or HuggingFace path."
            )
            _print_unknown_model_help(
                args.model, full_path_example="mlx-community/Qwen3.5-9B-4bit"
            )
            sys.exit(1)

    # --- BEGIN B2: auto-pull confirmation gate -------------------------
    # For subcommands that may trigger a first-time download of a large
    # repo (chat/run/serve/pull/bench), warn the user before kicking off
    # a multi-GB transfer. Cached repos and small downloads pass through
    # invisibly. Env override: QMLX_AUTO_PULL=1. See
    # ``vllm_mlx/_download_gate.py`` for the policy.
    #
    # Codex round 1 surfaced two ordering issues:
    #   (a) the chat REPL spawns its own ``serve`` subprocess after the
    #       parent already gated; without QMLX_CHAT_SPAWN=1 in the
    #       child env, the second main() would re-prompt (or worse,
    #       deadlock on a non-TTY child stdin path that doesn't reach
    #       the early-return).
    #   (b) the env / TTY checks belong *before* the 5-second HF
    #       metadata fetch — otherwise every CI run that sets
    #       QMLX_AUTO_PULL=1 still pays the network round-trip.
    # Single-use marker: pop the env var as soon as we observe it so a
    # grandchild ``qmlx`` spawn (e.g. a nested invocation from a
    # user hook, a doctor self-probe, or some future hub helper) does
    # NOT inherit the bypass. Codex round-2 BLOCKING #2.
    _chat_spawn_child = os.environ.pop("QMLX_CHAT_SPAWN", "") == "1"

    _GATED_COMMANDS = {"chat", "run", "serve", "pull", "jlens"}
    if (
        getattr(args, "command", None) in _GATED_COMMANDS
        and hasattr(args, "model")
        and args.model
        and "/" in args.model  # only HF-style repo ids; local paths skip
        and not os.path.exists(args.model)
        and not _chat_spawn_child
    ):
        # Cheap checks first: env override and non-TTY both short-circuit
        # without touching the HF API. ``confirm_or_abort`` re-checks
        # both internally; we mirror them here so we can skip the size
        # estimate as well.
        _env_val = os.environ.get("QMLX_AUTO_PULL", "").strip().lower()
        _auto_yes = _env_val in {"1", "true", "yes"}
        _interactive = sys.stdin.isatty()
        if not _auto_yes and _interactive:
            from vllm_mlx._download_gate import (
                confirm_or_abort,
                estimate_repo_size_bytes,
                is_repo_cached,
            )

            if not is_repo_cached(args.model):
                confirm_or_abort(
                    args.model,
                    estimate_repo_size_bytes(args.model),
                )
    # --- END B2 --------------------------------------------------------

    if args.command == "serve":
        serve_command(args)
    elif args.command == "models":
        models_command(args)
    elif args.command == "ls":
        # `ls` is a top-level alias for `models --cached`. Synthesize the
        # missing flag so models_command's branch fires without having to
        # know which command name it was invoked under.
        args.cached = True
        models_command(args)
    elif args.command == "version":
        print(f"qmlx {_version}")
    elif args.command == "help":
        target = getattr(args, "subcommand", None)
        if not target:
            parser.print_help()
        elif target in subparsers.choices:
            subparsers.choices[target].print_help()
        else:
            import difflib

            print(f"Unknown subcommand: {target}")
            matches = difflib.get_close_matches(
                target, list(subparsers.choices.keys()), n=3, cutoff=0.6
            )
            if matches:
                print(f"  Did you mean: {', '.join(matches)}?")
            print("Run `qmlx help` for the list of subcommands.")
            sys.exit(1)
    elif args.command == "pull":
        pull_command(args)
    elif args.command == "rm":
        rm_command(args)
    elif args.command == "ps":
        ps_command(args)
    elif args.command == "status":
        status_command(args)
    elif args.command == "tui":
        tui_command(args)
    elif args.command == "upgrade":
        upgrade_command(args)
    elif args.command in ("chat", "run"):
        # ``run`` is exposed as a subparser alias for Ollama compatibility;
        # argparse routes via ``aliases=`` but reports the user-typed name
        # on ``args.command``. Both names land here.
        chat_command(args)
    elif args.command == "info":
        info_command(args)
    elif args.command == "jlens":
        from vllm_mlx.jlens import jlens_command

        jlens_command(args)
    elif args.command == "agents":
        agents_command(args)
    elif args.command == "launch":
        from vllm_mlx.launch.cli import launch_command

        launch_command(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
