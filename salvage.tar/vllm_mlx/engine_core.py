# SPDX-License-Identifier: Apache-2.0
"""
Engine Core for qmlx continuous batching.

This module provides the EngineCore class that coordinates:
- Model loading and management
- Request scheduling via Scheduler
- Async request processing
- Output streaming

The design follows vLLM's engine architecture adapted for MLX.

Design: multiplexing, not parallelisation. qMLX targets
bandwidth-bound devices, so many requests interleave on one stream
rather than overlapping on several. All model/KV-touching MLX work
runs on a single owner thread, the ``mlx-step`` worker (see
``_init_mlx_step_thread``); the asyncio loop only dispatches to it.
The disk-KV cold-cache restore tier (``runtime/disk_kv_checkpoint.py``)
is a first-class memory tier: the SSD is the RAM of the second tier,
and a cache miss reloads a checkpoint instead of re-prefilling. The
one-owner-thread rule is the conformance contract ported backends
(``mlx-rocm`` / ``mlx-cuda``) must honour (``vllm_mlx.device.backend``,
"Stream contract").
"""

import asyncio
import concurrent.futures
import logging
import os
import sys
import time
import uuid
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

import mlx.core as mx

from .model_registry import get_registry
from .output_collector import RequestOutputCollector, RequestStreamState
from .request import Request, RequestOutput, SamplingParams
from .scheduler import Scheduler, SchedulerConfig

logger = logging.getLogger(__name__)


def _init_mlx_step_thread() -> None:
    """Create the MLX worker thread's generation stream binding.

    Design: one owner thread per device. This worker owns every
    model/KV-touching MLX op in the process; the asyncio loop only
    dispatches to it. Bandwidth-bound devices interleave, they do not
    overlap: a second thread issuing MLX work would contend on stream
    state rather than share the stream. This rule is the conformance
    contract ported backends (``mlx-rocm`` / ``mlx-cuda``) honour
    (``vllm_mlx.device.backend``, "Stream contract").

    Runs once when the executor spawns its single worker. Steps:

    1. Adopt this thread's default stream. MLX streams are thread-local,
       and mlx-lm / mlx-vlm both hold a module-level
       ``generation_stream`` created on the import thread (the asyncio
       loop / main thread); operations queued onto a stream another
       thread created cannot be ``mx.eval``-ed from here (``RuntimeError:
       There is no Stream(gpu, N) in current thread.``).
    2. Reassign the module-level ``generation_stream`` in BOTH
       ``mlx_lm.generate`` and ``mlx_vlm.generate`` (Gemma 4 etc. lives
       in the latter, and their ``with mx.stream(generation_stream)``
       blocks otherwise capture the import-thread stream).
    3. Convergence: anything that allocates an ``mx.array`` without an
       explicit stream context (e.g.
       ``BatchRotatingKVCache.__init__`` doing ``mx.array(left_padding)``
       inside ``BatchGenerator._next()``'s prompt cache merge) lands on
       this thread's default stream, the one we adopted, so ad-hoc
       allocations and ``with mx.stream(...)`` blocks converge on a
       single stream the owner can eval.
    """
    # MLX streams are thread-local, and mlx-lm's module-level
    # generation_stream was created on the import thread. BatchGenerator
    # captures `self._stream = stream or generation_stream` at __init__,
    # so a stream captured from the import thread cannot be eval'd from
    # this owner worker ("There is no Stream(gpu, N) in current
    # thread.").
    #
    # Adopt the worker thread's auto-default stream rather than creating a
    # NEW stream. MLX lazily creates a default stream per-thread on first
    # access — using that stream guarantees ad-hoc `mx.array(...)` calls
    # (which use the default stream when no `with mx.stream(...)` context
    # is active) and our `with mx.stream(stream)` overrides converge on the
    # same stream. Creating a new ThreadLocalStream and reassigning it can
    # leave the worker's TRUE default at a different index, so any path that
    # falls back to the default mid-flight ends up tagging arrays with one
    # stream while BatchGenerator evals against the other.
    stream = mx.default_stream(mx.default_device())

    for mod_name in ("mlx_lm.generate", "mlx_vlm.generate"):
        gen_mod = sys.modules.get(mod_name)
        if gen_mod is not None:
            gen_mod.generation_stream = stream

    logger.info(
        "MLX step thread initialized: stream=%s (worker default = generation_stream)",
        stream,
    )


@dataclass
class EngineConfig:
    """Configuration for the engine."""

    model_name: str = ""
    scheduler_config: SchedulerConfig | None = None
    # Housekeeping cadence when the scheduler is empty. The loop wakes
    # immediately on a new ``add_request`` via an asyncio Event; this
    # interval only bounds idle wake-ups for periodic checks. Bumped from
    # 1 ms (kHz polling) to 5 s (0.2 Hz) — see issue #265.
    step_interval: float = 5.0
    stream_interval: int = 1  # Tokens to batch before streaming (1=every token)
    gpu_memory_utilization: float = 0.90  # Fraction of device memory for allocation
    tool_logits_processor_factory: Any | None = None  # Factory for tool logits bias
    # NOTE: DFlash speculative decoding (issue #264) bypasses the
    # BatchedEngine entirely via a dedicated server module
    # (``vllm_mlx.spec_decode.dflash.server``). No engine-side fields
    # are needed today. If a future phase-2 brings DFlash inside
    # BatchedEngine for B>1 support, add the config fields back here
    # and wire them through ``EngineCore.__init__``.

    # ---- SOP §10 routing-override escape hatches ----
    # CLI surfaces these as --force-hybrid / --no-hybrid / etc. Applied
    # to ``self.model_config`` right after ``enrich_model_config()`` so
    # downstream Scheduler reads see the user's override. None (default)
    # means "respect auto-detection".
    force_hybrid: bool = False
    no_hybrid: bool = False
    force_spec_decode: bool = False
    no_spec_decode: bool = False


class EngineCore:
    """
    Core engine for qmlx inference with continuous batching.

    This engine runs the generation loop and manages request lifecycle.
    It provides both sync and async interfaces for request handling.
    """

    def __init__(
        self,
        model: Any,
        tokenizer: Any,
        config: EngineConfig | None = None,
        engine_id: str | None = None,
        force_model_ownership: bool = True,
    ):
        """
        Initialize the engine.

        Args:
            model: The MLX model
            tokenizer: The tokenizer
            config: Engine configuration
            engine_id: Optional unique ID for this engine (auto-generated if None)
            force_model_ownership: If True (default), forcibly take model ownership
                                   from any existing engine. If False, raises
                                   ModelOwnershipError if model is in use.
        """
        self.model = model
        self.tokenizer = tokenizer
        self.config = config or EngineConfig()
        self._engine_id = engine_id or str(uuid.uuid4())
        self._owns_model = False
        self._closed = False

        # Acquire model ownership
        registry = get_registry()
        registry.acquire(
            model=model,
            engine=self,
            engine_id=self._engine_id,
            force=force_model_ownership,
        )
        self._owns_model = True

        # Create scheduler
        scheduler_config = self.config.scheduler_config or SchedulerConfig()
        # D-METAL-CAP: propagate the engine-level ``gpu_memory_utilization``
        # to the scheduler so its admission gate can enforce the same cap
        # that the allocator (seam ``enforcement_mode == HINT``) only
        # treats as a hint. Skip when the
        # caller already wired it explicitly to a non-zero value so unit
        # tests that craft a SchedulerConfig in isolation retain their
        # explicit setting.
        #
        # Codex round 3 NIT #3: narrow the exception filter to
        # ``AttributeError``/``TypeError`` — a bare ``except Exception``
        # would silently swallow ANY failure here (including a
        # ``RuntimeError`` from a frozen-dataclass subclass) and the
        # operator would be left with a disabled admission gate despite
        # the CLI flag being set. Logging at WARN gives an actionable
        # signal; the engine still starts so a malformed scheduler-
        # config layer can't take down the server.
        try:
            if (
                getattr(scheduler_config, "gpu_memory_utilization", 0.0) <= 0.0
                and getattr(self.config, "gpu_memory_utilization", 0.0) > 0.0
            ):
                scheduler_config.gpu_memory_utilization = (
                    self.config.gpu_memory_utilization
                )
        except (AttributeError, TypeError) as e:
            logger.warning(
                "[D-METAL-CAP] could not propagate gpu_memory_utilization "
                "into scheduler_config (%s); admission cap will stay "
                "disabled even though CLI flag is set",
                e,
            )
        self.scheduler = Scheduler(
            model=model,
            tokenizer=tokenizer,
            config=scheduler_config,
            tool_logits_processor_factory=self.config.tool_logits_processor_factory,
        )
        # Disk-KV checkpoint/restore keys on the scheduler's model identity.
        # Without this the scheduler's ``_model_name`` is None, so every
        # checkpoint is written identity-less and the restore identity guard
        # fail-closes (rejects on unknown model). Stamp it from the engine
        # config, same source used for model_path detection above.
        self.scheduler._model_name = (
            getattr(self.config, "model_name", None)
            or getattr(self.config, "model_path", None)
        ) or None

        # Output collectors for low-latency streaming (vLLM pattern)
        self._output_collectors: dict[str, RequestOutputCollector] = {}
        self._stream_states: dict[str, RequestStreamState] = {}
        self._finished_events: dict[str, asyncio.Event] = {}
        # Per-request accumulator for stream_interval > 1: each step's
        # new_text/new_token_ids delta is merged here regardless of
        # should_send(); the buffer is flushed in one shot when should_send()
        # triggers, so no token deltas are dropped between sends.
        self._stream_buffers: dict[str, RequestOutput] = {}

        # Engine state
        self._running = False
        self._task: asyncio.Task | None = None
        self._start_time: float | None = None
        self._steps_executed = 0

        # Idle-wakeup signal: ``add_request`` sets this so the engine loop
        # can wait on it instead of polling at kHz when the scheduler is
        # empty. Lazy-created in ``_engine_loop`` because asyncio.Event
        # binds to the running loop. See issue #265.
        self._idle_event: asyncio.Event | None = None

        # The single mlx-step worker, the owner of all model/KV-touching
        # MLX work (created on demand in start(); see
        # _init_mlx_step_thread). Design: one owner thread per device:
        # bandwidth-bound devices interleave, they do not overlap; the
        # asyncio loop only dispatches to this executor. MLX streams are
        # thread-local, so a non-owner thread evaluating the owner's
        # stream raises "There is no Stream(gpu, N) in current thread."
        self._mlx_executor: concurrent.futures.ThreadPoolExecutor | None = None
        # True when we created the executor in ``start()`` and own its
        # lifecycle; False when the caller supplied an existing executor
        # (e.g. tests that load the model on the worker thread first to
        # avoid the cross-thread Stream(gpu, N) error). Caller-owned
        # executors are NOT shut down by ``stop()``.
        self._owns_executor: bool = False

        # Per-model capability profile. Runtime probe acts as the safety
        # net for unknown hybrid arches; regex-based defaults from
        # ``detect_model_config`` flow in via the engine config when the
        # model name is known.
        from .model_auto_config import (
            detect_model_config,
            enrich_model_config,
            format_profile_summary,
            format_profile_table,
            suffix_decoding_hint,
        )

        model_path = (
            getattr(self.config, "model_name", None)
            or getattr(self.config, "model_path", None)
            or getattr(model, "name_or_path", None)
        )
        # Guard against MagicMock / non-string sentinels coming from test
        # stubs and partially-loaded models.
        if not isinstance(model_path, str) or not model_path:
            model_path = None
        base_cfg = detect_model_config(model_path) if model_path else None
        self.model_config = enrich_model_config(base_cfg, model)

        # SOP §10: apply CLI routing-override escape hatches *after*
        # auto-detection/enrichment but *before* the scheduler reads
        # capability gates. Mutex pairs (force_X / no_X) are validated
        # at the CLI layer and re-validated here as a second line of
        # defense for programmatic callers. ModelConfig is non-frozen
        # so direct mutation is fine; we only touch fields whose
        # override flag was explicitly set.
        if self.config.force_hybrid and self.config.no_hybrid:
            raise ValueError("force_hybrid and no_hybrid are mutually exclusive")
        if self.config.force_spec_decode and self.config.no_spec_decode:
            raise ValueError(
                "force_spec_decode and no_spec_decode are mutually exclusive"
            )
        if self.config.no_hybrid:
            self.model_config.is_hybrid = False
            logger.info("Routing override: is_hybrid forced False via --no-hybrid")
        elif self.config.force_hybrid:
            self.model_config.is_hybrid = True
            logger.info("Routing override: is_hybrid forced True via --force-hybrid")
        if self.config.no_spec_decode:
            self.model_config.supports_spec_decode = False
            logger.info(
                "Routing override: supports_spec_decode forced False via --no-spec-decode"
            )
        elif self.config.force_spec_decode:
            self.model_config.supports_spec_decode = True
            logger.info(
                "Routing override: supports_spec_decode forced True via --force-spec-decode"
            )

        # Plumb profile into Scheduler so spec-decode installs can consult
        # capability gates (e.g. ``supports_spec_decode``).
        self.scheduler.model_config = self.model_config
        self._hybrid_throttle = self.model_config.is_hybrid
        self._hybrid_lock: asyncio.Lock | None = None  # lazy-init in event loop
        self._last_request_time = 0.0

        # Level 1 — always emit a one-line profile summary on engine init.
        # Level 2 — verbose ASCII capability table when explicitly requested
        # via env var ``QMLX_PROFILE_VERBOSE=1`` (or set on EngineConfig).
        display_path = model_path or "(unknown)"
        logger.info(format_profile_summary(display_path, self.model_config))
        if os.environ.get("QMLX_PROFILE_VERBOSE") == "1" or getattr(
            self.config, "verbose_profile", False
        ):
            for line in format_profile_table(
                display_path, self.model_config
            ).splitlines():
                logger.info(line)

        # SuffixDecoding eligibility hint — silent for unknown/neutral tiers
        # so this only fires when the bench has data worth surfacing.
        hint = suffix_decoding_hint(self.model_config)
        if hint:
            logger.info(hint)

        logger.debug(f"Engine {self._engine_id} initialized")

    async def start(
        self, executor: concurrent.futures.ThreadPoolExecutor | None = None
    ) -> None:
        """Start the engine loop.

        Args:
            executor: Optional pre-existing single-thread executor (whose
                worker is the mlx-step thread that already loaded the model).
                Reusing the same worker keeps every MLX op (model weights,
                forward passes, cache state) bound to the single owner
                thread (the engine's stream contract; see
                ``vllm_mlx.device.backend``). When None, a fresh executor is
                created.
        """
        if self._running:
            return

        if executor is not None:
            self._mlx_executor = executor
            self._owns_executor = False
        else:
            self._mlx_executor = concurrent.futures.ThreadPoolExecutor(
                max_workers=1,
                thread_name_prefix="mlx-step",
                initializer=_init_mlx_step_thread,
            )
            self._owns_executor = True
        self._running = True
        self._start_time = time.time()
        self._task = asyncio.create_task(self._engine_loop())
        logger.info("Engine started")

    async def stop(self) -> None:
        """Stop the engine loop."""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        if self._mlx_executor is not None:
            # Tear down BatchGenerator on the worker thread that owns its
            # generation stream. Otherwise its __del__ runs at process exit
            # in some other thread and calls mx.synchronize on a stream
            # that no longer exists, raising
            # "There is no Stream(gpu, N) in current thread."
            try:
                self._run_on_step_thread(self.scheduler._close_batch_generator)
            except Exception as e:
                logger.debug(f"Error closing BatchGenerator on worker: {e}")
            if self._owns_executor:
                self._mlx_executor.shutdown(wait=True)
            self._mlx_executor = None
            self._owns_executor = False
        logger.info("Engine stopped")

    def _run_on_step_thread(self, func, *args, **kwargs):
        """Run `func` on the MLX worker thread and return its result.

        Use this for MLX operations called from the asyncio loop thread
        (or any other thread) that touch arrays whose backing stream lives
        on the owner worker, e.g. saving the prefix cache to disk on
        shutdown.

        Falls back to a direct call if the executor isn't available
        (engine not started or already stopped); a non-owner thread
        evaluating the owner's stream raises
        "There is no Stream(gpu, N) in current thread."
        """
        executor = self._mlx_executor
        if executor is None:
            # No worker thread: callers in test/CLI paths run sync. In
            # production after start() this should never trigger; if it
            # does, the call is about to hit Stream(gpu, N) again — log
            # at debug so a future regression surfaces in diagnostics.
            logger.debug(
                "_run_on_step_thread: no executor, running %s inline",
                getattr(func, "__qualname__", func),
            )
            return func(*args, **kwargs)
        future = executor.submit(func, *args, **kwargs)
        return future.result()

    def is_running(self) -> bool:
        """Check if engine is running."""
        return self._running

    def _run_pressure_evict_tick(self) -> None:
        """D-METAL-PFX: drive the scheduler pressure-eviction loop once.

        Extracted from ``_engine_loop`` so the codex round 2 BLOCKING
        behavioural test can drive the exact error-handling path
        without spinning up a full asyncio engine loop.

        Why this is its own helper:
        - Called every 16 steps from the asyncio engine loop's
          memory-pressure tick INDEPENDENTLY of the legacy
          ``active_mem > _memory_pressure_threshold`` gate. That
          gate is computed once at startup from
          ``gpu_memory_utilization + 0.05`` (capped at 0.99) and on a
          low cap like ``--gpu-memory-utilization 0.45`` it can sit
          ABOVE the scheduler's own ``metal_pressure_evict_fraction ×
          cap`` — gating on it would prevent D-METAL-PFX recovery on
          exactly the configuration the bug repro flagged (codex
          round 1 BLOCKING).
        - ``Scheduler.evict_prefix_cache_under_pressure`` is itself
          short-circuited when pressure is below its threshold AND
          when the cap is disabled (default ``gpu_memory_utilization
          = 0.0``), so calling this every 16 steps costs one
          ``memory_stats()`` and one dict lookup on
          configurations that don't need it.
        - Exceptions from the eviction path (codex round 2 BLOCKING
          #1: e.g. ``memory_aware_cache._evict_lru`` raising under a
          subtle lock-state bug) MUST surface in the engine log so
          operators can correlate a stalled D-METAL-PFX series with
          the underlying error. Rate-limited via the
          ``_pressure_evict_error_logged`` sentinel so a persistent
          failure doesn't flood at 16-step cadence.
        """
        try:
            self.scheduler.evict_prefix_cache_under_pressure()
        except Exception as evict_exc:
            if not getattr(self, "_pressure_evict_error_logged", False):
                self._pressure_evict_error_logged = True
                logger.warning(
                    "[D-METAL-PFX] prefix-cache pressure "
                    "eviction raised; further failures "
                    "will be suppressed: %r",
                    evict_exc,
                )

    async def _engine_loop(self) -> None:
        """Main engine loop."""
        # The single mlx-step worker thread is created in start() so that
        # _run_on_step_thread() can also reach it from non-loop callers
        # (e.g. shutdown cache persistence). One owner thread per device:
        # MLX streams are thread-local, and KV caches (e.g. Qwen3.x
        # RotatingKVCache) keep arrays tagged with the owner's stream
        # across prefill and decode: only the owner can eval them.
        _executor = self._mlx_executor
        loop = asyncio.get_running_loop()

        step_interval = self.config.step_interval
        stream_interval = self.config.stream_interval
        use_simple_streaming = stream_interval == 1

        # Bind the idle-wakeup event to the running loop (asyncio.Event must
        # be created on the loop it's awaited from).
        if self._idle_event is None:
            self._idle_event = asyncio.Event()

        # Emergency memory pressure threshold — dynamic based on gpu_memory_utilization.
        # Uses the backend's recommended working set when available (seam,
        # item 3), falling back to device memory. Applies a 5% gap above the
        # soft limit (capped at 99%).
        _gpu_mem_util = self.config.gpu_memory_utilization
        try:
            from vllm_mlx.device import get_backend

            _backend = get_backend()
            _max_recommended = (
                _backend.recommended_working_set_bytes() if _backend else 0
            )
            _device_mem = (
                _max_recommended if _max_recommended > 0 else 200 * 1024 * 1024 * 1024
            )
            _memory_pressure_threshold = int(
                _device_mem * min(_gpu_mem_util + 0.05, 0.99)
            )
        except Exception:
            _memory_pressure_threshold = 200 * 1024 * 1024 * 1024
        # Check every 16 steps (was 64). Sustained-load Metal errors
        # correlate with creeping memory pressure; catching it 4× sooner
        # gives mx.clear_cache() a chance to defuse before the next
        # large allocation pushes us into a Metal-side OOM, which currently
        # propagates as an uncatchable abort (see GitHub #353 / mlx-lm#1015).
        _memory_check_interval = 16
        # Consecutive step() failures — once we hit the cap we sleep longer
        # between retries so a permanently-broken Metal state (e.g. real OOM
        # we can't recover from) stops flooding the log at 10 Hz. Resets
        # on the first successful step. See #353.
        _consecutive_step_failures = 0
        _STEP_FAILURE_BURST = 10

        # Codex round 6 BLOCKING #1: idle-state pressure-evict cadence.
        # The busy-step path runs eviction every ``_memory_check_interval``
        # steps. The idle path (no requests in flight) needs its own
        # wall-clock tick so prefix-cache slabs left behind by the LAST
        # request still drain — without it, an idle server stays stuck
        # at the old active-memory high-watermark and rejects every
        # new admit with D-METAL-CAP backpressure.
        _idle_pressure_evict_last = 0.0
        _idle_pressure_evict_interval_s = 5.0
        while self._running:
            try:
                if self.scheduler.has_requests():
                    output = await loop.run_in_executor(_executor, self.scheduler.step)
                    self._steps_executed += 1
                    _consecutive_step_failures = 0

                    # Emergency memory pressure check
                    if self._steps_executed % _memory_check_interval == 0:
                        try:
                            from vllm_mlx.device import get_backend

                            _backend = get_backend()
                            if _backend is not None:
                                active_mem = _backend.memory_stats().active_bytes
                                if active_mem > _memory_pressure_threshold:
                                    mx.clear_cache()
                                    logger.warning(
                                        f"[Memory pressure] {active_mem / 1e9:.1f}GB > "
                                        f"{_memory_pressure_threshold / 1e9:.0f}GB threshold, "
                                        f"forced cache clear"
                                    )
                        except Exception:
                            pass

                        # D-METAL-PFX: pressure-driven prefix-cache
                        # eviction must run INDEPENDENTLY of the legacy
                        # ``_memory_pressure_threshold`` gate above.
                        # See ``_run_pressure_evict_tick`` for the full
                        # rationale (codex round 1 BLOCKING + NIT).
                        # Codex round 6 BLOCKING #2: eviction touches
                        # cached MLX arrays + calls mx.clear_cache().
                        # One owner thread per device (MLX streams are
                        # thread-bound), so dispatch onto the same single
                        # ``mlx-step`` worker that runs ``scheduler.step``
                        # rather than executing on the asyncio thread.
                        if _executor is not None:
                            await loop.run_in_executor(
                                _executor, self._run_pressure_evict_tick
                            )
                        else:
                            self._run_pressure_evict_tick()

                    # Fast path: distribute outputs to collectors
                    outputs = output.outputs
                    if outputs:
                        collectors = self._output_collectors
                        states = self._stream_states
                        events = self._finished_events

                        for req_output in outputs:
                            rid = req_output.request_id
                            collector = collectors.get(rid)

                            if collector is not None:
                                # Optimized: skip stream_interval check when interval=1
                                if use_simple_streaming:
                                    collector.put(req_output)
                                else:
                                    state = states.get(rid)
                                    # Merge this step's delta into the buffer so
                                    # tokens that fall between should_send() hits
                                    # are not silently discarded. new_text,
                                    # new_token_ids, and logprobs are all
                                    # per-step deltas (scheduler emits one
                                    # token's worth per step) and must
                                    # accumulate; cumulative status fields take
                                    # the latest value.
                                    buf = self._stream_buffers.get(rid)
                                    self._stream_buffers[rid] = (
                                        self._merge_stream_buffer(buf, req_output)
                                    )
                                    if state and state.should_send(
                                        req_output.completion_tokens,
                                        req_output.finished,
                                    ):
                                        flushed = self._stream_buffers.pop(rid)
                                        collector.put(flushed)
                                        state.mark_sent(req_output.completion_tokens)

                            if req_output.finished:
                                event = events.get(rid)
                                if event:
                                    event.set()

                        # Free Metal buffers after distributing finished outputs
                        if output.finished_request_ids:
                            mx.clear_cache()

                        # Always yield to prevent event loop starvation.
                        # Without this, orphaned requests (client disconnected but
                        # request still in scheduler) block the entire event loop,
                        # making the server unresponsive to all HTTP requests.
                        await asyncio.sleep(0)
                else:
                    # No work — block until ``add_request`` sets the
                    # event, with a long fallback timeout for
                    # housekeeping (memory pressure, scheduler.deep_reset
                    # races, etc.). Drops idle CPU from kHz polling to
                    # essentially zero without adding any first-token
                    # latency for requests that arrive mid-idle.
                    try:
                        await asyncio.wait_for(
                            self._idle_event.wait(), timeout=step_interval
                        )
                    except asyncio.TimeoutError:
                        pass
                    self._idle_event.clear()

                    # Codex round 6 BLOCKING #1: drive a pressure-evict
                    # tick on the idle path so prefix-cache slabs from
                    # the last burst drain even when no new requests
                    # arrive. Without this, a fresh ``--gpu-memory-
                    # utilization 0.45`` server that just finished a
                    # 32k-prefill request stays at the high-watermark
                    # forever and rejects the NEXT admission with
                    # D-METAL-CAP backpressure — exactly the
                    # ``service stays stuck`` failure mode codex
                    # flagged in round 6.
                    now_mono = time.monotonic()
                    if (
                        now_mono - _idle_pressure_evict_last
                        >= _idle_pressure_evict_interval_s
                    ):
                        _idle_pressure_evict_last = now_mono
                        if _executor is not None:
                            try:
                                await loop.run_in_executor(
                                    _executor, self._run_pressure_evict_tick
                                )
                            except Exception:
                                # The helper already rate-limits its
                                # own WARNING. Don't let an evict
                                # failure crash the engine loop.
                                pass
                        else:
                            self._run_pressure_evict_tick()

            except asyncio.CancelledError:
                break
            except Exception as e:
                import traceback

                # If step() raises (e.g. Metal RuntimeError that did propagate
                # synchronously to Python, an unexpected scheduler bug, etc.),
                # the in-flight requests would otherwise hang forever waiting
                # on finished_events that never get set. Surface the error to
                # every waiting client as a structured RequestOutput and
                # release their events so HTTP handlers can return 503 instead
                # of timing out.
                #
                # NOTE: this does NOT recover from the async Metal abort path
                # described in #353. When mlx::core::gpu::check_error throws
                # from inside Metal's addCompletedHandler block, the C++
                # exception propagates straight to std::terminate -> abort()
                # without ever passing through a Python frame, and the whole
                # process dies. Tracking that path against mlx-lm#1015 /
                # ml-explore/mlx#... — once mlx defers the throw to the next
                # eval, this handler will start catching it.
                msg = str(e)
                is_metal = any(
                    needle in msg
                    for needle in ("Metal", "MTL", "command buffer", "gpu::check_error")
                )
                if is_metal:
                    logger.error(
                        "Metal runtime error caught in engine loop — failing "
                        f"in-flight requests and clearing buffers: {e}"
                    )
                    try:
                        mx.clear_cache()
                    except Exception:
                        pass
                else:
                    logger.error(f"Engine loop error: {e}\n{traceback.format_exc()}")

                # Fail all in-flight requests with a structured error output so
                # awaiting HTTP handlers unblock (#353).
                err_text = (
                    f"Inference aborted: {type(e).__name__}: {e}"
                    if is_metal
                    else f"Engine loop error: {type(e).__name__}: {e}"
                )
                for rid in list(self._finished_events.keys()):
                    collector = self._output_collectors.get(rid)
                    if collector is not None:
                        try:
                            collector.put(
                                RequestOutput(
                                    request_id=rid,
                                    new_token_ids=[],
                                    new_text="",
                                    output_token_ids=[],
                                    output_text="",
                                    finished=True,
                                    # OpenAI ChatCompletion finish_reason
                                    # literal-set rejects "error"; "length"
                                    # keeps the response spec-parseable.
                                    # ``RequestOutput.error`` still carries
                                    # the full abort message for callers.
                                    finish_reason="length",
                                    prompt_tokens=0,
                                    completion_tokens=0,
                                    error=err_text,
                                )
                            )
                        except Exception:
                            pass
                    ev = self._finished_events.get(rid)
                    if ev is not None:
                        ev.set()

                # Slow the retry loop when failures persist — a stuck Metal
                # state would otherwise burn CPU + flood logs at ~10 Hz. After
                # a burst of failures, back off to 1 s between attempts.
                _consecutive_step_failures += 1
                backoff = (
                    1.0 if _consecutive_step_failures >= _STEP_FAILURE_BURST else 0.1
                )
                if _consecutive_step_failures == _STEP_FAILURE_BURST:
                    logger.warning(
                        f"Engine step has failed {_STEP_FAILURE_BURST} times in a row — "
                        "backing off retry cadence to 1 s. Investigate the underlying "
                        "Metal/scheduler error."
                    )
                await asyncio.sleep(backoff)

    async def add_request(
        self,
        prompt: str | list[int],
        sampling_params: SamplingParams | None = None,
        request_id: str | None = None,
        images: list[Any] | None = None,
        videos: list[Any] | None = None,
        prefix_boundary: int = 0,
        has_tools: bool = False,
        media_key: str = "",
        pixel_values: Any | None = None,
    ) -> str:
        """
        Add a request for processing.

        Args:
            prompt: Input prompt (string or token IDs)
            sampling_params: Generation parameters
            request_id: Optional custom request ID
            images: Optional images for multimodal
            videos: Optional videos for multimodal
            prefix_boundary: Token count for shared prefix (for cache)
            has_tools: Whether the request includes tool definitions
                (routed to the diffusion lane scheduler)
            media_key: Stable media-content key for image-aware KV cache
                keying (issue #56). "" for text-only requests.
            pixel_values: Processed vision tensors for the request (issue
                #56 scoped mode). The scheduler forwards them to the model
                on the single-request vision prefill; None for text-only
                requests keeps the forward byte-identical to pre-#56.

        Returns:
            The request ID
        """
        if request_id is None:
            request_id = str(uuid.uuid4())

        if sampling_params is None:
            sampling_params = SamplingParams()

        request = Request(
            request_id=request_id,
            prompt=prompt,
            sampling_params=sampling_params,
            images=images,
            videos=videos,
            prefix_boundary=prefix_boundary,
            has_tools=has_tools,
            media_key=media_key or "",
            pixel_values=pixel_values,
        )

        # Throttle requests for hybrid models (GatedDeltaNet + Transformer).
        # Simultaneous batch formation with ArraysCache causes corruption
        # (all outputs become token 0).  A 200ms gap between inserts lets
        # the BatchGenerator fully absorb each request before the next arrives.
        # The first request needs a longer gap (500ms) to allow BatchGenerator
        # creation and Metal shader compilation to complete.
        if self._hybrid_throttle:
            if self._hybrid_lock is None:
                self._hybrid_lock = asyncio.Lock()
            loop = asyncio.get_running_loop()
            async with self._hybrid_lock:
                now = loop.time()
                elapsed = now - self._last_request_time
                gap = 0.5 if self._last_request_time == 0.0 else 0.2
                if elapsed < gap:
                    await asyncio.sleep(gap - elapsed)
                self._last_request_time = loop.time()

        # Setup output collector AFTER throttle so a cancelled sleep
        # doesn't leak per-request state.
        self._output_collectors[request_id] = RequestOutputCollector(aggregate=True)
        self._stream_states[request_id] = RequestStreamState(
            stream_interval=self.config.stream_interval
        )
        self._finished_events[request_id] = asyncio.Event()

        # Dispatch to the mlx-step worker so any MLX arrays allocated during
        # prefix cache lookup (memory_aware_cache.fetch deep-copies cached KV
        # state, paged_cache.reconstruct_cache materializes block tensors,
        # etc.) are tagged with the worker's default stream. Otherwise those
        # arrays carry the asyncio loop thread's stream and the next
        # batch_generator.next() raises "There is no Stream(gpu, N) in
        # current thread" inside `mx.eval([c.state for c in self.prompt_cache])`.
        # Complements the warmup/model-load fix in PR #173 / #174.
        #
        # F-012 (RST-mid-SSE zombie KV): a cancellation that lands while
        # we're awaiting the executor leaves the scheduler in a
        # genuinely unknown state — ``run_in_executor`` propagates
        # ``CancelledError`` to the awaiter but does NOT cancel the
        # blocking executor task, so ``scheduler.add_request(request)``
        # may already have run, may be mid-run, or may still be
        # waiting in the executor queue. Without protection the
        # cancellation chain unwinds the route, ``stream_outputs`` is
        # never entered, ``stream_outputs.finally`` never aborts, and
        # the executor-side ``add_request`` completes some
        # milliseconds later — leaving a request in the scheduler with
        # no awaiter. Under a 30-RST storm this happens 0-30 times per
        # storm; the orphaned requests then run to full ``max_tokens``
        # consuming KV cache until Metal OOM kills the process (the
        # upstream cause of F-010 and F-030).
        #
        # Fix (codex r1 P1): keep a reference to the underlying
        # ``concurrent.futures.Future`` from ``pool.submit`` and, if
        # the outer task is cancelled, register a done-callback that
        # cleans up AFTER the executor task actually returns. The
        # earlier ``asyncio.shield`` approach was incorrect — once
        # ``Task.cancel()`` propagates to the asyncio Future wrapper
        # returned by ``run_in_executor``, the wrapper is marked
        # CANCELLED immediately (``done() == True``) while the
        # executor thread continues running ``scheduler.add_request``
        # in the background, so the cleanup could fire BEFORE the
        # request actually landed in the scheduler — exactly the
        # zombie window we are trying to close.
        #
        # ``submit`` returns a ``concurrent.futures.Future`` whose
        # state is independent of asyncio cancellation. We wrap it
        # in ``asyncio.wrap_future`` for the happy-path await, and
        # on cancellation we hand the SCHEDULER-thread cleanup off
        # via ``cf.add_done_callback`` — guaranteed to fire once the
        # executor task actually completes. The callback runs on the
        # executor thread (NOT the asyncio thread), so we bounce the
        # asyncio-thread parts (collector dict mutation, idle-event
        # set) back via ``loop.call_soon_threadsafe`` to avoid mixing
        # writers on the per-request dicts.
        if self._mlx_executor is not None:
            loop = asyncio.get_running_loop()
            cf = self._mlx_executor.submit(self.scheduler.add_request, request)
            try:
                await asyncio.wrap_future(cf, loop=loop)
            except (asyncio.CancelledError, Exception):
                # Codex r2 P1 #1: catch the request-control exceptions
                # we own (cancellation and ordinary errors) but let
                # process-control ``BaseException``s
                # (``KeyboardInterrupt`` / ``SystemExit``) propagate
                # unaltered — we should NOT be mutating
                # scheduler/request state during a process shutdown
                # path. The cleanup invariants below assume the
                # executor is still running; under a SIGINT the
                # interpreter is tearing down and the right thing is
                # to bubble out cleanly.
                # The executor task may still be running. Hand
                # cleanup off to fire AFTER it completes (the abort
                # MUST land AFTER ``scheduler.add_request`` returns or
                # the abort id is consumed by ``_process_pending_aborts``
                # BEFORE the late-arriving request reaches the
                # scheduler — the zombie path).
                def _on_executor_done(_future: Any) -> None:
                    # Runs on the executor thread.
                    #
                    # Codex r3 P1 #1: ``asyncio.wrap_future`` propagates
                    # cancellation back to the underlying
                    # ``concurrent.futures.Future``. If the executor
                    # job had NOT started yet, ``cf.cancel()`` succeeds
                    # and ``scheduler.add_request`` never runs — in
                    # that case the request was never admitted and
                    # there is nothing to abort. Without this gate we
                    # would teardown a request that was never in the
                    # scheduler AND wake the engine for a no-op abort.
                    # Branch on ``cf.cancelled()`` so we only fire the
                    # abort + cleanup when the executor actually ran
                    # ``scheduler.add_request`` (success OR raise).
                    if _future.cancelled():
                        # Per-request collectors / events were already
                        # allocated; release them even though the
                        # scheduler never saw the request, so the
                        # dicts don't leak under a fast-cancel storm.
                        try:
                            loop.call_soon_threadsafe(
                                self._cleanup_request_safe, request_id
                            )
                        except RuntimeError:
                            self._cleanup_request_safe(request_id)
                        return
                    try:
                        self.scheduler.abort_request(request_id)
                    except Exception:
                        logger.warning(
                            "[add_request] abort_request raised during"
                            " executor-done cleanup for %s",
                            request_id,
                            exc_info=True,
                        )
                    # Bounce the asyncio-thread cleanup back onto the
                    # event loop so we don't race the dict writers
                    # in ``add_request`` (which all run on the
                    # asyncio thread normally).
                    try:
                        loop.call_soon_threadsafe(
                            self._cleanup_request_safe, request_id
                        )
                    except RuntimeError:
                        # Loop already closed (shutdown race) — fall
                        # back to a direct (best-effort) call so the
                        # dicts don't leak.
                        self._cleanup_request_safe(request_id)

                if cf.done():
                    # Executor already finished — run cleanup inline
                    # to preserve the ordering invariant (abort fires
                    # AFTER the request landed in the scheduler).
                    _on_executor_done(cf)
                else:
                    cf.add_done_callback(_on_executor_done)
                raise
        else:
            self.scheduler.add_request(request)

        # Wake the engine loop if it's blocked on the idle event.
        # asyncio.Event.set() is loop-thread-safe when called from coros
        # running on the same loop (which add_request always is).
        if self._idle_event is not None:
            self._idle_event.set()

        return request_id

    async def abort_request(self, request_id: str) -> bool:
        """Abort a request."""
        result = self.scheduler.abort_request(request_id)
        self._cleanup_request(request_id)
        return result

    def _cleanup_request(self, request_id: str) -> None:
        """Clean up request tracking."""
        collector = self._output_collectors.pop(request_id, None)
        if collector:
            collector.clear()
        self._stream_states.pop(request_id, None)
        self._stream_buffers.pop(request_id, None)
        self._finished_events.pop(request_id, None)
        self.scheduler.remove_finished_request(request_id)

    def _cleanup_request_safe(self, request_id: str) -> None:
        """``_cleanup_request`` + wake the engine idle event.

        Used by the F-012 cancellation-cleanup path: when
        ``add_request`` was cancelled mid-executor, the cleanup
        callback runs on the executor thread and bounces back here
        via ``loop.call_soon_threadsafe`` so the per-request dicts
        are mutated on the asyncio thread (single writer). Sets
        ``_idle_event`` so the engine loop wakes up to process the
        ``scheduler.abort_request`` we just enqueued — without this
        the abort id sits in ``_pending_abort_ids`` until the next
        natural ``step()``, which may be never if no other request
        is in flight.
        """
        try:
            self._cleanup_request(request_id)
        finally:
            if self._idle_event is not None:
                self._idle_event.set()

    @staticmethod
    def _merge_stream_buffer(
        buf: RequestOutput | None, req_output: RequestOutput
    ) -> RequestOutput:
        """Accumulate this step's delta into the stream buffer.

        Active when ``stream_interval > 1`` and the scheduler emits one
        token's worth of delta per step. ``new_text``, ``new_token_ids``,
        and ``logprobs`` are per-step deltas and must concat; cumulative
        status fields (``output_token_ids``, counts, finish state) take
        the latest value. Per-step ``logprobs`` (mx.array or None) is
        wrapped in a list so subsequent merges concat instead of
        overwriting — the flushed RequestOutput's ``logprobs`` ends up
        as ``list[mx.array]`` when stream_interval > 1.

        Pinned as a method so any new ``RequestOutput`` field must be
        threaded here too; tested in
        ``tests/test_server.py::TestEngineCoreStreamBufferMerge`` so a
        future addition that misses this path fails loud.
        """
        new_lp = [req_output.logprobs] if req_output.logprobs is not None else []
        prev_text = buf.new_text if buf else ""
        prev_tokens = buf.new_token_ids if buf else []
        prev_lp = (buf.logprobs if buf else None) or []
        return RequestOutput(
            request_id=req_output.request_id,
            new_token_ids=prev_tokens + req_output.new_token_ids,
            new_text=prev_text + req_output.new_text,
            output_token_ids=req_output.output_token_ids,
            output_text=req_output.output_text,
            finished=req_output.finished,
            finish_reason=req_output.finish_reason,
            prompt_tokens=req_output.prompt_tokens,
            completion_tokens=req_output.completion_tokens,
            cached_tokens=req_output.cached_tokens,
            logprobs=(prev_lp + new_lp) or None,
            # H-03: prefer the newer step's matched_stop (the scheduler
            # pins it exactly once on the chunk where the stop fires);
            # fall back to the existing buffer so a stop that fired on a
            # previous flush is not erased by a later step where the
            # field is None. ``buf`` may be None on the first step.
            matched_stop=(
                req_output.matched_stop
                or (buf.matched_stop if buf is not None else None)
            ),
        )

    async def stream_outputs(
        self,
        request_id: str,
        timeout: float | None = None,
    ) -> AsyncIterator[RequestOutput]:
        """
        Stream outputs for a request with low-latency non-blocking pattern.

        Uses the vLLM pattern: get_nowait() or await get()
        This avoids unnecessary task switches when output is available.

        Args:
            request_id: The request ID
            timeout: Optional timeout in seconds

        Yields:
            RequestOutput objects as tokens are generated
        """
        import time as _time

        _t0 = _time.monotonic()
        _token_count = 0

        collector = self._output_collectors.get(request_id)
        if collector is None:
            logger.warning(
                f"[stream_outputs] {request_id[:12]} no collector found, returning immediately"
            )
            return

        logger.info(f"[stream_outputs] {request_id[:12]} START waiting for tokens")

        finished_normally = False
        try:
            while True:
                try:
                    if timeout:
                        output = collector.get_nowait()
                        if output is None:
                            output = await asyncio.wait_for(
                                collector.get(), timeout=timeout
                            )
                    else:
                        output = collector.get_nowait() or await collector.get()

                    _token_count += 1
                    if _token_count == 1:
                        logger.info(
                            f"[stream_outputs] {request_id[:12]} first token after "
                            f"{_time.monotonic() - _t0:.1f}s"
                        )

                    # Engine loop sets ``error`` when it aborts a request mid-
                    # flight (e.g. Metal RuntimeError that propagated to Python).
                    # Raise so streaming HTTP handlers can map to 503 instead of
                    # silently yielding an empty terminal chunk (#353).
                    if output.error:
                        from .request import InferenceAbortedError

                        logger.warning(
                            f"[stream_outputs] {request_id[:12]} engine aborted: {output.error}"
                        )
                        raise InferenceAbortedError(output.error)

                    yield output

                    if output.finished:
                        finished_normally = True
                        logger.info(
                            f"[stream_outputs] {request_id[:12]} finished normally, "
                            f"{_token_count} tokens in {_time.monotonic() - _t0:.1f}s"
                        )
                        break

                except asyncio.TimeoutError:
                    logger.warning(
                        f"[stream_outputs] {request_id[:12]} TIMEOUT after "
                        f"{_token_count} tokens, {_time.monotonic() - _t0:.1f}s"
                    )
                    break

        except (GeneratorExit, asyncio.CancelledError) as exc:
            logger.info(
                f"[stream_outputs] {request_id[:12]} {type(exc).__name__} after "
                f"{_token_count} tokens, {_time.monotonic() - _t0:.1f}s"
            )

        finally:
            if not finished_normally:
                logger.info(
                    f"[stream_outputs] {request_id[:12]} ABORTING orphaned request "
                    f"({_token_count} tokens generated in {_time.monotonic() - _t0:.1f}s)"
                )
                aborted = self.scheduler.abort_request(request_id)
                logger.info(
                    f"[stream_outputs] {request_id[:12]} abort_request returned {aborted}"
                )
            self._cleanup_request(request_id)
            logger.info(f"[stream_outputs] {request_id[:12]} cleanup done")

    async def generate(
        self,
        prompt: str | list[int],
        sampling_params: SamplingParams | None = None,
        request_id: str | None = None,
        **kwargs,
    ) -> RequestOutput:
        """
        Generate a complete response (non-streaming).

        This method is optimized to avoid streaming overhead when
        you only need the final result.

        Args:
            prompt: Input prompt
            sampling_params: Generation parameters
            request_id: Optional request ID

        Returns:
            Final RequestOutput with complete text
        """
        request_id = await self.add_request(
            prompt=prompt,
            sampling_params=sampling_params,
            request_id=request_id,
            **kwargs,
        )

        # Wait for completion using event instead of streaming
        # This avoids the waiting_consumer tracking overhead
        event = self._finished_events.get(request_id)
        if event is None:
            raise RuntimeError(f"No event for request {request_id}")

        try:
            # Wait for the request to finish
            await event.wait()

            # Get the final output from collector
            collector = self._output_collectors.get(request_id)
            if collector is None:
                raise RuntimeError(f"No collector for request {request_id}")

            # Drain all outputs and get the last one
            final_output = None
            while True:
                output = collector.get_nowait()
                if output is None:
                    break
                final_output = output

            if final_output is None:
                raise RuntimeError(f"No output for request {request_id}")

            # Engine loop sets error= when it aborts the request (e.g. Metal
            # runtime error). Surface as InferenceAbortedError so the HTTP
            # layer maps to 503 (#353).
            if final_output.error:
                from .request import InferenceAbortedError

                raise InferenceAbortedError(final_output.error)

            return final_output

        except (asyncio.CancelledError, GeneratorExit):
            logger.info(f"[generate] {request_id[:12]} CANCELLED, aborting request")
            self.scheduler.abort_request(request_id)
            raise

        finally:
            self._cleanup_request(request_id)

    def generate_batch_sync(
        self,
        prompts: list[str | list[int]],
        sampling_params: SamplingParams | None = None,
    ) -> list[RequestOutput]:
        """
        Generate responses synchronously for maximum throughput.

        This bypasses the async engine loop entirely, running the scheduler
        directly for optimal batching performance. Use this when you don't
        need streaming and want maximum throughput.

        Args:
            prompts: List of input prompts
            sampling_params: Generation parameters (same for all)

        Returns:
            List of RequestOutput in same order as prompts
        """
        import uuid as uuid_module

        from .request import Request

        if sampling_params is None:
            sampling_params = SamplingParams()

        # Add all requests to scheduler
        request_ids = []
        for prompt in prompts:
            request_id = str(uuid_module.uuid4())
            request = Request(
                request_id=request_id,
                prompt=prompt,
                sampling_params=sampling_params,
            )
            self.scheduler.add_request(request)
            request_ids.append(request_id)

        # Process until all done - direct scheduler access, no async overhead
        results: dict[str, RequestOutput] = {}
        while self.scheduler.has_requests():
            output = self.scheduler.step()
            for req_output in output.outputs:
                if req_output.finished:
                    results[req_output.request_id] = req_output

        # Cleanup
        for rid in request_ids:
            self.scheduler.remove_finished_request(rid)

        # Return in original order
        return [results[rid] for rid in request_ids]

    def get_stats(self) -> dict[str, Any]:
        """Get engine statistics."""
        scheduler_stats = self.scheduler.get_stats()
        uptime = time.time() - self._start_time if self._start_time else 0

        return {
            "running": self._running,
            "uptime_seconds": uptime,
            "steps_executed": self._steps_executed,
            "active_requests": len(self._output_collectors),
            "stream_interval": self.config.stream_interval,
            "requests": self.scheduler.get_running_requests_info(),
            **scheduler_stats,
        }

    def get_cache_stats(self) -> dict[str, Any] | None:
        """Get prefix cache statistics."""
        return self.scheduler.get_cache_stats()

    def save_cache_to_disk(self, cache_dir: str, should_abort=None) -> bool:
        """Save prefix cache to disk.

        Routed through the mlx-step worker thread because the KV-cache
        arrays are tagged with that thread's generation_stream; trying to
        materialize them from the asyncio loop thread raises
        "There is no Stream(gpu, N) in current thread."

        ``should_abort`` is a ``Callable[[float], bool]`` evaluated
        between entries inside ``MemoryAwarePrefixCache.save_to_disk``.
        The ``float`` arg is the predicted write duration of the NEXT
        entry — the predicate answers "would starting that write push
        us past the deadline?" so a single uninterruptible
        ``save_prompt_cache`` call can't straddle the deadline and
        still get SIGKILLed mid-write (the round-1 at-now check could).
        Zero-arg predicates are accepted for backwards compatibility
        via auto-detection; the deadline-backed predicate the lifespan
        plumbs through is one-arg.
        """
        return self._run_on_step_thread(
            self.scheduler.save_cache_to_disk, cache_dir, should_abort=should_abort
        )

    def load_cache_from_disk(self, cache_dir: str) -> int:
        """Load prefix cache from disk.

        Loading also goes through the worker thread so the loaded arrays
        end up tagged with the generation_stream that subsequent fetches
        will run on.
        """
        return self._run_on_step_thread(self.scheduler.load_cache_from_disk, cache_dir)

    def _release_model(self) -> None:
        """Release model ownership."""
        if self._owns_model and not self._closed:
            registry = get_registry()
            registry.release(self.model, self._engine_id)
            self._owns_model = False
            logger.debug(f"Engine {self._engine_id} released model ownership")

    def close(self) -> None:
        """
        Explicitly close the engine and release resources.

        This should be called when done using the engine, especially
        if you plan to create another engine with the same model.
        """
        if self._closed:
            return

        # Release model ownership BEFORE setting _closed
        # (_release_model checks not self._closed)
        if self._owns_model:
            registry = get_registry()
            registry.release(self.model, self._engine_id)
            self._owns_model = False
            logger.debug(f"Engine {self._engine_id} released model ownership")

        self._closed = True

        # Reset scheduler to clear BatchGenerator and all caches
        self.scheduler.deep_reset()

        # Clear output collectors
        for collector in self._output_collectors.values():
            collector.clear()
        self._output_collectors.clear()
        self._stream_states.clear()
        self._stream_buffers.clear()
        self._finished_events.clear()

        logger.debug(f"Engine {self._engine_id} closed")

    def __del__(self):
        """Cleanup on destruction."""
        try:
            self._release_model()
        except Exception:
            # Ignore errors during garbage collection
            pass

    @property
    def engine_id(self) -> str:
        """Get the engine ID."""
        return self._engine_id


class AsyncEngineCore:
    """
    Async context manager wrapper for EngineCore.

    Usage:
        async with AsyncEngineCore(model, tokenizer) as engine:
            request_id = await engine.add_request("Hello")
            async for output in engine.stream_outputs(request_id):
                print(output.new_text)
    """

    def __init__(
        self,
        model: Any,
        tokenizer: Any,
        config: EngineConfig | None = None,
        *,
        executor: concurrent.futures.ThreadPoolExecutor | None = None,
    ):
        self.engine = EngineCore(model, tokenizer, config)
        self._executor = executor

    async def __aenter__(self) -> "AsyncEngineCore":
        await self.engine.start(executor=self._executor)
        return self

    async def __aexit__(self, *args) -> None:
        await self.engine.stop()

    def start(self) -> None:
        """Start engine (creates task in current loop)."""
        asyncio.create_task(self.engine.start())

    async def stop(self) -> None:
        """Stop the engine."""
        await self.engine.stop()

    async def add_request(
        self,
        prompt: str | list[int],
        sampling_params: SamplingParams | None = None,
        request_id: str | None = None,
        **kwargs,
    ) -> str:
        """Add a request."""
        return await self.engine.add_request(
            prompt=prompt,
            sampling_params=sampling_params,
            request_id=request_id,
            **kwargs,
        )

    async def abort_request(self, request_id: str) -> bool:
        """Abort a request."""
        return await self.engine.abort_request(request_id)

    async def stream_outputs(
        self,
        request_id: str,
        timeout: float | None = None,
    ) -> AsyncIterator[RequestOutput]:
        """Stream outputs."""
        async for output in self.engine.stream_outputs(request_id, timeout):
            yield output

    async def generate(
        self,
        prompt: str | list[int],
        sampling_params: SamplingParams | None = None,
        **kwargs,
    ) -> RequestOutput:
        """Generate complete response."""
        return await self.engine.generate(
            prompt=prompt,
            sampling_params=sampling_params,
            **kwargs,
        )

    def get_stats(self) -> dict[str, Any]:
        """Get engine stats."""
        return self.engine.get_stats()

    def get_cache_stats(self) -> dict[str, Any] | None:
        """Get prefix cache statistics."""
        return self.engine.get_cache_stats()

    def save_cache_to_disk(self, cache_dir: str, should_abort=None) -> bool:
        """Save prefix cache to disk."""
        return self.engine.save_cache_to_disk(cache_dir, should_abort=should_abort)

    def load_cache_from_disk(self, cache_dir: str) -> int:
        """Load prefix cache from disk."""
        return self.engine.load_cache_from_disk(cache_dir)
